package com.example.openaichat

import android.app.*
import android.content.*
import android.content.ClipboardManager
import android.content.res.ColorStateList
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.text.*
import android.text.style.*
import android.util.Base64
import android.view.*
import android.widget.*
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.security.KeyStore
import java.util.concurrent.Executors
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties

class MainActivity : Activity() {
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
        .readTimeout(0, java.util.concurrent.TimeUnit.SECONDS)
        .callTimeout(0, java.util.concurrent.TimeUnit.SECONDS)
        .build()
    private val executor = Executors.newCachedThreadPool()

    private lateinit var prefs: SharedPreferences
    private lateinit var scroll: ScrollView
    private lateinit var messages: LinearLayout
    private lateinit var input: EditText
    private lateinit var send: Button
    private lateinit var stop: Button
    private lateinit var status: TextView
    private lateinit var toolLabel: TextView
    private lateinit var title: TextView
    private lateinit var attachRow: LinearLayout
    private var vsListArea: LinearLayout? = null
    private var vsStatusLine: TextView? = null
    private lateinit var attachScroll: HorizontalScrollView
    private lateinit var effortBadge: TextView

    private var currentCall: Call? = null
    private var currentResponseId: String? = null
    private var baselineEffort: String? = null
    private val chat = mutableListOf<JSONObject>()
    private val attachedFileIds = mutableListOf<String>()
    private val attachedFileNames = mutableListOf<String>()
    private var pendingImageDataUrl: String? = null
    private var lastUserText: String = ""

    private val secure by lazy { SecureStore(this) }
    private val pickAny = 5100
    private val pickImage = 5101
    private val pickVoice = 5102
    private val pickVectorStoreFile = 5103

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("app", MODE_PRIVATE)
        ensureChatStore()
        buildUi()
        restoreCurrentChat()
    }

    override fun onDestroy() {
        currentCall?.cancel()
        executor.shutdownNow()
        super.onDestroy()
    }

    // ---------- UI ----------
    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(17,18,21))
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(9), dp(8), dp(4))
        }

        val chatsBtn = button("☰") { showChats() }
        header.addView(chatsBtn)

        title = TextView(this).apply {
            text = currentChatTitle()
            textSize = 19f
            setTextColor(Color.WHITE)
            setTypeface(null, Typeface.BOLD)
            setSingleLine(true)
            ellipsize = TextUtils.TruncateAt.END
        }
        header.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(button("＋") { newChat() })
        header.addView(button("⚙") { showSettings() })
        root.addView(header)

        status = TextView(this).apply {
            text = "Готово"
            textSize = 12f
            setTextColor(Color.rgb(165,170,180))
            setPadding(dp(14), 0, dp(14), dp(4))
        }
        root.addView(status)

        scroll = ScrollView(this)
        messages = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(6), dp(10), dp(12))
        }
        scroll.addView(messages)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        toolLabel = TextView(this).apply {
            textSize = 12f
            setTextColor(Color.rgb(145,190,245))
            setPadding(dp(12), 0, dp(12), dp(4))
            maxLines = 4
            ellipsize = TextUtils.TruncateAt.END
            setOnClickListener { showToolDetails() }
        }
        root.addView(toolLabel)

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), 0, dp(10), dp(4))
        }
        row.addView(button("📎") { chooseAny() })
        row.addView(button("🖼") { chooseImage() })

        effortBadge = TextView(this).apply {
            textSize = 12f
            setTextColor(Color.rgb(138,180,248))
            setPadding(dp(10),0,dp(6),0)
            text = "⚡ "+(prefs.getString("reasoning","high") ?: "high")
            setOnClickListener { showQuickEffortPicker() }
        }
        row.addView(effortBadge)

        val space = Space(this)
        row.addView(space, LinearLayout.LayoutParams(0,1,1f))

        val modelBadge = TextView(this).apply {
            textSize = 12f
            setTextColor(Color.GRAY)
            text = prefs.getString("model","gpt-6-astra")
        }
        row.addView(modelBadge)
        root.addView(row)

        attachRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        attachScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            setPadding(dp(10), 0, dp(10), dp(6))
            visibility = View.GONE
            addView(attachRow, LinearLayout.LayoutParams(-2, -2))
        }
        root.addView(attachScroll)

        val composer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.BOTTOM
            setPadding(dp(10), dp(3), dp(10), dp(10))
        }
        input = EditText(this).apply {
            hint = "Сообщение…"
            setHintTextColor(Color.rgb(120,125,135))
            setTextColor(Color.WHITE)
            textSize = 16f
            setPadding(dp(13),dp(10),dp(13),dp(10))
            setBackgroundColor(Color.rgb(30,31,36))
            minLines = 1
            maxLines = 7
            inputType = android.text.InputType.TYPE_CLASS_TEXT or
                    android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                    android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        }
        composer.addView(input, LinearLayout.LayoutParams(0,-2,1f))

        composer.addView(button("🎙") { chooseVoice() }, LinearLayout.LayoutParams(dp(46),-2))

        send = Button(this).apply {
            text = "➤"
            minWidth=0; minimumWidth=0
            setOnClickListener { sendMessage(false) }
        }
        composer.addView(send, LinearLayout.LayoutParams(dp(58),-2))

        stop = Button(this).apply {
            text = "■"
            minWidth=0; minimumWidth=0
            visibility = View.GONE
            setOnClickListener { currentCall?.cancel() }
        }
        composer.addView(stop, LinearLayout.LayoutParams(dp(58),-2))
        root.addView(composer)

        root.setOnApplyWindowInsetsListener { v, insets ->
            v.setPadding(insets.systemWindowInsetLeft, insets.systemWindowInsetTop, insets.systemWindowInsetRight, insets.systemWindowInsetBottom)
            insets.consumeSystemWindowInsets()
        }

        setContentView(root)
    }

    private fun showChats() {
        val all = loadAllChats()
        val names = all.map { it.optString("title","Новый чат") }.toMutableList()
        names.add("＋ Новый чат")
        AlertDialog.Builder(this)
            .setTitle("Чаты")
            .setItems(names.toTypedArray()) { _, which ->
                if (which == names.lastIndex) newChat()
                else switchChat(all[which].optString("id"))
            }
            .setNeutralButton("Управление") { _, _ -> manageChats(all) }
            .show()
    }

    private fun manageChats(all: List<JSONObject>) {
        val names = all.map { it.optString("title","Новый чат") }
        if (names.isEmpty()) return
        AlertDialog.Builder(this)
            .setTitle("Управление чатами")
            .setItems(names.toTypedArray()) { _, which ->
                showChatActions(all[which])
            }.show()
    }

    private fun showChatActions(c: JSONObject) {
        AlertDialog.Builder(this)
            .setTitle(c.optString("title","Чат"))
            .setItems(arrayOf("Переименовать","Удалить")) { _, which ->
                when (which) {
                    0 -> renameChat(c.optString("id"))
                    1 -> deleteChat(c.optString("id"))
                }
            }.show()
    }

    private fun renameChat(id: String) {
        val chats = loadAllChats().toMutableList()
        val found = chats.firstOrNull { it.optString("id")==id } ?: return
        val edit = EditText(this).apply {
            setText(found.optString("title"))
            setTextColor(Color.WHITE)
        }
        AlertDialog.Builder(this)
            .setTitle("Название")
            .setView(edit)
            .setNegativeButton("Отмена",null)
            .setPositiveButton("Сохранить") { _, _ ->
                found.put("title", edit.text.toString().trim().ifBlank { "Чат" })
                saveAllChats(chats)
                if (currentChatId()==id) title.text = found.optString("title")
            }.show()
    }

    private fun deleteChat(id: String) {
        val chats = loadAllChats().filterNot { it.optString("id")==id }
        saveAllChats(chats)
        if (currentChatId()==id) newChat()
    }

    // ---------- Settings ----------
    private fun showQuickEffortPicker(){
        val efforts=arrayOf("auto","low","medium","high","xhigh","max")
        val current=prefs.getString("reasoning","high") ?: "high"
        val idx=efforts.indexOf(current).coerceAtLeast(0)
        AlertDialog.Builder(this)
            .setTitle("Мышление")
            .setSingleChoiceItems(efforts,idx){d,which->
                prefs.edit().putString("reasoning",efforts[which]).apply()
                effortBadge.text="⚡ "+efforts[which]
                d.dismiss()
            }.show()
    }

    private fun showSettings() {
        val cardBg = Color.rgb(36,38,44)
        val accent = Color.rgb(138,180,248)
        val subtext = Color.rgb(150,155,165)
        val divider = Color.rgb(52,54,60)

        val box = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(14),dp(6),dp(14),dp(10)) }
        val advancedBox = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; visibility=View.GONE }
        var target: LinearLayout = box

        fun rounded(fill:Int) = GradientDrawable().apply{ cornerRadius=dp(10).toFloat(); setColor(fill) }

        fun section(title:String){
            target.addView(TextView(this).apply{
                this.text=title
                textSize=12.5f
                setTypeface(null,Typeface.BOLD)
                setTextColor(accent)
                setPadding(dp(2),dp(20),0,dp(8))
            })
            target.addView(View(this).apply{ setBackgroundColor(divider) }, LinearLayout.LayoutParams(-1,dp(1)))
        }
        fun spaced(v:View){ target.addView(v, LinearLayout.LayoutParams(-1,-2).apply{ topMargin=dp(10) }) }

        fun field(hint:String,value:String,secret:Boolean=false) = EditText(this).apply {
            this.hint=hint; setText(value); setTextColor(Color.WHITE); setHintTextColor(subtext)
            setPadding(dp(12),dp(11),dp(12),dp(11))
            background=rounded(cardBg)
            if (secret) inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        fun labeled(caption:String,view:View){
            target.addView(TextView(this).apply{this.text=caption;textSize=12f;setTextColor(subtext);setPadding(dp(2),dp(10),0,dp(4))})
            target.addView(view)
        }
        fun spinner(values:Array<String>,pref:String,def:String):Spinner{
            val s=Spinner(this)
            s.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,values)
            s.setSelection(values.indexOf(prefs.getString(pref,def) ?: def).coerceAtLeast(0))
            s.setPadding(dp(10),dp(8),dp(10),dp(8))
            s.background=rounded(cardBg)
            return s
        }

        section("Подключение")
        val key = field("OpenAI API key", secure.getApiKey(), true); spaced(key)
        val model = field("Model ID", prefs.getString("model","gpt-6-astra") ?: "gpt-6-astra"); spaced(model)

        section("Мышление")
        val efforts = arrayOf("auto","low","medium","high","xhigh","max")
        val reasoning = spinner(efforts,"reasoning","high")
        labeled("Reasoning effort (auto = клиент сам подбирает по сложности запроса)",reasoning)

        val modes = arrayOf("standard","pro")
        val mode = spinner(modes,"reasoning_mode","standard")
        labeled("Reasoning mode",mode)

        section("Инструменты")
        fun chk(label:String,pref:String) = CheckBox(this).apply {
            text=label; setTextColor(Color.LTGRAY); isChecked=prefs.getBoolean(pref,false)
            setPadding(dp(4),dp(6),0,dp(6))
        }
        val web=chk("Web Search","web")
        val file=chk("File Search","file_search")
        val code=chk("Code Interpreter","code_interpreter")
        val img=chk("Image Generation","image_generation")
        val parallel=chk("Parallel tool calls","parallel_tools")
        val toolsCard=LinearLayout(this).apply{
            orientation=LinearLayout.VERTICAL
            setPadding(dp(10),dp(4),dp(10),dp(4))
            background=rounded(cardBg)
        }
        listOf(web,file,code,img,parallel).forEach { toolsCard.addView(it) }
        spaced(toolsCard)

        lateinit var advancedToggle: TextView
        advancedToggle = TextView(this).apply{
            text="▸ Дополнительные настройки"
            setTextColor(accent); textSize=13f
            setPadding(dp(2),dp(20),0,dp(6))
            setOnClickListener{
                val show = advancedBox.visibility!=View.VISIBLE
                advancedBox.visibility = if(show) View.VISIBLE else View.GONE
                advancedToggle.text = if(show) "▾ Дополнительные настройки" else "▸ Дополнительные настройки"
            }
        }
        box.addView(advancedToggle)
        box.addView(advancedBox)
        target = advancedBox

        section("Формат ответа")
        val verbosities = arrayOf("low","medium","high")
        val verbosity = spinner(verbosities,"verbosity","medium")
        labeled("Verbosity",verbosity)

        val summaries = arrayOf("auto","concise","detailed","null")
        val summary = spinner(summaries,"reasoning_summary","auto")
        labeled("Summary",summary)

        val textFormats = arrayOf("text","json_object","json_schema")
        val textFormat = spinner(textFormats,"text_format","text")
        labeled("Text format — для обычного чата оставьте \"text\". json_object/json_schema нужны, только если ответ разбирает другая программа (не человек)",textFormat)

        val jsonSchema = field("JSON Schema — заполняйте только при Text format = json_schema", prefs.getString("json_schema","") ?: ""); spaced(jsonSchema)

        section("Прочее")
        val instructions = field("Developer instructions", prefs.getString("instructions","") ?: ""); spaced(instructions)
        val vector = field("Vector Store ID", prefs.getString("vector_store","") ?: ""); spaced(vector)
        spaced(button("📁 Управление файлами Vector Store"){ showVectorStoreManager() }.apply{
            setTextColor(accent); background=rounded(Color.rgb(40,48,66))
        })
        val max = field("Max output tokens", prefs.getString("max_output","128000") ?: "128000"); spaced(max)
        val cache = field("Prompt cache key (optional)", prefs.getString("cache_key","") ?: ""); spaced(cache)

        val note=TextView(this).apply {
            text="Astra: 1.05M context, 128K max output. reasoning: auto/low/medium/high/xhigh/max."
            setTextColor(subtext); textSize=11.5f; setPadding(dp(2),dp(14),0,0)
        }
        box.addView(note)

        AlertDialog.Builder(this)
            .setTitle("Astra / OpenAI API")
            .setView(ScrollView(this).apply{addView(box)})
            .setNegativeButton("Отмена",null)
            .setPositiveButton("Сохранить") { _,_ ->
                secure.setApiKey(key.text.toString().trim())
                prefs.edit()
                    .putString("model",model.text.toString().trim())
                    .putString("instructions",instructions.text.toString())
                    .putString("vector_store",vector.text.toString().trim())
                    .putString("max_output",max.text.toString().trim())
                    .putString("cache_key",cache.text.toString().trim())
                    .putString("json_schema",jsonSchema.text.toString())
                    .putString("reasoning",efforts[reasoning.selectedItemPosition])
                    .putString("reasoning_mode",modes[mode.selectedItemPosition])
                    .putString("verbosity",verbosities[verbosity.selectedItemPosition])
                    .putString("reasoning_summary",summaries[summary.selectedItemPosition])
                    .putString("text_format",textFormats[textFormat.selectedItemPosition])
                    .putBoolean("web",web.isChecked)
                    .putBoolean("file_search",file.isChecked)
                    .putBoolean("code_interpreter",code.isChecked)
                    .putBoolean("image_generation",img.isChecked)
                    .putBoolean("parallel_tools",parallel.isChecked)
                    .apply()
                effortBadge.text="⚡ "+efforts[reasoning.selectedItemPosition]
                status.text="Настройки сохранены"
            }.show()
    }

    // ---------- Chat ----------
    private fun newChat() {
        currentCall?.cancel()
        persistCurrentChat()
        val id = "chat_" + System.currentTimeMillis()
        prefs.edit().putString("current_chat",id).apply()
        chat.clear()
        currentResponseId=null
        baselineEffort=null
        lastUserText=""
        attachedFileIds.clear()
        attachedFileNames.clear()
        pendingImageDataUrl=null
        refreshAttachChips()
        messages.removeAllViews()
        toolLabel.text=""
        title.text="Новый чат"
        ensureChatEntry(id,"Новый чат")
        status.text="Новый чат"
    }

    private fun switchChat(id:String) {
        persistCurrentChat()
        prefs.edit().putString("current_chat",id).apply()
        restoreCurrentChat()
    }

    private fun autoEffort(text:String, hasAttachments:Boolean):String{
        val len=text.length
        val heavy=Regex("(?i)(код|напиши функци|проанализируй|подробно|разбер|докажи|архитектур|дебаг|отладь|сравни|оптимизир|алгоритм|рефактор|explain in detail|analyze|debug)")
        return when {
            hasAttachments && len>200 -> "high"
            heavy.containsMatchIn(text) -> "high"
            len>600 -> "xhigh"
            len in 1..39 -> "low"
            else -> "medium"
        }
    }
    private fun fmtTokens(n:Int):String = when {
        n>=1_000_000 -> "%.1fM".format(n/1_000_000.0)
        n>=1_000 -> "%.1fK".format(n/1_000.0)
        else -> n.toString()
    }
    private fun estimateCost(inputTokens:Int, cachedTokens:Int, outputTokens:Int):Double{
        // GPT-6 Astra standard-tier pricing: $10/M input, $1/M cached input, $50/M output.
        // reasoning.mode (standard/pro) does not itself change the per-token rate.
        val inRate=10.0; val cachedRate=1.0; val outRate=50.0
        val uncached=(inputTokens-cachedTokens).coerceAtLeast(0)
        return (uncached*inRate + cachedTokens*cachedRate + outputTokens*outRate) / 1_000_000.0
    }

    private fun sendMessage(regenerate:Boolean) {
        val key=secure.getApiKey()
        if(key.isBlank()){showSettings();return}

        var text = if(regenerate) lastUserText else input.text.toString().trim()

        // Regeneration reuses the last user message, including its attachments.
        if(regenerate) restoreLastUserAttachments()

        val image=pendingImageDataUrl
        val requestFileIds = attachedFileIds.toList()
        val requestFileNames = attachedFileNames.toList()
        val requestImageDataUrl = image
        if(!regenerate && text.isBlank() && requestImageDataUrl==null && requestFileIds.isEmpty()) return
        if(regenerate && text.isBlank()) return

        val model=prefs.getString("model","gpt-6-astra") ?: "gpt-6-astra"
        val effortPref=prefs.getString("reasoning","high") ?: "high"
        val hasAttachments = attachedFileIds.isNotEmpty() || pendingImageDataUrl!=null
        val effort=if(effortPref=="auto") autoEffort(text,hasAttachments) else effortPref
        val reasoningMode=prefs.getString("reasoning_mode","standard") ?: "standard"
        var configUpdateEffort:String? = null
        val effectiveEffort:String
        if(reasoningMode=="standard"){
            val baseline=baselineEffort
            when {
                baseline==null -> { baselineEffort=effort; effectiveEffort=effort }
                baseline==effort -> effectiveEffort=baseline
                else -> { effectiveEffort=baseline; configUpdateEffort=effort }
            }
        } else {
            effectiveEffort=effort
        }
        val verbosity=prefs.getString("verbosity","medium") ?: "medium"
        val summary=prefs.getString("reasoning_summary","auto") ?: "auto"
        val maxOut=prefs.getString("max_output","128000")?.toIntOrNull()?.coerceIn(256,128000) ?: 128000

        if(!regenerate) {
            addBubble("Ты",buildString {
                if(text.isNotBlank()) append(text)
                if(image!=null){ if(isNotEmpty()) append("\n"); append("🖼 Изображение") }
                if(attachedFileNames.isNotEmpty()){ if(isNotEmpty()) append("\n"); append("📎 "+attachedFileNames.joinToString(", ")) }
            },true, image?.let{decodeThumbnailFromDataUrl(it)})
            input.setText("")
        }

        lastUserText=text
        setBusy(true)
        status.text="Astra думает…"

        val content=JSONArray()
        if(text.isNotBlank()) content.put(JSONObject().put("type","input_text").put("text",text))
        requestImageDataUrl?.let { content.put(JSONObject().put("type","input_image").put("image_url",it)) }
        requestFileIds.forEach { content.put(JSONObject().put("type","input_file").put("file_id",it)) }

        val reasoningObj=JSONObject().put("effort",effectiveEffort).put("mode",reasoningMode)
        if(summary!="null") reasoningObj.put("summary",summary)

        val textObj=JSONObject().put("verbosity",verbosity)

        val inputArr=JSONArray()
        configUpdateEffort?.let{ newEffort->
            inputArr.put(JSONObject().put("type","configuration_update").put("reasoning",JSONObject().put("effort",newEffort)))
            runOnUiThread{toolLabel.text="⚙ мышление: $effectiveEffort → $newEffort (эта реплика)"}
        }
        inputArr.put(JSONObject().put("role","user").put("content",content))

        val body=JSONObject()
            .put("model",model)
            .put("input",inputArr)
            .put("stream",true)
            .put("store",true)
            .put("reasoning",reasoningObj)
            .put("max_output_tokens",maxOut)
            .put("parallel_tool_calls",prefs.getBoolean("parallel_tools",true))

        prefs.getString("instructions","")?.takeIf{it.isNotBlank()}?.let { body.put("instructions",it) }
        prefs.getString("cache_key","")?.takeIf{it.isNotBlank()}?.let { body.put("prompt_cache_key",it) }
        currentResponseId?.let { body.put("previous_response_id",it) }

        when(prefs.getString("text_format","text")){
            "json_object" -> textObj.put("format",JSONObject().put("type","json_object"))
            "json_schema" -> {
                val schemaText=prefs.getString("json_schema","")?.trim().orEmpty()
                if(schemaText.isNotBlank()){
                    try {
                        val schema=JSONObject(schemaText)
                        textObj.put("format",
                            JSONObject().put("type","json_schema")
                                .put("name","astra_response")
                                .put("strict",true)
                                .put("schema",schema))
                    } catch(_:Exception){
                        runOnUiThread{status.text="Ошибка: JSON Schema недействительна"}
                    }
                } else {
                    runOnUiThread{status.text="Укажите JSON Schema в настройках для этого формата"}
                }
            }
        }
        body.put("text",textObj)

        val tools=JSONArray()
        if(prefs.getBoolean("web",true)) tools.put(JSONObject().put("type","web_search_preview"))
        if(prefs.getBoolean("file_search",false)){
            val vs=prefs.getString("vector_store","")?.trim().orEmpty()
            if(vs.isNotBlank()) tools.put(JSONObject().put("type","file_search").put("vector_store_ids",JSONArray().put(vs)).put("max_num_results",20))
        }
        if(prefs.getBoolean("code_interpreter",false)){
            val c=JSONObject().put("type","auto").put("memory_limit","4g")
            if(attachedFileIds.isNotEmpty()) {
                val ids = JSONArray()
                attachedFileIds.forEach { ids.put(it) }
                c.put("file_ids", ids)
            }
            tools.put(JSONObject().put("type","code_interpreter").put("container",c))
        }
        if(prefs.getBoolean("image_generation",false)) tools.put(JSONObject().put("type","image_generation"))
        if(tools.length()>0) body.put("tools",tools)

        val include=JSONArray()
        if(prefs.getBoolean("web",true)) include.put("web_search_call.action.sources")
        if(prefs.getBoolean("file_search",false)) include.put("file_search_call.results")
        if(prefs.getBoolean("code_interpreter",false)) include.put("code_interpreter_call.outputs")
        include.put("computer_call_output.output.image_url")
        body.put("include",include)

        pendingImageDataUrl=null
        attachedFileIds.clear()
        attachedFileNames.clear()
        toolLabel.text=""
        refreshAttachChips()

        // Create the streaming response bubble on the Android main/UI thread.
        // sendMessage() is invoked by the button listener, so this runs on main.
        val assistantView = addBubble("Astra","",false)

        val req=Request.Builder()
            .url("https://api.openai.com/v1/responses")
            .addHeader("Authorization","Bearer $key")
            .addHeader("Content-Type","application/json")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        currentCall=client.newCall(req)
        val call=currentCall!!

        executor.execute {
            try {
                call.execute().use { response ->
                    if(!response.isSuccessful) throw IOException("HTTP ${response.code}: ${response.body?.string().orEmpty()}")
                    val reader=response.body?.byteStream()?.bufferedReader(Charsets.UTF_8) ?: throw IOException("Пустой ответ")
                    val full=StringBuilder()
                    var newId:String?=null
                    val toolItems=mutableListOf<String>()

                    reader.forEachLine { line ->
                        if(!line.startsWith("data: ")) return@forEachLine
                        val data=line.removePrefix("data: ").trim()
                        if(data=="[DONE]") return@forEachLine
                        try {
                            val ev=JSONObject(data)
                            when(ev.optString("type")){
                                "response.output_text.delta" -> {
                                    val delta=ev.optString("delta")
                                    if(delta.isNotEmpty()){
                                        full.append(delta)
                                        runOnUiThread{
                                            assistantView.text=markdown(full.toString())
                                            scroll.post{scroll.fullScroll(View.FOCUS_DOWN)}
                                        }
                                    }
                                }
                                "response.web_search_call.completed" -> toolItems.add("🌐 Web Search")
                                "response.file_search_call.completed" -> toolItems.add("📚 File Search")
                                "response.code_interpreter_call.completed" -> toolItems.add("🐍 Code Interpreter")
                                "response.image_generation_call.completed" -> toolItems.add("🎨 Image Generation")
                                "response.computer_call.completed" -> toolItems.add("🖥 Computer Use")
                                "response.completed" -> {
                                    val r=ev.optJSONObject("response")
                                    newId=r?.optString("id")
                                    parseTools(r?.optJSONArray("output"),toolItems)
                                    val usage=r?.optJSONObject("usage")
                                    runOnUiThread{
                                        status.text=if(usage!=null){
                                            val inTok=usage.optInt("input_tokens",0)
                                            val outTok=usage.optInt("output_tokens",0)
                                            val cachedTok=usage.optJSONObject("input_tokens_details")?.optInt("cached_tokens",0) ?: 0
                                            val reasoningTok=usage.optJSONObject("output_tokens_details")?.optInt("reasoning_tokens",0) ?: 0
                                            val cost=estimateCost(inTok,cachedTok,outTok)
                                            val reasoningPart=if(reasoningTok>0)" (${fmtTokens(reasoningTok)} думал)" else ""
                                            "Готово · ${fmtTokens(inTok)} in · ${fmtTokens(outTok)} out$reasoningPart · ≈\$%.4f".format(cost)
                                        } else "Готово"
                                        if(toolItems.isNotEmpty()) toolLabel.text=toolItems.distinct().joinToString("  ")
                                    }
                                }
                            }
                        } catch(_:Exception){}
                    }

                    currentResponseId=newId ?: currentResponseId
                    val answer=full.toString().ifBlank{"Готово. Ответ не содержит текста."}

                    // Mutate chat state and persist it on the main/UI thread as well.
                    runOnUiThread{
                        val userMessage=JSONObject()
                            .put("role","user")
                            .put("text",text)
                        val fileIds=JSONArray(); requestFileIds.forEach { fileIds.put(it) }
                        val fileNames=JSONArray(); requestFileNames.forEach { fileNames.put(it) }
                        if(fileIds.length()>0) userMessage.put("file_ids",fileIds)
                        if(fileNames.length()>0) userMessage.put("file_names",fileNames)
                        requestImageDataUrl?.let { dataUrl ->
                            saveImageDataUrl(dataUrl)?.let { userMessage.put("image_path",it) }
                        }
                        chat.add(userMessage)
                        chat.add(JSONObject().put("role","assistant").put("text",answer).put("response_id",newId ?: JSONObject.NULL))
                        persistCurrentChat()
                        setBusy(false)
                        if(status.text=="Astra думает…") status.text="Готово"
                    }
                }
            } catch(e:Exception) {
                if(call.isCanceled()){
                    runOnUiThread{setBusy(false);status.text="Остановлено"}
                } else {
                    runOnUiThread{
                        setBusy(false)
                        status.text="Ошибка"
                        addBubble("Ошибка",e.message ?: "Неизвестная ошибка",false)
                    }
                }
            }
        }
    }

    private fun parseTools(output:JSONArray?, items:MutableList<String>) {
        if(output==null)return
        for(i in 0 until output.length()){
            val o=output.optJSONObject(i)?:continue
            when(o.optString("type")){
                "web_search_call" -> items.add("🌐 Web Search")
                "file_search_call" -> items.add("📚 File Search")
                "code_interpreter_call" -> items.add("🐍 Code Interpreter")
                "image_generation_call" -> items.add("🎨 Image Generation")
                "computer_call" -> items.add("🖥 Computer Use")
            }
        }
    }

    private fun showToolDetails() {
        if(toolLabel.text.isNullOrBlank()) return
        AlertDialog.Builder(this)
            .setTitle("Инструменты")
            .setMessage(toolLabel.text)
            .setPositiveButton("OK",null).show()
    }

    // ---------- attachments ----------
    private fun chip(label:String,onRemove:()->Unit):View{
        val c=LinearLayout(this).apply{
            orientation=LinearLayout.HORIZONTAL
            gravity=Gravity.CENTER_VERTICAL
            setPadding(dp(10),dp(4),dp(2),dp(4))
            setBackgroundColor(Color.rgb(38,40,46))
        }
        val t=TextView(this).apply{
            this.text=label;textSize=12f;setTextColor(Color.rgb(210,214,222))
            isSingleLine=true;ellipsize=TextUtils.TruncateAt.END;maxWidth=dp(150)
        }
        c.addView(t)
        val x=TextView(this).apply{
            this.text="✕";textSize=13f;setTextColor(Color.rgb(210,120,120))
            setPadding(dp(10),dp(6),dp(8),dp(6))
            setOnClickListener{onRemove()}
        }
        c.addView(x)
        return c
    }
    private fun refreshAttachChips(){
        attachRow.removeAllViews()
        pendingImageDataUrl?.let{
            attachRow.addView(chip("🖼 Изображение"){pendingImageDataUrl=null;refreshAttachChips()},
                LinearLayout.LayoutParams(-2,-2).apply{rightMargin=dp(6)})
        }
        attachedFileNames.forEachIndexed{i,name->
            attachRow.addView(chip("📎 $name"){
                attachedFileIds.removeAt(i);attachedFileNames.removeAt(i);refreshAttachChips()
            }, LinearLayout.LayoutParams(-2,-2).apply{rightMargin=dp(6)})
        }
        attachScroll.visibility=if(attachRow.childCount>0)View.VISIBLE else View.GONE
    }
    private fun chooseAny() {
        val i=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{
            type="*/*"; addCategory(Intent.CATEGORY_OPENABLE); putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true)
        }
        startActivityForResult(i,pickAny)
    }
    private fun chooseImage() {
        val i=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{
            type="image/*"; addCategory(Intent.CATEGORY_OPENABLE)
        }
        startActivityForResult(i,pickImage)
    }
    private fun chooseVoice() {
        val i=Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply{
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Говорите…")
        }
        if(i.resolveActivity(packageManager)!=null){
            try{ startActivityForResult(i,pickVoice) }
            catch(e:Exception){ status.text="Голосовой ввод недоступен: ${e.message}" }
        } else {
            status.text="На устройстве не найден сервис распознавания речи"
        }
    }
    // ---------- vector store management ----------
    private fun vectorStoreId():String? = prefs.getString("vector_store","")?.trim()?.takeIf{it.isNotBlank()}

    private fun showVectorStoreManager(){
        val container=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL; setPadding(dp(20),dp(10),dp(20),dp(10))}
        val statusLine=TextView(this).apply{this.text="Загрузка…";setTextColor(Color.GRAY);textSize=12f}
        val listArea=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        container.addView(statusLine)
        container.addView(listArea)
        vsListArea=listArea
        vsStatusLine=statusLine

        val dialog=AlertDialog.Builder(this)
            .setTitle("Файлы Vector Store")
            .setView(ScrollView(this).apply{addView(container)})
            .setPositiveButton("+ Добавить файл",null)
            .setNegativeButton("Закрыть",null)
            .create()
        dialog.setOnShowListener{
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener{
                val existing=vectorStoreId()
                if(existing==null){
                    statusLine.text="Создаю Vector Store…"
                    executor.execute{
                        try{
                            val newId=createVectorStore("Astra Files")
                            prefs.edit().putString("vector_store",newId).apply()
                            runOnUiThread{ pickFileForVectorStore() }
                        }catch(e:Exception){ runOnUiThread{statusLine.text="Ошибка создания: ${e.message}"} }
                    }
                } else pickFileForVectorStore()
            }
        }
        dialog.show()
        val vsId=vectorStoreId()
        if(vsId==null) statusLine.text="Vector Store ещё не создан — нажмите «Добавить файл»"
        else renderVectorStoreList(vsId)
    }

    private fun renderVectorStoreList(vsId:String){
        vsStatusLine?.text="Загрузка списка файлов…"
        executor.execute{
            try{
                val files=listVectorStoreFiles(vsId)
                runOnUiThread{
                    val area=vsListArea ?: return@runOnUiThread
                    area.removeAllViews()
                    if(files.isEmpty()){
                        area.addView(TextView(this).apply{this.text="Файлов пока нет";setTextColor(Color.GRAY);textSize=13f})
                    }
                    files.forEach{(fid,name)->
                        val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(0,dp(6),0,dp(6))}
                        row.addView(TextView(this).apply{this.text=name;textSize=14f;setTextColor(Color.WHITE)}, LinearLayout.LayoutParams(0,-2,1f))
                        row.addView(TextView(this).apply{
                            this.text="✕";setTextColor(Color.rgb(210,120,120));setPadding(dp(12),dp(6),dp(6),dp(6))
                            setOnClickListener{
                                executor.execute{
                                    try{ removeFileFromVectorStore(vsId,fid) }catch(_:Exception){}
                                    renderVectorStoreList(vsId)
                                }
                            }
                        })
                        area.addView(row)
                    }
                    vsStatusLine?.text="Vector Store: $vsId"
                }
            }catch(e:Exception){
                runOnUiThread{ vsStatusLine?.text="Ошибка загрузки: ${e.message}" }
            }
        }
    }

    private fun pickFileForVectorStore(){
        val i=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="*/*"}
        startActivityForResult(i,pickVectorStoreFile)
    }

    private fun listVectorStoreFiles(vsId:String):List<Pair<String,String>>{
        val key=secure.getApiKey()
        val req=Request.Builder().url("https://api.openai.com/v1/vector_stores/$vsId/files?limit=100")
            .addHeader("Authorization","Bearer $key").get().build()
        client.newCall(req).execute().use{resp->
            val raw=resp.body?.string().orEmpty()
            if(!resp.isSuccessful)throw IOException("HTTP ${resp.code}: $raw")
            val arr=JSONObject(raw).optJSONArray("data") ?: JSONArray()
            val out=mutableListOf<Pair<String,String>>()
            for(i in 0 until arr.length()){
                val fid=arr.optJSONObject(i)?.optString("id") ?: continue
                val name=try{ fetchFileName(fid) }catch(_:Exception){ fid }
                out.add(fid to name)
            }
            return out
        }
    }
    private fun fetchFileName(fileId:String):String{
        val key=secure.getApiKey()
        val req=Request.Builder().url("https://api.openai.com/v1/files/$fileId")
            .addHeader("Authorization","Bearer $key").get().build()
        client.newCall(req).execute().use{resp->
            val raw=resp.body?.string().orEmpty()
            if(!resp.isSuccessful)throw IOException("HTTP ${resp.code}")
            return JSONObject(raw).optString("filename",fileId)
        }
    }
    private fun createVectorStore(name:String):String{
        val key=secure.getApiKey()
        val reqBody=JSONObject().put("name",name).toString().toRequestBody("application/json".toMediaType())
        val req=Request.Builder().url("https://api.openai.com/v1/vector_stores")
            .addHeader("Authorization","Bearer $key").post(reqBody).build()
        client.newCall(req).execute().use{resp->
            val raw=resp.body?.string().orEmpty()
            if(!resp.isSuccessful)throw IOException("HTTP ${resp.code}: $raw")
            return JSONObject(raw).getString("id")
        }
    }
    private fun attachFileToVectorStore(vsId:String, fileId:String){
        val key=secure.getApiKey()
        val reqBody=JSONObject().put("file_id",fileId).toString().toRequestBody("application/json".toMediaType())
        val req=Request.Builder().url("https://api.openai.com/v1/vector_stores/$vsId/files")
            .addHeader("Authorization","Bearer $key").post(reqBody).build()
        client.newCall(req).execute().use{resp->
            if(!resp.isSuccessful)throw IOException("HTTP ${resp.code}: ${resp.body?.string()}")
        }
    }
    private fun removeFileFromVectorStore(vsId:String, fileId:String){
        val key=secure.getApiKey()
        val req=Request.Builder().url("https://api.openai.com/v1/vector_stores/$vsId/files/$fileId")
            .addHeader("Authorization","Bearer $key").delete().build()
        client.newCall(req).execute().use{resp->
            if(!resp.isSuccessful)throw IOException("HTTP ${resp.code}: ${resp.body?.string()}")
        }
    }
    private fun uploadFileForVectorStore(uri:Uri):Pair<String,String>{
        val key=secure.getApiKey()
        val temp=File(cacheDir,"upload_${System.nanoTime()}")
        contentResolver.openInputStream(uri).use{input->temp.outputStream().use{out->input!!.copyTo(out)}}
        val mime=contentResolver.getType(uri) ?: "application/octet-stream"
        val name=queryName(uri) ?: "attachment"
        val body=MultipartBody.Builder().setType(MultipartBody.FORM)
            .addFormDataPart("purpose","assistants")
            .addFormDataPart("file",name,temp.asRequestBody(mime.toMediaType()))
            .build()
        val req=Request.Builder().url("https://api.openai.com/v1/files").addHeader("Authorization","Bearer $key").post(body).build()
        try{
            client.newCall(req).execute().use{resp->
                val raw=resp.body?.string().orEmpty()
                if(!resp.isSuccessful)throw IOException("HTTP ${resp.code}: $raw")
                return JSONObject(raw).getString("id") to name
            }
        }finally{temp.delete()}
    }

    override fun onActivityResult(r:Int,c:Int,d:Intent?){
        super.onActivityResult(r,c,d)
        if(c!=RESULT_OK || d==null)return
        if(r==pickVoice){
            val results=d.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val heard=results?.firstOrNull()
            if(!heard.isNullOrBlank()){
                val current=input.text.toString()
                input.setText(if(current.isBlank()) heard else "$current $heard")
                input.setSelection(input.text.length)
            }
            return
        }
        if(r==pickVectorStoreFile){
            val uri=d.data ?: return
            val vsId=vectorStoreId()
            if(vsId==null){ vsStatusLine?.text="Сначала создайте Vector Store"; return }
            vsStatusLine?.text="Загружаю файл…"
            executor.execute{
                try{
                    val (fileId,_)=uploadFileForVectorStore(uri)
                    attachFileToVectorStore(vsId,fileId)
                    runOnUiThread{ renderVectorStoreList(vsId) }
                }catch(e:Exception){
                    runOnUiThread{ vsStatusLine?.text="Ошибка: ${e.message}" }
                }
            }
            return
        }
        if(r==pickImage){
            val uri=d.data ?: return
            executor.execute{
                try{
                    val bytes=contentResolver.openInputStream(uri).use{it!!.readBytes()}
                    val url="data:${contentResolver.getType(uri) ?: "image/jpeg"};base64,"+Base64.encodeToString(bytes,Base64.NO_WRAP)
                    runOnUiThread{pendingImageDataUrl=url;refreshAttachChips()}
                }catch(e:Exception){runOnUiThread{status.text="Ошибка изображения"}}
            }
            return
        }

        val uris=mutableListOf<Uri>()
        d.data?.let{uris.add(it)}
        d.clipData?.let{clip->for(i in 0 until clip.itemCount)uris.add(clip.getItemAt(i).uri)}
        uris.distinct().forEach{uri->
            val name=queryName(uri) ?: "attachment"
            val ext=name.substringAfterLast('.',"").lowercase()
            if(ext=="zip"){
                handleZipAttachment(uri,name)
                return@forEach
            }
            if(ext.isBlank() || ext !in supportedFileExtensions){
                runOnUiThread{status.text="Формат .$ext не поддерживается для чтения файла: $name"}
                return@forEach
            }
            executor.execute{
                try{
                    val (id,uploadedName)=uploadFile(uri)
                    runOnUiThread{
                        attachedFileIds.add(id)
                        attachedFileNames.add(uploadedName)
                        refreshAttachChips()
                    }
                }catch(e:Exception){runOnUiThread{status.text="Ошибка файла: ${e.message}"}}
            }
        }
    }

    private val supportedFileExtensions = setOf(
        "art","bat","brf","c","cls","css","csv","diff","doc","docx","dot","eml","epub","es",
        "h","hs","htm","html","hwp","hwpx","ics","ifb","java","js","json","keynote","ksh",
        "ltx","mail","markdown","md","mht","mhtml","mjs","msg","nws","odp","ods","odt","otp",
        "ots","pages","patch","pdf","pl","pm","pot","potm","potx","ppa","pps","ppsm","ppsx",
        "ppt","pptm","pptx","pwz","py","rst","rtf","scala","sh","shtml","srt","sty","svg",
        "svgz","tex","text","txt","tsv","vcf","vtt","wiz","xla","xlb","xlc","xlm","xls","xlsx",
        "xlt","xlw","xml","yaml","yml"
    )

    private fun handleZipAttachment(uri:Uri, zipName:String){
        runOnUiThread{status.text="Распаковываю $zipName…"}
        executor.execute{
            var uploaded=0
            var skipped=0
            try{
                contentResolver.openInputStream(uri)?.use{stream->
                    java.util.zip.ZipInputStream(stream).use{zin->
                        var entry=zin.nextEntry
                        while(entry!=null){
                            val entryName=entry.name.substringAfterLast('/')
                            val ext=entryName.substringAfterLast('.',"").lowercase()
                            if(!entry.isDirectory && entryName.isNotBlank() && !entryName.startsWith(".") && ext in supportedFileExtensions){
                                val bytes=zin.readBytes()
                                if(bytes.isNotEmpty() && bytes.size<25_000_000){
                                    try{
                                        val (id,uploadedName)=uploadFileBytes(bytes,entryName)
                                        runOnUiThread{
                                            attachedFileIds.add(id)
                                            attachedFileNames.add(uploadedName)
                                            refreshAttachChips()
                                        }
                                        uploaded++
                                    }catch(_:Exception){ skipped++ }
                                } else skipped++
                            } else if(!entry.isDirectory) skipped++
                            zin.closeEntry()
                            entry=zin.nextEntry
                        }
                    }
                }
                runOnUiThread{
                    status.text="Из $zipName загружено файлов: $uploaded"+(if(skipped>0)", пропущено (неподдерживаемый формат/пусто): $skipped" else "")
                }
            }catch(e:Exception){
                runOnUiThread{status.text="Ошибка распаковки $zipName: ${e.message}"}
            }
        }
    }

    private fun uploadFileBytes(bytes:ByteArray, name:String):Pair<String,String>{
        val key=secure.getApiKey()
        val temp=File(cacheDir,"upload_${System.nanoTime()}")
        temp.writeBytes(bytes)
        try{
            val body=MultipartBody.Builder().setType(MultipartBody.FORM)
                .addFormDataPart("purpose","user_data")
                .addFormDataPart("file",name,temp.asRequestBody("application/octet-stream".toMediaType()))
                .build()
            val req=Request.Builder().url("https://api.openai.com/v1/files").addHeader("Authorization","Bearer $key").post(body).build()
            client.newCall(req).execute().use{resp->
                val raw=resp.body?.string().orEmpty()
                if(!resp.isSuccessful)throw IOException("HTTP ${resp.code}: $raw")
                return JSONObject(raw).getString("id") to name
            }
        }finally{temp.delete()}
    }

    private fun uploadFile(uri:Uri):Pair<String,String>{
        val key=secure.getApiKey()
        val temp=File(cacheDir,"upload_${System.nanoTime()}")
        contentResolver.openInputStream(uri).use{input->temp.outputStream().use{out->input!!.copyTo(out)}}
        val mime=contentResolver.getType(uri) ?: "application/octet-stream"
        val name=queryName(uri) ?: "attachment"
        val body=MultipartBody.Builder().setType(MultipartBody.FORM)
            .addFormDataPart("purpose","user_data")
            .addFormDataPart("file",name,temp.asRequestBody(mime.toMediaType()))
            .build()
        val req=Request.Builder().url("https://api.openai.com/v1/files").addHeader("Authorization","Bearer $key").post(body).build()
        try{
            client.newCall(req).execute().use{resp->
                val raw=resp.body?.string().orEmpty()
                if(!resp.isSuccessful)throw IOException("HTTP ${resp.code}: $raw")
                return JSONObject(raw).getString("id") to name
            }
        }finally{temp.delete()}
    }
    private fun queryName(uri:Uri):String?{
        var n:String?=null
        contentResolver.query(uri,arrayOf("_display_name"),null,null,null)?.use{c->if(c.moveToFirst())n=c.getString(0)}
        return n
    }

    // ---------- storage ----------
    private fun ensureChatStore(){
        if(prefs.getString("chat_store",null)==null){
            prefs.edit().putString("chat_store","[]").apply()
        }
        if(prefs.getString("current_chat",null)==null){
            val id = "chat_" + System.currentTimeMillis()
            prefs.edit().putString("current_chat",id).apply()
            ensureChatEntry(id,"Новый чат")
        } else {
            val id = currentChatId()
            if(id.isNotBlank()) ensureChatEntry(id,currentChatTitleSafe())
        }
    }

    private fun currentChatTitleSafe(): String {
        val id = prefs.getString("current_chat","") ?: ""
        return loadAllChats().firstOrNull { it.optString("id")==id }?.optString("title") ?: "Новый чат"
    }
    private fun currentChatId()=prefs.getString("current_chat","") ?: ""
    private fun currentChatTitle():String{
        val id=currentChatId()
        return loadAllChats().firstOrNull{it.optString("id")==id}?.optString("title") ?: "Новый чат"
    }
    private fun currentChatObj():JSONObject{
        val all=loadAllChats().toMutableList()
        val id=currentChatId()
        return all.firstOrNull{it.optString("id")==id} ?: JSONObject().put("id",id).put("title","Новый чат")
    }
    private fun ensureChatEntry(id:String,titleText:String){
        val all=loadAllChats().toMutableList()
        if(all.none{it.optString("id")==id})all.add(JSONObject().put("id",id).put("title",titleText).put("messages",JSONArray()).put("response_id",JSONObject.NULL))
        saveAllChats(all)
    }
    private fun loadAllChats():List<JSONObject>{
        val raw=prefs.getString("chat_store","[]") ?: "[]"
        val arr=try{JSONArray(raw)}catch(_:Exception){JSONArray()}
        val out=mutableListOf<JSONObject>()
        for(i in 0 until arr.length()) out.add(arr.optJSONObject(i) ?: JSONObject())
        return out
    }
    private fun saveAllChats(list:List<JSONObject>){
        val arr=JSONArray();list.forEach{arr.put(it)}
        prefs.edit().putString("chat_store",arr.toString()).apply()
    }
    private fun persistCurrentChat(){
        val id=currentChatId()
        if(id.isBlank())return
        val all=loadAllChats().toMutableList()
        val c=all.firstOrNull{it.optString("id")==id} ?: JSONObject().put("id",id)
        if(chat.isNotEmpty() && c.optString("title")=="Новый чат"){
            val first=chat.firstOrNull{it.optString("role")=="user"}?.optString("text").orEmpty()
            c.put("title",first.take(36).ifBlank{"Новый чат"})
        }
        val arr=JSONArray();chat.forEach{arr.put(it)}
        c.put("messages",arr)
        c.put("response_id",currentResponseId ?: JSONObject.NULL)
        c.put("baseline_effort",baselineEffort ?: JSONObject.NULL)
        if(all.none{it.optString("id")==id})all.add(c)
        saveAllChats(all)
        title.text=c.optString("title","Новый чат")
    }
    private fun restoreCurrentChat(){
        messages.removeAllViews()
        chat.clear()
        attachedFileIds.clear()
        attachedFileNames.clear()
        pendingImageDataUrl=null
        refreshAttachChips()
        val c=currentChatObj()
        title.text=c.optString("title","Новый чат")
        currentResponseId=c.optString("response_id").takeIf{it.isNotBlank() && it!="null"}
        baselineEffort=c.optString("baseline_effort").takeIf{it.isNotBlank() && it!="null"}
        val arr=c.optJSONArray("messages") ?: JSONArray()
        for(i in 0 until arr.length()){
            val m=arr.optJSONObject(i)?:continue
            val role=m.optString("role")
            val t=m.optString("text")
            chat.add(m)
            val imgPath=m.optString("image_path").takeIf{it.isNotBlank()}
            addBubble(if(role=="user")"Ты" else "Astra",t,role=="user",imgPath?.let{decodeThumbnailFromFile(it)})
            if(role=="user")lastUserText=t
        }
        toolLabel.text=""
        status.text="Готово"
    }

    private fun editMessage(idx:Int){
        if(idx<0 || idx>=chat.size) return
        if(chat[idx].optString("role")!="user") return
        currentCall?.cancel()
        val message=chat[idx]
        val text=message.optString("text")

        // Restore attachments from the original user message into the composer.
        attachedFileIds.clear()
        attachedFileNames.clear()
        pendingImageDataUrl=null
        message.optJSONArray("file_ids")?.let { arr ->
            for(i in 0 until arr.length()) attachedFileIds.add(arr.optString(i))
        }
        message.optJSONArray("file_names")?.let { arr ->
            for(i in 0 until arr.length()) attachedFileNames.add(arr.optString(i))
        }
        message.optString("image_path").takeIf { it.isNotBlank() }?.let { path ->
            loadImageDataUrl(path)?.let { pendingImageDataUrl=it }
        }

        while(chat.size>idx) chat.removeAt(chat.size-1)
        while(messages.childCount>idx) messages.removeViewAt(messages.childCount-1)
        currentResponseId=chat.lastOrNull{it.optString("role")=="assistant"}
            ?.optString("response_id")?.takeIf{it.isNotBlank() && it!="null"}
        if(chat.isEmpty()) baselineEffort=null
        persistCurrentChat()
        input.setText(text)
        input.setSelection(input.text.length)
        refreshAttachChips()
        input.requestFocus()
        setBusy(false)
        status.text="Отредактируйте и отправьте снова"
    }

    private fun restoreLastUserAttachments(){
        val last=chat.lastOrNull{it.optString("role")=="user"} ?: return
        attachedFileIds.clear()
        attachedFileNames.clear()
        pendingImageDataUrl=null
        last.optJSONArray("file_ids")?.let { arr ->
            for(i in 0 until arr.length()) attachedFileIds.add(arr.optString(i))
        }
        last.optJSONArray("file_names")?.let { arr ->
            for(i in 0 until arr.length()) attachedFileNames.add(arr.optString(i))
        }
        last.optString("image_path").takeIf { it.isNotBlank() }?.let { path ->
            loadImageDataUrl(path)?.let { pendingImageDataUrl=it }
        }
    }

    private fun decodeSampledBitmap(bytes:ByteArray, maxDim:Int=640): Bitmap?{
        return try{
            val bounds=BitmapFactory.Options().apply{inJustDecodeBounds=true}
            BitmapFactory.decodeByteArray(bytes,0,bytes.size,bounds)
            var sample=1
            while(bounds.outWidth/sample>maxDim || bounds.outHeight/sample>maxDim) sample*=2
            val opts=BitmapFactory.Options().apply{inSampleSize=sample}
            BitmapFactory.decodeByteArray(bytes,0,bytes.size,opts)
        }catch(_:Exception){null}
    }
    private fun decodeThumbnailFromDataUrl(dataUrl:String): Bitmap?{
        val comma=dataUrl.indexOf(',')
        if(comma<0) return null
        return try{ decodeSampledBitmap(Base64.decode(dataUrl.substring(comma+1),Base64.NO_WRAP)) }catch(_:Exception){null}
    }
    private fun decodeThumbnailFromFile(path:String): Bitmap?{
        return try{ decodeSampledBitmap(File(path).readBytes()) }catch(_:Exception){null}
    }

    private fun saveImageDataUrl(dataUrl:String):String?{
        return try{
            val comma=dataUrl.indexOf(',')
            if(comma<0) return null
            val meta=dataUrl.substring(5,comma)
            val bytes=Base64.decode(dataUrl.substring(comma+1),Base64.NO_WRAP)
            val ext=when{
                meta.contains("png",true)->"png"
                meta.contains("webp",true)->"webp"
                meta.contains("gif",true)->"gif"
                else->"jpg"
            }
            val dir=File(filesDir,"attachments").apply{mkdirs()}
            val file=File(dir,"img_${System.currentTimeMillis()}_${System.nanoTime()}.$ext")
            file.writeBytes(bytes)
            file.absolutePath
        }catch(_:Exception){null}
    }

    private fun loadImageDataUrl(path:String):String?{
        return try{
            val file=File(path)
            if(!file.exists()) return null
            val mime=when(file.extension.lowercase()){
                "png"->"image/png"
                "webp"->"image/webp"
                "gif"->"image/gif"
                else->"image/jpeg"
            }
            "data:$mime;base64,"+Base64.encodeToString(file.readBytes(),Base64.NO_WRAP)
        }catch(_:Exception){null}
    }

    // ---------- utils ----------
    private fun setBusy(v:Boolean){send.isEnabled=!v;stop.visibility=if(v)View.VISIBLE else View.GONE}
    private fun addBubble(label:String,text:String,user:Boolean,imageBitmap:Bitmap?=null):TextView{
        val card=LinearLayout(this).apply{
            orientation=LinearLayout.VERTICAL
            setPadding(dp(13),dp(10),dp(13),dp(10))
            setBackgroundColor(if(user)Color.rgb(31,40,54) else Color.rgb(28,29,34))
        }
        val who=TextView(this).apply{this.text=label;textSize=12f;setTextColor(if(user)Color.rgb(160,195,245) else Color.rgb(190,195,205));setTypeface(null,Typeface.BOLD)}
        card.addView(who)
        imageBitmap?.let{ bmp->
            card.addView(ImageView(this).apply{
                setImageBitmap(bmp)
                setAdjustViewBounds(true)
                scaleType=ImageView.ScaleType.FIT_CENTER
                setPadding(0,dp(6),0,0)
            }, LinearLayout.LayoutParams(-1,dp(180)))
        }
        val body=TextView(this).apply{
            this.text=markdown(text);textSize=16f;setTextColor(Color.WHITE);setTextIsSelectable(true);setPadding(0,dp(5),0,0)
        }
        card.addView(body)
        val longPress=View.OnLongClickListener{
            val items=if(user)arrayOf("Копировать","Редактировать") else arrayOf("Копировать","Повторить последний запрос")
            AlertDialog.Builder(this).setItems(items){_,which->
                when(which){
                    0->{
                        val cm=getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                        cm.setPrimaryClip(ClipData.newPlainText("Astra",text));status.text="Скопировано"
                    }
                    1->if(user) editMessage(messages.indexOfChild(card)) else sendMessage(true)
                }
            }.show();true
        }
        card.setOnLongClickListener(longPress)
        body.setOnLongClickListener(longPress)
        who.setOnLongClickListener(longPress)
        messages.addView(card,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(8)})
        scroll.post{scroll.fullScroll(View.FOCUS_DOWN)}
        return body
    }
    private fun markdown(s:String):CharSequence{
        val sp=SpannableString(s)
        Regex("\\*\\*([^*]+)\\*\\*").findAll(s).forEach{sp.setSpan(StyleSpan(Typeface.BOLD),it.range.first,it.range.last+1,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)}
        Regex("`([^`]+)`").findAll(s).forEach{sp.setSpan(TypefaceSpan("monospace"),it.range.first,it.range.last+1,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)}
        return sp
    }
    private fun button(t:String,a:()->Unit)=Button(this).apply{text=t;textSize=16f;minWidth=0;minimumWidth=0;setPadding(dp(7),0,dp(7),0);setOnClickListener{a()}}
    private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()

    private class SecureStore(private val context:Context){
        private val prefs=context.getSharedPreferences("secure",Context.MODE_PRIVATE)
        private val alias="OpenAIApiChatKey"
        private fun key():SecretKey{
            val ks=KeyStore.getInstance("AndroidKeyStore").apply{load(null)}
            (ks.getKey(alias,null) as? SecretKey)?.let{return it}
            val gen=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore")
            gen.init(KeyGenParameterSpec.Builder(alias,KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).setRandomizedEncryptionRequired(true).build())
            return gen.generateKey()
        }
        fun setApiKey(v:String){
            if(v.isBlank()){prefs.edit().remove("key").apply();return}
            val c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,key())
            val p=c.iv+c.doFinal(v.toByteArray(Charsets.UTF_8))
            prefs.edit().putString("key",Base64.encodeToString(p,Base64.NO_WRAP)).apply()
        }
        fun getApiKey():String{
            return try{
                val p=Base64.decode(prefs.getString("key",null)?:return "",Base64.NO_WRAP)
                val iv=p.copyOfRange(0,12);val d=p.copyOfRange(12,p.size)
                val c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,key(),GCMParameterSpec(128,iv))
                String(c.doFinal(d),Charsets.UTF_8)
            }catch(_:Exception){""}
        }
    }
}
