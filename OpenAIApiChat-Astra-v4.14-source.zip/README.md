# OpenAI API Chat — Astra v4.14

Нативный Android-клиент для использования собственного OpenAI API key, ориентированный на GPT-6 Astra.

## Реализовано

- Чат-интерфейс в стиле ChatGPT
- несколько локально сохранённых чатов
- список чатов + переименование + удаление
- streaming через Responses API
- `previous_response_id` для продолжения контекста
- regenerate последнего пользовательского запроса
- копирование ответа
- `reasoning.effort`: low / medium / high / xhigh / max + Auto
- `configuration_update` для смены effort в стандартном режиме без изменения исходного request-level effort
- max output tokens до 128K
- developer instructions
- prompt cache key
- parallel tool calls
- `web_search` + кликабельные `url_citation`
- File Search + Vector Store ID
- загрузка документов в `/v1/files`
- input image через Files API и `file_id` без Base64 в Responses input
- Code Interpreter
- реальные `container_file_citation` + скачивание созданных файлов
- локальный кэш generated files + `FileProvider`
- карточки generated files: имя, MIME/размер, состояния downloading/ready/failed/expired
- Markdown/rich text: ссылки, bare URLs, bold, italic, strike, inline code
- структурированная модель `AstraResponseModel` для итоговых Responses
- локальная SQLite история чатов с миграцией старого `SharedPreferences` chat_store
- диагностический лог с request/response/container/file идентификаторами
- метрики reasoning effort и явная пользовательская обратная связь 👍/👎 для Auto-калибровки
- безопасный потоковый ZIP import с лимитами entry/архива/количества файлов
- экспорт TXT и сохранение generated files через Storage Access Framework
- отмена генерации и защита от устаревших async callback при смене чата
- GitHub Actions для сборки APK

## Важные ограничения

`Auto` использует детерминированный baseline по типу задачи, а после накопления минимум трёх явных оценок по task/effort может консервативно скорректировать baseline. Это не скрытая ML-модель: приложение не может автоматически измерить «качество ответа» без пользовательского сигнала.

Computer Use, MCP, Hosted Shell, Skills, Apply Patch, Programmatic Tool Calling, async tool calling и другие расширенные возможности Astra требуют отдельного исполнителя/серверной интеграции и не считаются реализованными только потому, что модель умеет возвращать соответствующий tool event.

Голосовой ввод использует отдельный Android speech intent; полноценный Realtime voice UI не является частью текстового Responses API клиента.

## Проверка API

По текущей документации OpenAI GPT-6 Astra использует model ID `gpt-6-astra`, поддерживает reasoning levels low / medium / high / xhigh / max, а также `configuration_update`. Для длинного контекста действуют отдельные тарифные множители; клиент учитывает их в приблизительной token-only оценке стоимости.

Для Web Search новый клиент использует `web_search`, а не устаревающий `web_search_preview`. Для Code Interpreter generated files обрабатываются как структурированные `container_file_citation`, после чего содержимое скачивается через container files API.

## Сборка

В проекте нет Gradle wrapper. Для CI используется JDK 17, Gradle 8.9 и Android SDK 35 через `.github/workflows/build-apk.yml`.

Локальная статическая проверка v4.14 включает проверку синтаксических разделителей Kotlin, XML, SQLite schema, ключевых Responses API контрактов и отсутствие старого `web_search_preview`/Base64 image path.
