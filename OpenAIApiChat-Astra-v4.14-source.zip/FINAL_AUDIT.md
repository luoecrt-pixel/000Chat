# FINAL AUDIT — Astra v4.14

## Claude v4.13 changes re-checked

The uploaded v4.13 source archive was re-extracted and checked against its implementation. The following claims are supported by the source and are retained in v4.14:

- `container_file_citation`: extracted from Responses output and downloaded through the container file content endpoint.
- `url_citation`: extracted and rendered as clickable sources.
- delete-current-chat: direct DB deletion avoids routing through the old `newChat()` persistence path.
- export: `openOutputStream(...) == null` is treated as an error before success is shown.
- async race protection: v4.13 already tied callbacks to chat ID; v4.14 adds a monotonically increasing generation token as a second guard.
- `web_search_preview` → `web_search`.

Two statements from the earlier audit were corrected during this re-check:

1. v4.13 already had a 25 MB limit for a single ZIP entry. The real remaining issue was that the entry was read before the limit was enforced safely; v4.14 switches ZIP extraction to bounded streaming and adds total-uncompressed/entry-count budgets.
2. v4.13 preserves the uploaded filename in the normal multipart file upload path, so no filename-loss fix was necessary.

## v4.14 implemented fixes

### Responses / rendering

- `AstraResponseModel` now represents response id, request id, text, annotations, tools, usage, status and error.
- `RichTextRenderer` accepts the structured model directly.
- Markdown links and bare HTTP(S) URLs are clickable.
- `url_citation` spans are applied using API indices.
- `container_file_citation` is treated as a file object, not as a `sandbox:/` URL.

### Generated files

- Download uses `GET /v1/containers/{container_id}/files/{file_id}/content`.
- Download is streamed with a 64 KiB buffer.
- Local generated-file cache uses a safe `FileProvider` content URI.
- States: DOWNLOADING / READY / FAILED / EXPIRED.
- READY files expose Open / Save / Share.
- 404/410 marks the file EXPIRED instead of offering a useless retry loop.
- File state is also persisted directly in SQLite, so an off-screen download completion is not lost when the user changes chats.

### ZIP safety

- per-entry uncompressed budget: 25 MB
- archive-wide uncompressed budget: 200 MB
- max entries: 100
- supported entries are streamed to temporary files
- unsupported entries are also drained in bounded streaming, so they count toward the archive budget
- no `readBytes()` is used by the ZIP extraction path

### Images

- picked images are copied to app-private storage with a 50 MB local limit
- Images are uploaded through Files API with `purpose=vision`
- Responses input uses `input_image` + `file_id`, avoiding Base64/Data URL payloads
- thumbnails use bounds/sample decoding and RGB_565 to reduce bitmap memory pressure

### Chat persistence and race handling

- chat history migrated from the single JSON `SharedPreferences` blob to SQLite
- current DB schema is version 5 with one-time migrations
- generation token + chat ID prevent stale callbacks from mutating another chat
- deleting the current chat does not re-persist the removed chat
- partial `response.incomplete` output is persisted as incomplete instead of being mislabeled as a successful completion
- `response.failed` is surfaced as an error

### Auto effort / diagnostics

- every request records effort preference, effective effort, task class, latency, token counts and success/failure
- assistant messages expose explicit 👍/👎 feedback
- with enough feedback, Auto can conservatively adjust one reasoning tier from the lexical baseline for the same task class
- diagnostic log tracks request/response/container/file IDs without storing the API key

### Input file guard

- normal Responses `input_file` uploads are checked against a 50 MB per-file client limit before sending
- copying from a content URI is streamed and aborts when the limit is exceeded

## Static verification completed

- Kotlin delimiter/string scan: PASS
- XML parse: PASS
- SQLite schema syntax: PASS
- required Responses API markers: PASS
- FileProvider wiring: PASS
- stale legacy `web_search_preview`: absent
- legacy Base64 image sending path: absent
- `body.bytes()` generated-file download path: absent

## Build limitation

A full Android/Gradle build was not executed in this environment because the project does not include a Gradle wrapper and no usable local Android SDK/Gradle installation was available. The CI workflow remains the intended build path. Therefore this audit is a static/source verification, not a claim of a locally installed-and-executed APK.
