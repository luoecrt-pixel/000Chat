from pathlib import Path
import sqlite3
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
MAIN = ROOT / "app/src/main/java/com/example/openaichat/MainActivity.kt"
DB = ROOT / "app/src/main/java/com/example/openaichat/ChatDatabase.kt"
MODEL = ROOT / "app/src/main/java/com/example/openaichat/AstraResponseModel.kt"
RENDERER = ROOT / "app/src/main/java/com/example/openaichat/RichTextRenderer.kt"
GRADLE = ROOT / "app/build.gradle.kts"

assert 'versionName = "4.14"' in GRADLE.read_text()
assert 'container_file_citation' in MAIN.read_text()
assert 'url_citation' in MAIN.read_text()
assert 'put("type","web_search")' in MAIN.read_text()
assert 'configuration_update' in MAIN.read_text()
assert 'response.failed' in MAIN.read_text()
assert 'response.incomplete' in MAIN.read_text()
assert 'body.byteStream()' in MAIN.read_text()
assert 'body.bytes()' not in MAIN.read_text()
assert 'pendingImageDataUrl' not in MAIN.read_text()
assert 'web_search_preview' not in MAIN.read_text()
assert 'AstraResponseModel.fromResponse' in MAIN.read_text()
assert 'AstraResponseModel.fromChatJson' in MAIN.read_text()
assert 'URLSpan' in RENDERER.read_text()
assert 'DB_VERSION = 5' in DB.read_text()
assert 'autoEffortHint' in DB.read_text()

for p in [ROOT/'app/src/main/AndroidManifest.xml', *ROOT.glob('app/src/main/res/**/*.xml')]:
    ET.parse(p)

# Verify the SQL shape used by ChatDatabase onCreate in a real SQLite engine.
con = sqlite3.connect(':memory:')
con.execute('CREATE TABLE chats (id TEXT PRIMARY KEY NOT NULL,title TEXT NOT NULL,response_id TEXT,baseline_effort TEXT,updated_at INTEGER NOT NULL)')
con.execute('CREATE TABLE messages (id INTEGER PRIMARY KEY AUTOINCREMENT,chat_id TEXT NOT NULL,position INTEGER NOT NULL,role TEXT NOT NULL,text TEXT NOT NULL,response_id TEXT,request_id TEXT,file_ids TEXT,file_names TEXT,image_path TEXT,image_file_id TEXT,annotations TEXT,tools TEXT,status TEXT,feedback INTEGER,FOREIGN KEY(chat_id) REFERENCES chats(id) ON DELETE CASCADE)')
con.execute("CREATE TABLE effort_metrics (id INTEGER PRIMARY KEY AUTOINCREMENT,chat_id TEXT NOT NULL,created_at INTEGER NOT NULL,effort_pref TEXT NOT NULL,effective_effort TEXT NOT NULL,auto_selected INTEGER NOT NULL,prompt_chars INTEGER NOT NULL,attachments INTEGER NOT NULL,latency_ms INTEGER NOT NULL,input_tokens INTEGER NOT NULL DEFAULT 0,cached_tokens INTEGER NOT NULL DEFAULT 0,cache_write_tokens INTEGER NOT NULL DEFAULT 0,output_tokens INTEGER NOT NULL DEFAULT 0,reasoning_tokens INTEGER NOT NULL DEFAULT 0,success INTEGER NOT NULL,error_type TEXT,request_id TEXT,task_class TEXT NOT NULL DEFAULT 'general',feedback INTEGER)")
print('Astra v4.14 static verification: PASS')
