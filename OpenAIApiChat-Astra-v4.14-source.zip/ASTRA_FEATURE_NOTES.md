# Astra feature notes — v4.14

Implemented directly:
- reasoning.effort: low / medium / high / xhigh / max
- Auto effort: lexical baseline + conservative feedback-based calibration
- max_output_tokens
- instructions
- prompt_cache_key
- parallel_tool_calls
- streaming
- previous_response_id
- `configuration_update` for standard-mode effort changes
- `web_search`
- `url_citation` rendering
- file_search with vector_store_ids
- file upload + input_file
- code_interpreter + container file download
- image_generation tool flag
- image input via Files API `file_id`
- SQLite chat history with legacy migration
- diagnostics and effort telemetry
- generated-file cards with local cache and FileProvider

Not fully implemented:
- Computer Use executor
- arbitrary custom function tools / full MCP UX
- Realtime voice UI
- rich image-generation result gallery
- full Structured Outputs schema editor

The app does not use `temperature` or `top_p` for Astra.
