plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.openaichat"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.openaichat"
        minSdk = 26
        targetSdk = 35
        versionCode = 41
        versionName = "4.1"
    }
}

dependencies {
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
}
