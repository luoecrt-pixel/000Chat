# Astra v4.16.0 handoff for Claude

This package is a GPT-authored increment built on top of the Claude-authored v4.13 and the later GPT increments v4.14/v4.14.1/v4.15.0/v4.15.1.

Do not roll back existing functionality. The goal is to verify this source, fix only real issues, and get `assembleDebug` passing in GitHub Actions.

## Already present before v4.16

- `gpt-6-astra` with reasoning levels low/medium/high/xhigh/max.
- `configuration_update` for reasoning changes in standard mode.
- `web_search` (migrated from `web_search_preview`).
- `container_file_citation` and `file_citation` download handling.
- `url_citation` and ordinary HTTP(S) links are clickable.
- SQLite chat history with legacy SharedPreferences migration.
- Auto-effort metrics and feedback calibration.
- Diagnostics screen/logging.
- Race protection using chat/generation IDs.
- Current-chat deletion fix.
- Export failure handling.
- Background Responses and response polling/reconciliation.
- Composer draft/attachment persistence.
- Usage/token/cost dashboard.
- Long-chat preflight warning.
- Reasoning Summary UI: API-provided reasoning summary, not private chain-of-thought.

## v4.16.0 changes

### Composer / user attachments
- A selected attachment is shown immediately, before server upload completes.
- Upload progress is visible as a percentage with a stage label.
- Images get immediate thumbnails and a larger in-app preview.
- Text/JSON/CSV/code-like files can be read inside the app.
- PDFs have a first-page in-app preview; other formats retain an external Open action.
- The permanent local copy is exposed to the UI as soon as local copying finishes, even while network upload is still running.
- Cancellation cleans up temporary local copies created for in-flight uploads.
- Sent user file metadata (`file_paths`, `file_mimes`, `image_name`, `image_mime`, `image_size`) is persisted in the message DB.
- On restart, older sent attachments without a local path show Download and can then be viewed locally.
- User images without a local path but with a file_id can be downloaded again and restored locally.
- Pending composer attachments are chat-scoped; switching/new/deleting a chat no longer leaks pending attachment chips into another chat.

### Generated files / images
- Generated file cards are rendered directly under the assistant response text and before Sources/feedback.
- A valid local generated-file copy is preferred even if the annotation has a stale EXPIRED/PENDING state. This addresses the observed v4.14.1 case where diagnostics showed successful downloads but the reopened chat said the container was unavailable.
- Generated image previews are clickable.
- Generated text/JSON/PDF files are previewable inside the app.
- Legacy migration now preserves `generated_images`.
- Local file library also offers in-app preview where possible.

### ZIP
- Selecting a ZIP keeps it as a ZIP card in the composer.
- ZIP is unpacked only after Send is pressed.
- Extraction is streamed with per-entry / total / entry-count safety limits.

## Important CI workflow change

The canonical workflow is `.github/workflows/build.yml`.

For v4.16.0 it was changed only to point the source verification step at:

`python3 tools/verify_v4_16.py`

All other workflow settings remain the same as the validated v4.15.1 workflow:
- checkout@v7
- setup-java@v6
- setup-android@v4
- setup-gradle@v6
- upload-artifact@v7
- JDK 17
- Android SDK 35 / build-tools 35.0.0
- Gradle 8.9

Because GitHub executes the workflow file stored in the repository, the repository copy of `.github/workflows/build.yml` MUST be replaced/committed. A new workflow inside a ZIP does not retroactively update a previously committed workflow.

The workflow expects one source archive at repository root matching `*-source.zip`. Remove duplicate old source ZIPs.

## Version

- versionName: `4.16.0`
- versionCode: `60`

## Static verification

Run:

`python3 tools/verify_v4_16.py`

Expected:

`Astra v4.16.0 static verification: PASS`

This is not a substitute for the actual GitHub Actions Android build.

## Runtime test checklist

1. Select a large image: attachment card should appear immediately and progress should move.
2. Select a TXT/JSON: after local copy, `Просмотр` should be usable before upload finishes.
3. Select a PDF: first page preview should render.
4. Send JSON: it should remain viewable in the sent message.
5. Close/reopen app: sent image name and thumbnail should remain if local file exists.
6. Open an old message whose file annotation says EXPIRED but whose local generated file still exists: it should recover to READY.
7. Generate a TXT/JSON/HTML and a PNG with Astra: asset cards should sit directly below response text.
8. Select ZIP: it must NOT unpack before Send.
9. Send ZIP: only then should supported inner files be unpacked/uploaded.
10. Select two files, switch chats during upload: each must stay associated with its original chat.
11. Cancel an upload: no abandoned temp copy should remain.
12. Force-close/reopen while a background response is running: result should reconcile by response ID when known.
