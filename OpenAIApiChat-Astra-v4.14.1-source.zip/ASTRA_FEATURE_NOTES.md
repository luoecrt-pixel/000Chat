# Astra feature notes — v4.14.1

Already implemented in the source:
- gpt-6-astra
- reasoning.effort: low / medium / high / xhigh / max
- Auto effort: lexical baseline + conservative feedback-based calibration
- `configuration_update` in standard mode
- streaming + `previous_response_id`
- `web_search` + `url_citation`
- File Search + `file_citation`
- Code Interpreter + `container_file_citation` download
- Image Generation result -> local PNG preview
- image input via Files API `file_id`
- SQLite chat history with legacy migration
- lightweight chat summaries
- diagnostics and effort telemetry
- rich text renderer with HTTP(S) Markdown/bare links
- safe ZIP streaming
- FileProvider / Storage Access Framework file actions

Not implemented as full end-to-end executors:
- Computer Use
- arbitrary custom function/MCP execution
- Realtime voice UI

The live streaming display intentionally keeps a simple text buffer for low-latency rendering. The completed response path uses `AstraResponseModel`, annotations and tool metadata.
