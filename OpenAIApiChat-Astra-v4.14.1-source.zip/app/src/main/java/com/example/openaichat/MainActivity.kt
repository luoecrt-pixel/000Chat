package com.example.openaichat

import android.app.*
import android.content.*
import android.content.ClipboardManager
import android.database.Cursor
import android.provider.OpenableColumns
import android.os.SystemClock
import android.text.method.LinkMovementMethod
import androidx.core.content.FileProvider
import android.content.res.ColorStateList
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.text.*
import android.text.style.*
import android.util.Base64
import android.view.*
import android.widget.*
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.security.KeyStore
import java.util.concurrent.Executors
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties

class MainActivity : Activity() {
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
        .readTimeout(0, java.util.concurrent.TimeUnit.SECONDS)
        .callTimeout(0, java.util.concurrent.TimeUnit.SECONDS)
        .build()
    private val executor = Executors.newCachedThreadPool()

    private lateinit var prefs: SharedPreferences
    private lateinit var chatDb: ChatDatabase
    private lateinit var diagnostics: AstraDiagnostics
    private lateinit var scroll: ScrollView
    private lateinit var messages: LinearLayout
    private lateinit var input: EditText
    private lateinit var send: Button
    private lateinit var stop: Button
    private lateinit var status: TextView
    private lateinit var toolLabel: TextView
    private lateinit var title: TextView
    private lateinit var attachRow: LinearLayout
    private var vsListArea: LinearLayout? = null
    private var vsStatusLine: TextView? = null
    private lateinit var attachScroll: HorizontalScrollView
    private lateinit var effortBadge: TextView

    private var currentCall: Call? = null
    private var requestGeneration = 0L
    private var currentResponseId: String? = null
    private var baselineEffort: String? = null
    private var pendingUploads = 0
    private val chat = mutableListOf<JSONObject>()
    private val attachedFileIds = mutableListOf<String>()
    private val attachedFileNames = mutableListOf<String>()
    private val attachedFileSizes = mutableListOf<Long>()
    private var pendingImagePath: String? = null
    private var pendingImageFileId: String? = null
    private var lastUserText: String = ""

    private val secure by lazy { SecureStore(this) }
    private val pickAny = 5100
    private val pickImage = 5101
    private val pickVoice = 5102
    private val pickVectorStoreFile = 5103
    private val pickExportTxt = 5104
    private val pickSaveGenerated = 5105
    private var pendingExportBytes: ByteArray? = null
    private var pendingSaveSourcePath: String? = null
    private var pendingSaveFilename: String? = null
    private var pendingSaveMime: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("app", MODE_PRIVATE)
        chatDb = ChatDatabase(this)
        diagnostics = AstraDiagnostics(this)
        chatDb.migrateLegacyPrefs(prefs)
        ensureChatStore()
        buildUi()
        restoreCurrentChat()
        diagnostics.log("app_started", mapOf("version" to BuildConfig.VERSION_NAME, "model" to (prefs.getString("model", "gpt-6-astra") ?: "gpt-6-astra")))
    }

    override fun onDestroy() {
        requestGeneration++
        currentCall?.cancel()
        executor.shutdownNow()
        try { chatDb.close() } catch (_: Exception) {}
        super.onDestroy()
    }

    private fun isRequestCurrent(chatId: String, generation: Long): Boolean =
        currentChatId() == chatId && requestGeneration == generation && !isFinishing

    // ---------- UI ----------
    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(17,18,21))
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(10), dp(10), dp(10))
            setBackgroundColor(Color.rgb(22,23,27))
        }

        val chatsBtn = button("☰") { showChats() }
        header.addView(chatsBtn, LinearLayout.LayoutParams(-2,-2).apply{rightMargin=dp(10)})

        title = TextView(this).apply {
            text = currentChatTitle()
            textSize = 19f
            setTextColor(Color.WHITE)
            setTypeface(null, Typeface.BOLD)
            setSingleLine(true)
            ellipsize = TextUtils.TruncateAt.END
        }
        header.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(button("＋") { newChat() }, LinearLayout.LayoutParams(-2,-2).apply{leftMargin=dp(8)})
        header.addView(button("⚙") { showSettings() }, LinearLayout.LayoutParams(-2,-2).apply{leftMargin=dp(8)})
        root.addView(header)
        root.addView(View(this).apply{ setBackgroundColor(Color.rgb(34,36,42)) }, LinearLayout.LayoutParams(-1,dp(1)))

        status = TextView(this).apply {
            text = "Готово"
            textSize = 12f
            setTextColor(Color.rgb(165,170,180))
            setPadding(dp(14), 0, dp(14), dp(4))
        }
        root.addView(status)

        scroll = ScrollView(this)
        messages = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(6), dp(10), dp(12))
        }
        scroll.addView(messages)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        toolLabel = TextView(this).apply {
            textSize = 12f
            setTextColor(Color.rgb(145,190,245))
            setPadding(dp(12), 0, dp(12), dp(4))
            maxLines = 4
            ellipsize = TextUtils.TruncateAt.END
            setOnClickListener { showToolDetails() }
        }
        root.addView(toolLabel)

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), 0, dp(10), dp(4))
        }
        row.addView(button("📎") { chooseAny() })
        row.addView(button("🖼") { chooseImage() })

        effortBadge = TextView(this).apply {
            textSize = 12f
            setTextColor(Color.rgb(138,180,248))
            setPadding(dp(10),0,dp(6),0)
            text = "⚡ "+(prefs.getString("reasoning","high") ?: "high")
            setOnClickListener { showQuickEffortPicker() }
        }
        row.addView(effortBadge)

        val space = Space(this)
        row.addView(space, LinearLayout.LayoutParams(0,1,1f))

        val modelBadge = TextView(this).apply {
            textSize = 12f
            setTextColor(Color.GRAY)
            text = prefs.getString("model","gpt-6-astra")
        }
        row.addView(modelBadge)
        root.addView(row)

        attachRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        attachScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            setPadding(dp(10), 0, dp(10), dp(6))
            visibility = View.GONE
            addView(attachRow, LinearLayout.LayoutParams(-2, -2))
        }
        root.addView(attachScroll)

        val composer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.BOTTOM
            setPadding(dp(10), dp(3), dp(10), dp(10))
        }
        input = EditText(this).apply {
            hint = "Сообщение…"
            setHintTextColor(Color.rgb(120,125,135))
            setTextColor(Color.WHITE)
            textSize = 16f
            setPadding(dp(14),dp(11),dp(14),dp(11))
            background = rounded(Color.rgb(30,31,36),20)
            minLines = 1
            maxLines = 7
            inputType = android.text.InputType.TYPE_CLASS_TEXT or
                    android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                    android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        }
        composer.addView(input, LinearLayout.LayoutParams(0,-2,1f))

        composer.addView(button("🎙") { chooseVoice() }, LinearLayout.LayoutParams(dp(46),-2).apply{leftMargin=dp(6)})

        send = Button(this).apply {
            text = "➤"
            minWidth=0; minimumWidth=0
            setTextColor(Color.rgb(18,20,24))
            background = rounded(Color.rgb(138,180,248),20)
            setOnClickListener { sendMessage(false) }
        }
        composer.addView(send, LinearLayout.LayoutParams(dp(52),-2).apply{leftMargin=dp(6)})

        stop = Button(this).apply {
            text = "■"
            minWidth=0; minimumWidth=0
            setTextColor(Color.WHITE)
            background = rounded(Color.rgb(120,60,60),20)
            visibility = View.GONE
            setOnClickListener { currentCall?.cancel() }
        }
        composer.addView(stop, LinearLayout.LayoutParams(dp(52),-2).apply{leftMargin=dp(6)})
        root.addView(composer)

        root.setOnApplyWindowInsetsListener { v, insets ->
            v.setPadding(insets.systemWindowInsetLeft, insets.systemWindowInsetTop, insets.systemWindowInsetRight, insets.systemWindowInsetBottom)
            insets.consumeSystemWindowInsets()
        }

        setContentView(root)
    }

    private fun showChats() {
        val all = loadAllChats()
        val names = all.map { it.optString("title","Новый чат") }.toMutableList()
        names.add("＋ Новый чат")
        AlertDialog.Builder(this)
            .setTitle("Чаты")
            .setItems(names.toTypedArray()) { _, which ->
                if (which == names.lastIndex) newChat()
                else switchChat(all[which].optString("id"))
            }
            .setNeutralButton("Управление") { _, _ -> manageChats(all) }
            .show()
    }

    private fun manageChats(all: List<JSONObject>) {
        val names = all.map { it.optString("title","Новый чат") }
        if (names.isEmpty()) return
        AlertDialog.Builder(this)
            .setTitle("Управление чатами")
            .setItems(names.toTypedArray()) { _, which ->
                showChatActions(all[which])
            }.show()
    }

    private fun showChatActions(c: JSONObject) {
        AlertDialog.Builder(this)
            .setTitle(c.optString("title","Чат"))
            .setItems(arrayOf("Переименовать","Удалить")) { _, which ->
                when (which) {
                    0 -> renameChat(c.optString("id"))
                    1 -> deleteChat(c.optString("id"))
                }
            }.show()
    }

    private fun renameChat(id: String) {
        val chats = loadAllChats().toMutableList()
        val found = chats.firstOrNull { it.optString("id")==id } ?: return
        val edit = EditText(this).apply {
            setText(found.optString("title"))
            setTextColor(Color.WHITE)
        }
        AlertDialog.Builder(this)
            .setTitle("Название")
            .setView(edit)
            .setNegativeButton("Отмена",null)
            .setPositiveButton("Сохранить") { _, _ ->
                found.put("title", edit.text.toString().trim().ifBlank { "Чат" })
                chatDb.renameChat(id, found.optString("title"))
                if (currentChatId()==id) title.text = found.optString("title")
            }.show()
    }

    private fun deleteChat(id: String) {
        chatDb.deleteChat(id)
        if (currentChatId()==id) {
            requestGeneration++
            currentCall?.cancel()
            val newId = newChatId()
            prefs.edit().putString("current_chat",newId).apply()
            chat.clear()
            currentResponseId=null
            baselineEffort=null
            attachedFileIds.clear()
            attachedFileNames.clear()
            attachedFileSizes.clear()
            pendingImagePath=null
            pendingImageFileId=null
            refreshAttachChips()
            messages.removeAllViews()
            toolLabel.text=""
            title.text="Новый чат"
            ensureChatEntry(newId,"Новый чат")
            status.text="Новый чат"
        }
    }

    // ---------- Settings ----------
    private fun showQuickEffortPicker(){
        val efforts=arrayOf("auto","low","medium","high","xhigh","max")
        val current=prefs.getString("reasoning","high") ?: "high"
        val idx=efforts.indexOf(current).coerceAtLeast(0)
        AlertDialog.Builder(this)
            .setTitle("Мышление")
            .setSingleChoiceItems(efforts,idx){d,which->
                prefs.edit().putString("reasoning",efforts[which]).apply()
                effortBadge.text="⚡ "+efforts[which]
                d.dismiss()
            }.show()
    }

    private fun showSettings() {
        val cardBg = Color.rgb(36,38,44)
        val accent = Color.rgb(138,180,248)
        val subtext = Color.rgb(150,155,165)
        val divider = Color.rgb(52,54,60)

        val box = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(14),dp(6),dp(14),dp(10)) }
        val advancedBox = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; visibility=View.GONE }
        var target: LinearLayout = box

        fun section(title:String){
            target.addView(TextView(this).apply{
                this.text=title
                textSize=12.5f
                setTypeface(null,Typeface.BOLD)
                setTextColor(accent)
                setPadding(dp(2),dp(20),0,dp(8))
            })
            target.addView(View(this).apply{ setBackgroundColor(divider) }, LinearLayout.LayoutParams(-1,dp(1)))
        }
        fun spaced(v:View){ target.addView(v, LinearLayout.LayoutParams(-1,-2).apply{ topMargin=dp(10) }) }

        fun field(hint:String,value:String,secret:Boolean=false) = EditText(this).apply {
            this.hint=hint; setText(value); setTextColor(Color.WHITE); setHintTextColor(subtext)
            setPadding(dp(12),dp(11),dp(12),dp(11))
            background=rounded(cardBg)
            if (secret) inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        fun labeled(caption:String,view:View){
            target.addView(TextView(this).apply{this.text=caption;textSize=12f;setTextColor(subtext);setPadding(dp(2),dp(10),0,dp(4))})
            target.addView(view)
        }
        fun spinner(values:Array<String>,pref:String,def:String):Spinner{
            val s=Spinner(this)
            s.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,values)
            s.setSelection(values.indexOf(prefs.getString(pref,def) ?: def).coerceAtLeast(0))
            s.setPadding(dp(10),dp(8),dp(10),dp(8))
            s.background=rounded(cardBg)
            return s
        }

        section("Подключение")
        val key = field("OpenAI API key", secure.getApiKey(), true); spaced(key)
        val model = field("Model ID", prefs.getString("model","gpt-6-astra") ?: "gpt-6-astra"); spaced(model)

        section("Мышление")
        val efforts = arrayOf("auto","low","medium","high","xhigh","max")
        val reasoning = spinner(efforts,"reasoning","high")
        labeled("Reasoning effort (auto = клиент сам подбирает по сложности запроса)",reasoning)

        val modes = arrayOf("standard","pro")
        val mode = spinner(modes,"reasoning_mode","standard")
        labeled("Reasoning mode",mode)

        section("Инструменты")
        fun chk(label:String,pref:String) = CheckBox(this).apply {
            text=label; setTextColor(Color.LTGRAY); isChecked=prefs.getBoolean(pref,false)
            setPadding(dp(4),dp(6),0,dp(6))
        }
        val web=chk("Web Search","web")
        val file=chk("File Search","file_search")
        val code=chk("Code Interpreter","code_interpreter")
        val img=chk("Image Generation","image_generation")
        val parallel=chk("Parallel tool calls","parallel_tools")
        val toolsCard=LinearLayout(this).apply{
            orientation=LinearLayout.VERTICAL
            setPadding(dp(10),dp(4),dp(10),dp(4))
            background=rounded(cardBg)
        }
        listOf(web,file,code,img,parallel).forEach { toolsCard.addView(it) }
        spaced(toolsCard)

        lateinit var advancedToggle: TextView
        advancedToggle = TextView(this).apply{
            text="▸ Дополнительные настройки"
            setTextColor(accent); textSize=13f
            setPadding(dp(2),dp(20),0,dp(6))
            setOnClickListener{
                val show = advancedBox.visibility!=View.VISIBLE
                advancedBox.visibility = if(show) View.VISIBLE else View.GONE
                advancedToggle.text = if(show) "▾ Дополнительные настройки" else "▸ Дополнительные настройки"
            }
        }
        box.addView(advancedToggle)
        box.addView(advancedBox)
        target = advancedBox

        section("Формат ответа")
        val verbosities = arrayOf("low","medium","high")
        val verbosity = spinner(verbosities,"verbosity","medium")
        labeled("Verbosity",verbosity)

        val summaries = arrayOf("auto","concise","detailed","null")
        val summary = spinner(summaries,"reasoning_summary","auto")
        labeled("Summary",summary)

        val textFormats = arrayOf("text","json_object","json_schema")
        val textFormat = spinner(textFormats,"text_format","text")
        labeled("Text format — для обычного чата оставьте \"text\". json_object/json_schema нужны, только если ответ разбирает другая программа (не человек)",textFormat)

        val jsonSchema = field("JSON Schema — заполняйте только при Text format = json_schema", prefs.getString("json_schema","") ?: ""); spaced(jsonSchema)

        section("Прочее")
        val instructions = field("Developer instructions", prefs.getString("instructions","") ?: ""); spaced(instructions)
        val vector = field("Vector Store ID", prefs.getString("vector_store","") ?: ""); spaced(vector)
        spaced(button("📁 Управление файлами Vector Store"){ showVectorStoreManager() }.apply{
            setTextColor(accent); background=rounded(Color.rgb(40,48,66))
        })
        val max = field("Max output tokens", prefs.getString("max_output","128000") ?: "128000"); spaced(max)
        val cache = field("Prompt cache key (optional)", prefs.getString("cache_key","") ?: ""); spaced(cache)
        spaced(button("📈 Статистика auto-эффорта") {
            AlertDialog.Builder(this)
                .setTitle("Auto-эффорт")
                .setMessage(chatDb.effortStats())
                .setPositiveButton("OK", null)
                .setNeutralButton("Очистить лог") { _, _ -> diagnostics.clear(); status.text = "Диагностический лог очищен" }
                .show()
        }.apply {
            setTextColor(accent); background=rounded(Color.rgb(40,48,66))
        })
        spaced(button("🧪 Диагностика") {
            AlertDialog.Builder(this)
                .setTitle("Astra diagnostics")
                .setMessage(diagnostics.tail())
                .setPositiveButton("OK", null)
                .show()
        }.apply {
            setTextColor(accent); background=rounded(Color.rgb(40,48,66))
        })

        val note=TextView(this).apply {
            text="Astra: 1.05M context, 128K max output. reasoning: auto/low/medium/high/xhigh/max."
            setTextColor(subtext); textSize=11.5f; setPadding(dp(2),dp(14),0,0)
        }
        box.addView(note)

        AlertDialog.Builder(this)
            .setTitle("Astra / OpenAI API")
            .setView(ScrollView(this).apply{addView(box)})
            .setNegativeButton("Отмена",null)
            .setPositiveButton("Сохранить") { _,_ ->
                secure.setApiKey(key.text.toString().trim())
                prefs.edit()
                    .putString("model",model.text.toString().trim())
                    .putString("instructions",instructions.text.toString())
                    .putString("vector_store",vector.text.toString().trim())
                    .putString("max_output",max.text.toString().trim())
                    .putString("cache_key",cache.text.toString().trim())
                    .putString("json_schema",jsonSchema.text.toString())
                    .putString("reasoning",efforts[reasoning.selectedItemPosition])
                    .putString("reasoning_mode",modes[mode.selectedItemPosition])
                    .putString("verbosity",verbosities[verbosity.selectedItemPosition])
                    .putString("reasoning_summary",summaries[summary.selectedItemPosition])
                    .putString("text_format",textFormats[textFormat.selectedItemPosition])
                    .putBoolean("web",web.isChecked)
                    .putBoolean("file_search",file.isChecked)
                    .putBoolean("code_interpreter",code.isChecked)
                    .putBoolean("image_generation",img.isChecked)
                    .putBoolean("parallel_tools",parallel.isChecked)
                    .apply()
                effortBadge.text="⚡ "+efforts[reasoning.selectedItemPosition]
                status.text="Настройки сохранены"
            }.show()
    }

    // ---------- Chat ----------
    private fun newChatId(): String = "chat_${System.currentTimeMillis()}_${System.nanoTime()}"

    private fun newChat() {
        requestGeneration++
        currentCall?.cancel()
        persistCurrentChat()
        val id = newChatId()
        prefs.edit().putString("current_chat",id).apply()
        chat.clear()
        currentResponseId=null
        baselineEffort=null
        lastUserText=""
        attachedFileIds.clear()
        attachedFileNames.clear()
        attachedFileSizes.clear()
        pendingImagePath=null
        pendingImageFileId=null
        refreshAttachChips()
        messages.removeAllViews()
        toolLabel.text=""
        title.text="Новый чат"
        ensureChatEntry(id,"Новый чат")
        status.text="Новый чат"
    }

    private fun switchChat(id:String) {
        requestGeneration++
        currentCall?.cancel()
        persistCurrentChat()
        prefs.edit().putString("current_chat",id).apply()
        restoreCurrentChat()
    }

    private fun classifyTask(text:String, hasAttachments:Boolean):String{
        val t=text.lowercase()
        return when {
            hasAttachments && (t.contains("анализ") || t.contains("разбери") || t.contains("проанализ") || t.contains("таблиц") || t.contains("файл")) -> "attachment_analysis"
            t.contains("код") || t.contains("функци") || t.contains("дебаг") || t.contains("отлад") || t.contains("рефактор") || t.contains("algorithm") || t.contains("debug") || t.contains("refactor") -> "coding"
            t.contains("проанализ") || t.contains("сравни") || t.contains("докажи") || t.contains("архитектур") || t.contains("исслед") || t.contains("analyze") || t.contains("compare") -> "analysis"
            text.length <= 80 -> "short"
            else -> "general"
        }
    }

    private fun autoEffortHeuristic(text:String, hasAttachments:Boolean):String{
        val len=text.length
        val heavy=Regex("(?i)(код|напиши функци|проанализируй|подробно|разбер|докажи|архитектур|дебаг|отладь|сравни|оптимизир|алгоритм|рефактор|explain in detail|analyze|debug)")
        return when {
            hasAttachments && len>200 -> "high"
            heavy.containsMatchIn(text) -> "high"
            len>600 -> "xhigh"
            len in 1..39 -> "low"
            else -> "medium"
        }
    }
    private fun fmtTokens(n:Int):String = when {
        n>=1_000_000 -> "%.1fM".format(n/1_000_000.0)
        n>=1_000 -> "%.1fK".format(n/1_000.0)
        else -> n.toString()
    }
    private fun estimateCost(inputTokens:Int, cachedTokens:Int, cacheWriteTokens:Int, outputTokens:Int):Double{
        // Astra standard tier: baseline $10/M input, $1/M cached input,
        // $12.50/M cache-write input and $50/M output. Above 272K input tokens
        // the documented long-context multiplier changes the effective rates.
        val longContext = inputTokens > 272_000
        val inMultiplier = if(longContext) 2.0 else 1.0
        val outMultiplier = if(longContext) 1.5 else 1.0
        val inRate=10.0*inMultiplier
        val cachedRate=1.0*inMultiplier
        val cacheWriteRate=12.50*inMultiplier
        val outRate=50.0*outMultiplier
        val uncached=(inputTokens-cachedTokens-cacheWriteTokens).coerceAtLeast(0)
        return (uncached*inRate + cachedTokens*cachedRate + cacheWriteTokens*cacheWriteRate + outputTokens*outRate) / 1_000_000.0
    }

    private fun sendMessage(regenerate:Boolean) {
        val key=secure.getApiKey()
        if(key.isBlank()){showSettings();return}
        if(pendingUploads>0){ status.text="Дождитесь загрузки вложений…"; return }
        val requestChatId = currentChatId()
        val requestGeneration = ++this.requestGeneration
        val startedAt = SystemClock.elapsedRealtime()

        var text = if(regenerate) lastUserText else input.text.toString().trim()
        if(regenerate) restoreLastUserAttachments()

        val imagePath=pendingImagePath
        val imageFileId=pendingImageFileId
        val requestFileIds = attachedFileIds.toList()
        val requestFileNames = attachedFileNames.toList()
        val requestFileSizes = attachedFileSizes.toList()
        val knownFileBytes = requestFileSizes.sumOf { it.coerceAtLeast(0L) }
        val maxTotalInputFileBytes = 50L * 1024L * 1024L
        if (knownFileBytes > maxTotalInputFileBytes) {
            status.text = "Суммарный размер файлов больше ${formatBytes(maxTotalInputFileBytes)} — уменьшите количество/размер вложений"
            return
        }
        val requestImagePath = imagePath
        val requestImageFileId = imageFileId
        if(!regenerate && text.isBlank() && requestImageFileId==null && requestFileIds.isEmpty()) return
        if(regenerate && text.isBlank()) return

        val model=prefs.getString("model","gpt-6-astra") ?: "gpt-6-astra"
        val effortPref=prefs.getString("reasoning","high") ?: "high"
        val hasAttachments = requestFileIds.isNotEmpty() || requestImageFileId!=null
        val autoSelected = effortPref=="auto"
        val taskClass = classifyTask(text, hasAttachments)
        val baselineAutoEffort = autoEffortHeuristic(text,hasAttachments)
        val effort=if(autoSelected) chatDb.autoEffortHint(taskClass, baselineAutoEffort) else effortPref
        val reasoningMode=prefs.getString("reasoning_mode","standard") ?: "standard"
        var configUpdateEffort:String? = null
        val effectiveEffort:String
        if(reasoningMode=="standard"){
            val baseline=baselineEffort
            when {
                baseline==null -> { baselineEffort=effort; effectiveEffort=effort }
                baseline==effort -> effectiveEffort=baseline
                else -> { effectiveEffort=baseline; configUpdateEffort=effort }
            }
        } else {
            effectiveEffort=effort
        }
        val actualEffort = configUpdateEffort ?: effectiveEffort
        val verbosity=prefs.getString("verbosity","medium") ?: "medium"
        val summary=prefs.getString("reasoning_summary","auto") ?: "auto"
        val maxOut=prefs.getString("max_output","128000")?.toIntOrNull()?.coerceIn(256,128000) ?: 128000

        if(!regenerate) {
            addBubble("Ты",buildString {
                if(text.isNotBlank()) append(text)
                if(requestImageFileId!=null || imagePath!=null){ if(isNotEmpty()) append("\n"); append("🖼 Изображение") }
                if(requestFileNames.isNotEmpty()){ if(isNotEmpty()) append("\n"); append("📎 "+requestFileNames.joinToString(", ")) }
            },true, imagePath?.let{decodeThumbnailFromFile(it)})
            input.setText("")
        }

        lastUserText=text
        setBusy(true)
        status.text="Astra думает…"
        diagnostics.log("request_start", mapOf(
            "chat_id" to requestChatId,
            "generation" to requestGeneration,
            "effort_pref" to effortPref,
            "effective_effort" to actualEffort,
            "auto" to autoSelected,
            "task_class" to taskClass,
            "auto_baseline" to baselineAutoEffort,
            "auto_effective" to effort,
            "attachments" to requestFileIds.size + if(requestImageFileId!=null) 1 else 0,
            "prompt_chars" to text.length,
            "model" to model
        ))

        val content=JSONArray()
        if(text.isNotBlank()) content.put(JSONObject().put("type","input_text").put("text",text))
        requestImageFileId?.let { content.put(JSONObject().put("type","input_image").put("file_id",it)) }
        requestFileIds.forEach { content.put(JSONObject().put("type","input_file").put("file_id",it)) }

        // Keep the request-level effort stable in standard mode; Astra's configuration_update
        // changes the conversation effort while preserving the original prompt prefix for caching.
        val reasoningObj=JSONObject().put("effort",effectiveEffort).put("mode",reasoningMode)
        if(summary!="null") reasoningObj.put("summary",summary)

        val textObj=JSONObject().put("verbosity",verbosity)
        val inputArr=JSONArray()
        configUpdateEffort?.let{ newEffort->
            inputArr.put(JSONObject().put("type","configuration_update").put("reasoning",JSONObject().put("effort",newEffort)))
            runOnUiThread{
                if(isRequestCurrent(requestChatId,requestGeneration)) toolLabel.text="⚙ мышление: $effectiveEffort → $newEffort (эта реплика)"
            }
        }
        inputArr.put(JSONObject().put("role","user").put("content",content))

        val body=JSONObject()
            .put("model",model)
            .put("input",inputArr)
            .put("stream",true)
            .put("store",true)
            .put("reasoning",reasoningObj)
            .put("max_output_tokens",maxOut)
            .put("parallel_tool_calls",prefs.getBoolean("parallel_tools",true))

        prefs.getString("instructions","")?.takeIf{it.isNotBlank()}?.let { body.put("instructions",it) }
        prefs.getString("cache_key","")?.takeIf{it.isNotBlank()}?.let { body.put("prompt_cache_key",it) }
        // OpenAI currently disallows combining configuration_update with automatic compaction.
        if (configUpdateEffort == null) {
            body.put("context_management", JSONArray().put(JSONObject().put("type","compaction").put("compact_threshold",800000)))
        }
        currentResponseId?.let { body.put("previous_response_id",it) }

        when(prefs.getString("text_format","text")){
            "json_object" -> textObj.put("format",JSONObject().put("type","json_object"))
            "json_schema" -> {
                val schemaText=prefs.getString("json_schema","")?.trim().orEmpty()
                if(schemaText.isNotBlank()){
                    try {
                        val schema=JSONObject(schemaText)
                        textObj.put("format",JSONObject().put("type","json_schema").put("name","astra_response").put("strict",true).put("schema",schema))
                    } catch(_:Exception){
                        runOnUiThread{ if(isRequestCurrent(requestChatId,requestGeneration)) status.text="Ошибка: JSON Schema недействительна" }
                    }
                } else {
                    runOnUiThread{ if(isRequestCurrent(requestChatId,requestGeneration)) status.text="Укажите JSON Schema в настройках для этого формата" }
                }
            }
        }
        body.put("text",textObj)

        val tools=JSONArray()
        if(prefs.getBoolean("web",true)) tools.put(JSONObject().put("type","web_search"))
        if(prefs.getBoolean("file_search",false)){
            val vs=prefs.getString("vector_store","")?.trim().orEmpty()
            if(vs.isNotBlank()) tools.put(JSONObject().put("type","file_search").put("vector_store_ids",JSONArray().put(vs)).put("max_num_results",20))
        }
        if(prefs.getBoolean("code_interpreter",false)){
            val c=JSONObject().put("type","auto").put("memory_limit","4g")
            if(requestFileIds.isNotEmpty()){
                val ids=JSONArray(); requestFileIds.forEach{ids.put(it)}; c.put("file_ids",ids)
            }
            tools.put(JSONObject().put("type","code_interpreter").put("container",c))
        }
        if(prefs.getBoolean("image_generation",false)) tools.put(JSONObject().put("type","image_generation"))
        if(tools.length()>0) body.put("tools",tools)

        val include=JSONArray()
        if(prefs.getBoolean("web",true)) include.put("web_search_call.action.sources")
        if(prefs.getBoolean("file_search",false)) include.put("file_search_call.results")
        if(prefs.getBoolean("code_interpreter",false)) include.put("code_interpreter_call.outputs")
        include.put("computer_call_output.output.image_url")
        body.put("include",include)

        pendingImagePath=null
        pendingImageFileId=null
        attachedFileIds.clear()
        attachedFileNames.clear()
        attachedFileSizes.clear()
        toolLabel.text=""
        refreshAttachChips()

        val assistantView = addBubble("Astra","",false)
        val req=Request.Builder()
            .url("https://api.openai.com/v1/responses")
            .addHeader("Authorization","Bearer $key")
            .addHeader("Content-Type","application/json")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        currentCall=client.newCall(req)
        val call=currentCall!!

        executor.execute {
            var requestId: String? = null
            var newId: String? = null
            var usage: JSONObject? = null
            var fileCites = emptyList<JSONObject>()
            var urlCites = emptyList<JSONObject>()
            var completionState = "in_progress"
            var completionError: String? = null
            var completedResponse: JSONObject? = null
            val toolItems=mutableListOf<String>()
            val full=StringBuilder()
            var lastUiUpdate=0L
            try {
                call.execute().use { response ->
                    requestId=response.header("x-request-id")
                    diagnostics.log("http_response", mapOf("request_id" to requestId, "status" to response.code, "chat_id" to requestChatId, "generation" to requestGeneration))
                    if(!response.isSuccessful) throw IOException("HTTP ${response.code}: ${response.body?.string().orEmpty()}")
                    val reader=response.body?.byteStream()?.bufferedReader(Charsets.UTF_8) ?: throw IOException("Пустой ответ")
                    reader.forEachLine { line ->
                        if(!line.startsWith("data: ")) return@forEachLine
                        val data=line.removePrefix("data: ").trim()
                        if(data=="[DONE]") return@forEachLine
                        try {
                            val ev=JSONObject(data)
                            when(ev.optString("type")){
                                "response.output_text.delta" -> {
                                    val delta=ev.optString("delta")
                                    if(delta.isNotEmpty()){
                                        full.append(delta)
                                        val now=SystemClock.elapsedRealtime()
                                        if(now-lastUiUpdate>=50L){
                                            lastUiUpdate=now
                                            val snapshot=full.toString()
                                            runOnUiThread{
                                                if(isRequestCurrent(requestChatId,requestGeneration)){
                                                    assistantView.text=markdown(snapshot)
                                                    scroll.post{scroll.fullScroll(View.FOCUS_DOWN)}
                                                }
                                            }
                                        }
                                    }
                                }
                                "response.web_search_call.completed" -> toolItems.add("🌐 Web Search")
                                "response.file_search_call.completed" -> toolItems.add("📚 File Search")
                                "response.code_interpreter_call.completed" -> toolItems.add("🐍 Code Interpreter")
                                "response.image_generation_call.completed" -> toolItems.add("🎨 Image Generation")
                                "response.computer_call.completed" -> toolItems.add("🖥 Computer Use")
                                "response.incomplete" -> {
                                    val r=ev.optJSONObject("response")
                                    completionState="incomplete"
                                    newId=r?.optString("id")?.takeIf{it.isNotBlank()}
                                    usage=r?.optJSONObject("usage")
                                    completionError=r?.optJSONObject("incomplete_details")?.optString("reason")
                                    completedResponse=r
                                }
                                "response.failed" -> {
                                    val r=ev.optJSONObject("response")
                                    completionState="failed"
                                    newId=r?.optString("id")?.takeIf{it.isNotBlank()}
                                    usage=r?.optJSONObject("usage")
                                    completionError=r?.optJSONObject("error")?.optString("message")
                                        ?: r?.optString("error")
                                    completedResponse=r
                                }
                                "response.completed" -> {
                                    completionState="completed"
                                    val r=ev.optJSONObject("response")
                                    newId=r?.optString("id")?.takeIf{it.isNotBlank()}
                                    usage=r?.optJSONObject("usage")
                                    completedResponse=r
                                    parseTools(r?.optJSONArray("output"),toolItems)
                                    val annotations=extractAnnotations(r?.optJSONArray("output"))
                                    fileCites=annotations.first
                                    urlCites=annotations.second
                                    diagnostics.log("response_completed", mapOf(
                                        "request_id" to requestId,
                                        "response_id" to newId,
                                        "files" to fileCites.size,
                                        "urls" to urlCites.size,
                                        "latency_ms" to (SystemClock.elapsedRealtime()-startedAt)
                                    ))
                                }
                            }
                        } catch (parseError:Exception){
                            diagnostics.log("sse_event_parse_error", mapOf("message" to (parseError.message ?: "unknown"), "request_id" to requestId))
                        }
                    }

                    if(completionState=="failed") {
                        throw IOException("Ответ Astra не завершился: ${completionError?.take(500) ?: "неизвестная ошибка"}")
                    }
                    val finalText=full.toString().ifBlank{if(completionState=="incomplete") "Ответ завершён не полностью." else "Готово. Ответ не содержит текста."}
                    val answerAnnotations=JSONArray()
                    fileCites.forEach{ answerAnnotations.put(JSONObject(it.toString())) }
                    urlCites.forEach{ answerAnnotations.put(JSONObject(it.toString())) }
                    val parsedModel = AstraResponseModel.fromResponse(
                        completedResponse,
                        finalText,
                        requestId,
                        completionState,
                        completionError
                    )
                    val responseModel = parsedModel.copy(
                        id = newId ?: parsedModel.id,
                        annotations = if(parsedModel.annotations.length()>0) parsedModel.annotations else answerAnnotations,
                        tools = (parsedModel.tools + toolItems).distinct(),
                        usage = usage ?: parsedModel.usage
                    )
                    val assistantMessage=responseModel.toChatJson()
                    val savedGeneratedImages = saveGeneratedImages(responseModel.generatedImageResults)
                    if (savedGeneratedImages.length() > 0) assistantMessage.put("generated_images", savedGeneratedImages)

                    val latency=SystemClock.elapsedRealtime()-startedAt
                    val usageObj=usage
                    val inTok=usageObj?.optInt("input_tokens",0) ?: 0
                    val outTok=usageObj?.optInt("output_tokens",0) ?: 0
                    val cachedTok=usageObj?.optJSONObject("input_tokens_details")?.optInt("cached_tokens",0) ?: 0
                    val cacheWriteTok=usageObj?.optJSONObject("input_tokens_details")?.optInt("cache_write_tokens",0) ?: 0
                    val reasoningTok=usageObj?.optJSONObject("output_tokens_details")?.optInt("reasoning_tokens",0) ?: 0
                    chatDb.recordEffortMetric(requestId, requestChatId, taskClass, effortPref, actualEffort, autoSelected, text.length, requestFileIds.size + if(requestImageFileId!=null) 1 else 0, latency, inTok, cachedTok, cacheWriteTok, outTok, reasoningTok, true, null)

                    runOnUiThread{
                        if(!isRequestCurrent(requestChatId,requestGeneration)) return@runOnUiThread
                        currentResponseId=newId ?: currentResponseId
                        baselineEffort=actualEffort
                        val userMessage=JSONObject().put("role","user").put("text",text)
                        val fileIds=JSONArray(); requestFileIds.forEach{fileIds.put(it)}
                        val fileNames=JSONArray(); requestFileNames.forEach{fileNames.put(it)}
                        val fileSizes=JSONArray(); requestFileSizes.forEach{fileSizes.put(it)}
                        if(fileIds.length()>0) userMessage.put("file_ids",fileIds)
                        if(fileNames.length()>0) userMessage.put("file_names",fileNames)
                        if(fileSizes.length()>0) userMessage.put("file_sizes",fileSizes)
                        requestImagePath?.takeIf{File(it).isFile}?.let{path->userMessage.put("image_path",path)}
                        requestImageFileId?.let{fid->userMessage.put("image_file_id",fid)}
                        if(!regenerate) {
                            chat.add(userMessage)
                        }
                        chat.add(assistantMessage)
                        persistCurrentChat()

                        assistantView.text=RichTextRenderer.render(responseModel)
                        val bubbleCard=assistantView.parent as? LinearLayout
                        if(bubbleCard!=null){
                            renderAnnotations(responseModel.annotations,bubbleCard,assistantMessage,requestChatId,requestGeneration)
                            renderGeneratedImages(assistantMessage,bubbleCard)
                            addFeedbackRow(bubbleCard,assistantMessage,requestChatId)
                        }
                        status.text=if(usageObj!=null){
                            val cost=estimateCost(inTok,cachedTok,cacheWriteTok,outTok)
                            val reasoningPart=if(reasoningTok>0)" (${fmtTokens(reasoningTok)} думал)" else ""
                            val donePrefix=if(completionState=="incomplete") "Неполный ответ" else "Готово"
                            "$donePrefix · ${fmtTokens(inTok)} in · ${fmtTokens(outTok)} out$reasoningPart · ≈\$%.4f".format(cost)
                        } else if(completionState=="incomplete") "Ответ завершён не полностью" else "Готово"
                        if(toolItems.isNotEmpty()) toolLabel.text=toolItems.distinct().joinToString("  ")
                        setBusy(false)
                        currentCall=null
                        if(status.text=="Astra думает…") status.text="Готово"
                    }
                }
            } catch(e:Exception) {
                val cancelled=call.isCanceled()
                val latency=SystemClock.elapsedRealtime()-startedAt
                chatDb.recordEffortMetric(requestId, requestChatId, taskClass, effortPref, actualEffort, autoSelected, text.length, requestFileIds.size + if(requestImageFileId!=null) 1 else 0, latency, 0,0,0,0,0, false, if(cancelled) "cancelled" else e.javaClass.simpleName)
                diagnostics.log(if(cancelled) "request_cancelled" else "request_failed", mapOf("request_id" to requestId, "response_id" to newId, "chat_id" to requestChatId, "generation" to requestGeneration, "latency_ms" to latency, "error" to (e.message ?: e.toString()).take(512)))
                runOnUiThread{
                    if(!isRequestCurrent(requestChatId,requestGeneration)) return@runOnUiThread
                    setBusy(false)
                    currentCall=null
                    if(!cancelled && completionState=="incomplete" && full.isNotBlank() && isRequestCurrent(requestChatId,requestGeneration)) {
                        val partial=JSONObject().put("role","assistant").put("text",full.toString()).put("incomplete",true).put("status","incomplete")
                        newId?.let{partial.put("response_id",it)}
                        requestId?.let{partial.put("request_id",it)}
                        chat.add(partial)
                        persistCurrentChat()
                    }
                    if(cancelled){
                        if(messages.childCount>0) messages.removeViewAt(messages.childCount-1)
                        if(!regenerate && messages.childCount>0) messages.removeViewAt(messages.childCount-1)
                        if(!regenerate){
                            input.setText(text); input.setSelection(input.text.length)
                        }
                        attachedFileIds.clear(); attachedFileIds.addAll(requestFileIds)
                        attachedFileNames.clear(); attachedFileNames.addAll(requestFileNames)
                        attachedFileSizes.clear(); attachedFileSizes.addAll(requestFileSizes)
                        pendingImagePath=requestImagePath
                        refreshAttachChips()
                        status.text="Остановлено — сообщение и вложения возвращены в поле ввода"
                    } else {
                        val friendly = friendlyApiError(e.message)
                        status.text="Ошибка"
                        addBubble("Ошибка",friendly,false)
                    }
                }
            }
        }
    }

    private fun JSONArray.toJsonArray(): JSONArray = JSONArray(toString())

    private fun friendlyApiError(raw:String?):String{
        val text=raw.orEmpty()
        if(text.isBlank()) return "Неизвестная ошибка API"
        val jsonStart=text.indexOf('{')
        if(jsonStart>=0){
            try{
                val obj=JSONObject(text.substring(jsonStart))
                val err=obj.optJSONObject("error")
                val msg=err?.optString("message")?.takeIf{it.isNotBlank()}
                if(msg!=null) return msg
            }catch(_:Exception){}
        }
        return text.lineSequence().firstOrNull()?.take(500) ?: "Ошибка запроса"
    }

    private fun parseTools(output:JSONArray?, items:MutableList<String>) {
        if(output==null)return
        for(i in 0 until output.length()){
            val o=output.optJSONObject(i)?:continue
            when(o.optString("type")){
                "web_search_call" -> items.add("🌐 Web Search")
                "file_search_call" -> items.add("📚 File Search")
                "code_interpreter_call" -> items.add("🐍 Code Interpreter")
                "image_generation_call" -> items.add("🎨 Image Generation")
                "computer_call" -> items.add("🖥 Computer Use")
            }
        }
    }

    private fun extractAnnotations(output:JSONArray?): Pair<List<JSONObject>,List<JSONObject>> {
        val files=mutableListOf<JSONObject>()
        val urls=mutableListOf<JSONObject>()
        if(output==null) return files to urls
        for(i in 0 until output.length()){
            val item=output.optJSONObject(i) ?: continue
            if(item.optString("type")!="message") continue
            val contentArr=item.optJSONArray("content") ?: continue
            for(j in 0 until contentArr.length()){
                val c=contentArr.optJSONObject(j) ?: continue
                if(c.optString("type")!="output_text") continue
                val annotations=c.optJSONArray("annotations") ?: continue
                for(k in 0 until annotations.length()){
                    val raw=annotations.optJSONObject(k) ?: continue
                    val a=JSONObject(raw.toString())
                    when(a.optString("type")){
                        "container_file_citation", "file_citation" -> files.add(a)
                        "url_citation" -> urls.add(a)
                    }
                }
            }
        }
        return files to urls
    }

    private fun renderAnnotations(
        annotations:JSONArray,
        card:LinearLayout,
        message:JSONObject,
        chatId:String,
        generation:Long
    ){
        val files=mutableListOf<JSONObject>()
        val urls=mutableListOf<JSONObject>()
        for(i in 0 until annotations.length()){
            val a=annotations.optJSONObject(i) ?: continue
            when(a.optString("type")){
                "container_file_citation", "file_citation" -> files.add(a)
                "url_citation" -> urls.add(a)
            }
        }
        files.distinctBy{it.optString("container_id")+"/"+it.optString("file_id")}.forEach{a->
            addGeneratedFileCard(a,card,message,chatId,generation)
        }
        if(urls.isNotEmpty()){
            val header=TextView(this).apply{
                text="Источники"
                textSize=12f
                setTypeface(null,Typeface.BOLD)
                setTextColor(Color.rgb(180,185,198))
                setPadding(0,dp(9),0,dp(2))
            }
            card.addView(header)
            urls.distinctBy{it.optString("url")}.take(10).forEach{u->
                val raw=u.optJSONObject("url_citation") ?: u
                val url=raw.optString("url").trim()
                if(url.isBlank()) return@forEach
                val sourceTitle=raw.optString("title").ifBlank{url}
                card.addView(TextView(this).apply{
                    text="🔗 $sourceTitle"
                    setTextColor(Color.rgb(138,180,248)); textSize=12.5f
                    isSingleLine=true; ellipsize=TextUtils.TruncateAt.END
                    setPadding(0,dp(2),0,dp(2))
                    setOnClickListener{
                        try{
                            val intent=Intent(Intent.ACTION_VIEW,Uri.parse(url)).apply{
                                addCategory(Intent.CATEGORY_BROWSABLE)
                            }
                            startActivity(intent)
                        }catch(_:Exception){status.text="Не удалось открыть ссылку"}
                    }
                })
            }
        }
    }

    private fun addGeneratedFileCard(
        annotation:JSONObject,
        parent:LinearLayout,
        message:JSONObject,
        chatId:String,
        generation:Long
    ){
        val annotationType = annotation.optString("type").trim()
        val containerId=annotation.optString("container_id").trim()
        val fileId=annotation.optString("file_id").trim()
        val filename=safeDisplayName(annotation.optString("filename").ifBlank{"file"})
        val state=annotation.optString("state").ifBlank{"PENDING"}
        val path=annotation.optString("local_path").takeIf{it.isNotBlank()}
        if(state=="READY" && path!=null && File(path).isFile){
            val box=LinearLayout(this).apply{
                orientation=LinearLayout.VERTICAL
                setPadding(dp(10),dp(8),dp(10),dp(8))
                background=rounded(Color.rgb(38,40,46),10)
            }
            parent.addView(box,LinearLayout.LayoutParams(-1,-2).apply{topMargin=dp(6)})
            populateReadyFileCard(box,annotation,filename,path)
            return
        }

        val box=LinearLayout(this).apply{
            orientation=LinearLayout.VERTICAL
            setPadding(dp(10),dp(8),dp(10),dp(8))
            background=rounded(Color.rgb(38,40,46),10)
        }
        parent.addView(box,LinearLayout.LayoutParams(-1,-2).apply{topMargin=dp(6)})
        renderFileCardState(box,annotation,message,chatId,generation,filename)

        val canDownload = fileId.isNotBlank() && (containerId.isNotBlank() || annotationType == "file_citation")
        val shouldAutoDownload = canDownload && annotationType == "container_file_citation" && state !in setOf("FAILED","EXPIRED")
        if(shouldAutoDownload) {
            downloadCitedFile(annotation,box,message,chatId,generation)
        } else if(annotationType == "file_citation" && state == "PENDING" && canDownload) {
            val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
            row.addView(fileActionButton("Скачать"){
                annotation.put("state","DOWNLOADING").remove("error")
                persistCurrentChatFor(chatId)
                renderFileCardState(box,annotation,message,chatId,generation,filename)
                downloadCitedFile(annotation,box,message,chatId,generation)
            })
            box.addView(row)
        } else if(state=="FAILED") {
            addFileRetryButton(box,annotation,message,chatId,generation,filename)
        }
    }

    private fun renderFileCardState(
        box:LinearLayout,
        annotation:JSONObject,
        message:JSONObject,
        chatId:String,
        generation:Long,
        filename:String
    ){
        box.removeAllViews()
        val state=annotation.optString("state").ifBlank{"DOWNLOADING"}
        val size=annotation.optLong("size_bytes",0L)
        val mime=annotation.optString("mime_type").ifBlank{mimeForFilename(filename)}
        val icon=when(state){"READY"->"✅";"FAILED"->"⚠️";"EXPIRED"->"⌛";else->"📄"}
        val titleRow=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val titleView=TextView(this).apply{
            text="$icon $filename"
            textSize=14f;setTextColor(Color.WHITE);setTypeface(null,Typeface.BOLD)
        }
        titleRow.addView(titleView,LinearLayout.LayoutParams(0,-2,1f))
        box.addView(titleRow)
        val details=TextView(this).apply{
            text=when(state){
                "READY" -> "$mime · ${formatBytes(size)}"
                "FAILED" -> "Ошибка: ${annotation.optString("error").ifBlank{"неизвестная ошибка"}.take(180)}"
                "EXPIRED" -> if(annotation.optString("type") == "file_citation") "Исходный файл больше недоступен" else "Файл контейнера больше недоступен"
                "PENDING" -> if(annotation.optString("type") == "file_citation") "Файл найден в хранилище · нажмите «Скачать»" else "Подготовка…"
                else -> "Скачивание…"
            }
            textSize=11.5f;setTextColor(Color.rgb(165,170,180));setPadding(0,dp(3),0,dp(4))
        }
        box.addView(details)
    }

    private fun populateReadyFileCard(box:LinearLayout,annotation:JSONObject,filename:String,path:String){
        box.removeAllViews()
        val mime=annotation.optString("mime_type").ifBlank{mimeForFilename(filename)}
        val size=annotation.optLong("size_bytes",File(path).length())
        box.addView(TextView(this).apply{
            text="✅ $filename";textSize=14f;setTextColor(Color.WHITE);setTypeface(null,Typeface.BOLD)
        })
        box.addView(TextView(this).apply{
            text="$mime · ${formatBytes(size)}";textSize=11.5f;setTextColor(Color.rgb(165,170,180));setPadding(0,dp(3),0,dp(6))
        })
        val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        row.addView(fileActionButton("Открыть"){openLocalFile(path,filename,mime)})
        row.addView(fileActionButton("Сохранить"){requestSaveLocalFile(path,filename,mime)})
        row.addView(fileActionButton("Поделиться"){shareLocalFile(path,filename,mime)})
        box.addView(row)
    }

    private fun addFileRetryButton(box:LinearLayout,annotation:JSONObject,message:JSONObject,chatId:String,generation:Long,filename:String){
        val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        row.addView(fileActionButton("Повторить"){
            annotation.put("state","DOWNLOADING").remove("error")
            persistCurrentChatFor(chatId)
            renderFileCardState(box,annotation,message,chatId,generation,filename)
            downloadCitedFile(annotation,box,message,chatId,generation)
        })
        box.addView(row)
    }


    private fun fileActionButton(label:String,onClick:()->Unit)=TextView(this).apply{
        text=label;textSize=12.5f;setTextColor(Color.rgb(138,180,248))
        setPadding(dp(6),dp(6),dp(12),dp(6))
        setOnClickListener{onClick()}
    }

    private fun downloadCitedFile(annotation:JSONObject,box:LinearLayout,message:JSONObject,chatId:String,generation:Long){
        val annotationType = annotation.optString("type").trim()
        val containerId=annotation.optString("container_id").trim()
        val fileId=annotation.optString("file_id").trim()
        val filename=safeDisplayName(annotation.optString("filename").ifBlank{"file"})
        if(fileId.isBlank() || (containerId.isBlank() && annotationType != "file_citation")) return
        annotation.put("state","DOWNLOADING")
        chatDb.updateGeneratedFileState(chatId,fileId,"DOWNLOADING", annotationType=annotationType)
        if(currentChatId()==chatId) persistCurrentChatFor(chatId)
        renderFileCardState(box,annotation,message,chatId,generation,filename)
        diagnostics.log("file_download_start",mapOf("chat_id" to chatId,"type" to annotationType,"container_id" to containerId,"file_id" to fileId,"filename" to filename))
        val key=secure.getApiKey()
        executor.execute{
            try{
                val contentUrl = if (annotationType == "file_citation") {
                    "https://api.openai.com/v1/files/$fileId/content"
                } else {
                    "https://api.openai.com/v1/containers/$containerId/files/$fileId/content"
                }
                val req=Request.Builder()
                    .url(contentUrl)
                    .addHeader("Authorization","Bearer $key").get().build()
                client.newCall(req).execute().use{resp->
                    if(!resp.isSuccessful) throw FileDownloadException(resp.code)
                    val body=resp.body ?: throw IOException("Пустой ответ")
                    val expected=body.contentLength()
                    val maxBytes=512L*1024L*1024L
                    if(expected>maxBytes) throw IOException("Файл слишком большой для мобильного клиента (>${formatBytes(maxBytes)})")
                    val dir=File(filesDir,"generated").apply{mkdirs()}
                    val destination=File(dir,"${System.currentTimeMillis()}_${safeFileName(filename)}")
                    body.byteStream().use{input->destination.outputStream().use{output->
                        val buffer=ByteArray(64*1024)
                        var total=0L
                        while(true){
                            val n=input.read(buffer)
                            if(n<0) break
                            total+=n
                            if(total>maxBytes){destination.delete();throw IOException("Файл слишком большой для мобильного клиента (>${formatBytes(maxBytes)})")}
                            output.write(buffer,0,n)
                        }
                    }}
                    val mime=resp.header("Content-Type")?.substringBefore(';')?.trim().takeIf{!it.isNullOrBlank()} ?: mimeForFilename(filename)
                    chatDb.updateGeneratedFileState(chatId,fileId,"READY",destination.absolutePath,mime,destination.length(), annotationType=annotationType)
                    runOnUiThread{
                        if(!isRequestCurrent(chatId,generation)){ return@runOnUiThread }
                        annotation.put("state","READY")
                            .put("local_path",destination.absolutePath)
                            .put("mime_type",mime)
                            .put("size_bytes",destination.length())
                        persistCurrentChatFor(chatId)
                        populateReadyFileCard(box,annotation,filename,destination.absolutePath)
                        diagnostics.log("file_download_ready",mapOf("container_id" to containerId,"file_id" to fileId,"bytes" to destination.length()))
                    }
                }
            }catch(e:FileDownloadException){
                val expired=e.code==404 || e.code==410
                chatDb.updateGeneratedFileState(chatId,fileId,if(expired)"EXPIRED" else "FAILED",error="HTTP ${e.code}", annotationType=annotationType)
                runOnUiThread{
                    if(!isRequestCurrent(chatId,generation))return@runOnUiThread
                    annotation.put("state",if(expired)"EXPIRED" else "FAILED").put("error","HTTP ${e.code}")
                    persistCurrentChatFor(chatId)
                    renderFileCardState(box,annotation,message,chatId,generation,filename)
                    if(!expired) addFileRetryButton(box,annotation,message,chatId,generation,filename)
                    diagnostics.log("file_download_failed",mapOf("container_id" to containerId,"file_id" to fileId,"status" to e.code))
                }
            }catch(e:Exception){
                val friendly=friendlyApiError(e.message)
                chatDb.updateGeneratedFileState(chatId,fileId,"FAILED",error=friendly, annotationType=annotationType)
                runOnUiThread{
                    if(!isRequestCurrent(chatId,generation))return@runOnUiThread
                    annotation.put("state","FAILED").put("error",friendly)
                    persistCurrentChatFor(chatId)
                    renderFileCardState(box,annotation,message,chatId,generation,filename)
                    addFileRetryButton(box,annotation,message,chatId,generation,filename)
                    diagnostics.log("file_download_failed",mapOf("container_id" to containerId,"file_id" to fileId,"error" to (e.message ?: e.toString()).take(300)))
                }
            }
        }
    }

    private class FileDownloadException(val code:Int):IOException("HTTP $code")

    private fun saveGeneratedImages(results:List<String>):JSONArray {
        val out=JSONArray()
        if(results.isEmpty()) return out
        val maxEncodedBytes = 72L*1024L*1024L
        val maxDecodedBytes = 50L*1024L*1024L
        val dir=File(filesDir,"generated_images").apply{mkdirs()}
        results.take(4).forEachIndexed { index, encoded ->
            try{
                if(encoded.length.toLong() > maxEncodedBytes) throw IOException("Изображение Astra слишком большое")
                val bytes=Base64.decode(encoded,Base64.DEFAULT)
                if(bytes.size.toLong()>maxDecodedBytes) throw IOException("Изображение Astra слишком большое")
                if(bytes.size<8 || (bytes[0].toInt() and 0xFF)!=0x89 || (bytes[1].toInt() and 0xFF)!=0x50 || (bytes[2].toInt() and 0xFF)!=0x4E || (bytes[3].toInt() and 0xFF)!=0x47) throw IOException("Ожидался PNG")
                val file=File(dir,"astra_${System.currentTimeMillis()}_${System.nanoTime()}_$index.png")
                file.outputStream().use{it.write(bytes)}
                out.put(JSONObject().put("filename",file.name).put("local_path",file.absolutePath).put("mime_type","image/png").put("size_bytes",file.length()).put("state","READY"))
            }catch(e:Exception){
                diagnostics.log("generated_image_failed",mapOf("error" to (e.message ?: e.toString()).take(300)))
            }
        }
        return out
    }

    private fun renderGeneratedImages(message:JSONObject,parent:LinearLayout){
        val arr=message.optJSONArray("generated_images") ?: return
        for(i in 0 until arr.length()){
            val a=arr.optJSONObject(i) ?: continue
            val path=a.optString("local_path").takeIf{it.isNotBlank()}
            val filename=safeDisplayName(a.optString("filename").ifBlank{"astra_image.png"})
            val mime=a.optString("mime_type").ifBlank{"image/png"}
            if(path==null || !File(path).isFile) continue
            val box=LinearLayout(this).apply{
                orientation=LinearLayout.VERTICAL
                setPadding(dp(10),dp(8),dp(10),dp(8))
                background=rounded(Color.rgb(38,40,46),10)
            }
            parent.addView(box,LinearLayout.LayoutParams(-1,-2).apply{topMargin=dp(6)})
            box.addView(ImageView(this).apply{
                val bmp=decodeThumbnailFromFile(path,1200)
                setImageBitmap(bmp)
                adjustViewBounds=true
                scaleType=ImageView.ScaleType.FIT_CENTER
                setPadding(0,0,0,dp(6))
            },LinearLayout.LayoutParams(-1,dp(280)))
            box.addView(TextView(this).apply{
                text="🎨 $filename · ${formatBytes(File(path).length())}"
                textSize=12f;setTextColor(Color.rgb(165,170,180))
            })
            val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
            row.addView(fileActionButton("Открыть"){openLocalFile(path,filename,mime)})
            row.addView(fileActionButton("Сохранить"){requestSaveLocalFile(path,filename,mime)})
            row.addView(fileActionButton("Поделиться"){shareLocalFile(path,filename,mime)})
            box.addView(row)
        }
    }

    private fun openLocalFile(path:String,filename:String,mime:String){
        try{
            val uri=FileProvider.getUriForFile(this,"${BuildConfig.APPLICATION_ID}.fileprovider",File(path))
            val intent=Intent(Intent.ACTION_VIEW).apply{
                setDataAndType(uri,mime)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(intent,"Открыть $filename"))
        }catch(e:Exception){status.text="Нет приложения для открытия ${filename}: ${e.message ?: "неизвестная ошибка"}"}
    }

    private fun requestSaveLocalFile(path:String,filename:String,mime:String){
        pendingSaveSourcePath=path
        pendingSaveFilename=filename
        pendingSaveMime=mime
        val i=Intent(Intent.ACTION_CREATE_DOCUMENT).apply{
            addCategory(Intent.CATEGORY_OPENABLE)
            type=mime
            putExtra(Intent.EXTRA_TITLE,filename)
        }
        try{startActivityForResult(i,pickSaveGenerated)}catch(e:Exception){status.text="Сохранение недоступно: ${e.message}"}
    }

    private fun shareLocalFile(path:String,filename:String,mime:String){
        try{
            val uri=FileProvider.getUriForFile(this,"${BuildConfig.APPLICATION_ID}.fileprovider",File(path))
            val intent=Intent(Intent.ACTION_SEND).apply{
                type=mime
                putExtra(Intent.EXTRA_STREAM,uri)
                putExtra(Intent.EXTRA_TEXT,filename)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(intent,"Поделиться $filename"))
        }catch(e:Exception){status.text="Не удалось поделиться файлом: ${e.message}"}
    }

    private fun safeFileName(name:String):String{
        val cleaned=name.replace(Regex("[\\\\/:*?\"<>|\\r\\n]+"),"_").trim().ifBlank{"file"}
        return cleaned.take(180)
    }
    private fun safeDisplayName(name:String):String=safeFileName(name)
    private fun mimeForFilename(name:String):String{
        val ext=name.substringAfterLast('.').lowercase()
        return android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: when(ext){
            "json"->"application/json"; "csv"->"text/csv"; "md"->"text/markdown"; "txt"->"text/plain"; else->"application/octet-stream"
        }
    }
    private fun formatBytes(size:Long):String = when{
        size>=1024L*1024*1024->"%.1f GB".format(size/1024.0/1024.0/1024.0)
        size>=1024L*1024->"%.1f MB".format(size/1024.0/1024.0)
        size>=1024L->"%.1f KB".format(size/1024.0)
        else->"$size B"
    }

    private fun persistCurrentChatFor(chatId:String){
        if(currentChatId()!=chatId)return
        persistCurrentChat()
    }

    private fun showToolDetails() {
        if(toolLabel.text.isNullOrBlank()) return
        AlertDialog.Builder(this)
            .setTitle("Инструменты")
            .setMessage(toolLabel.text)
            .setPositiveButton("OK",null).show()
    }

    // ---------- attachments ----------
    private fun chip(label:String,onRemove:()->Unit):View{
        val c=LinearLayout(this).apply{
            orientation=LinearLayout.HORIZONTAL
            gravity=Gravity.CENTER_VERTICAL
            setPadding(dp(10),dp(4),dp(2),dp(4))
            setBackgroundColor(Color.rgb(38,40,46))
        }
        val t=TextView(this).apply{
            this.text=label;textSize=12f;setTextColor(Color.rgb(210,214,222))
            isSingleLine=true;ellipsize=TextUtils.TruncateAt.END;maxWidth=dp(150)
        }
        c.addView(t)
        val x=TextView(this).apply{
            this.text="✕";textSize=13f;setTextColor(Color.rgb(210,120,120))
            setPadding(dp(10),dp(6),dp(8),dp(6))
            setOnClickListener{onRemove()}
        }
        c.addView(x)
        return c
    }
    private fun refreshAttachChips(){
        attachRow.removeAllViews()
        pendingImagePath?.let{
            attachRow.addView(chip("🖼 Изображение"){pendingImagePath=null;pendingImageFileId=null;refreshAttachChips()},
                LinearLayout.LayoutParams(-2,-2).apply{rightMargin=dp(6)})
        }
        attachedFileNames.forEachIndexed{i,name->
            attachRow.addView(chip("📎 $name"){
                attachedFileIds.removeAt(i);attachedFileNames.removeAt(i);if(i<attachedFileSizes.size)attachedFileSizes.removeAt(i);refreshAttachChips()
            }, LinearLayout.LayoutParams(-2,-2).apply{rightMargin=dp(6)})
        }
        attachScroll.visibility=if(attachRow.childCount>0)View.VISIBLE else View.GONE
    }
    private fun chooseAny() {
        val i=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{
            type="*/*"; addCategory(Intent.CATEGORY_OPENABLE); putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true)
        }
        startActivityForResult(i,pickAny)
    }
    private fun chooseImage() {
        val i=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{
            type="image/*"; addCategory(Intent.CATEGORY_OPENABLE)
        }
        startActivityForResult(i,pickImage)
    }
    private fun chooseVoice() {
        val i=Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply{
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Говорите…")
        }
        if(i.resolveActivity(packageManager)!=null){
            try{ startActivityForResult(i,pickVoice) }
            catch(e:Exception){ status.text="Голосовой ввод недоступен: ${e.message}" }
        } else {
            status.text="На устройстве не найден сервис распознавания речи"
        }
    }
    // ---------- vector store management ----------
    private fun vectorStoreId():String? = prefs.getString("vector_store","")?.trim()?.takeIf{it.isNotBlank()}

    private fun showVectorStoreManager(){
        val container=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL; setPadding(dp(20),dp(10),dp(20),dp(10))}
        val statusLine=TextView(this).apply{this.text="Загрузка…";setTextColor(Color.GRAY);textSize=12f}
        val listArea=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        container.addView(statusLine)
        container.addView(listArea)
        vsListArea=listArea
        vsStatusLine=statusLine

        val dialog=AlertDialog.Builder(this)
            .setTitle("Файлы Vector Store")
            .setView(ScrollView(this).apply{addView(container)})
            .setPositiveButton("+ Добавить файл",null)
            .setNegativeButton("Закрыть",null)
            .create()
        dialog.setOnShowListener{
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener{
                val existing=vectorStoreId()
                if(existing==null){
                    statusLine.text="Создаю Vector Store…"
                    executor.execute{
                        try{
                            val newId=createVectorStore("Astra Files")
                            prefs.edit().putString("vector_store",newId).apply()
                            runOnUiThread{ pickFileForVectorStore() }
                        }catch(e:Exception){ runOnUiThread{statusLine.text="Ошибка создания: ${e.message}"} }
                    }
                } else pickFileForVectorStore()
            }
        }
        dialog.show()
        val vsId=vectorStoreId()
        if(vsId==null) statusLine.text="Vector Store ещё не создан — нажмите «Добавить файл»"
        else renderVectorStoreList(vsId)
    }

    private fun renderVectorStoreList(vsId:String){
        vsStatusLine?.text="Загрузка списка файлов…"
        executor.execute{
            try{
                val files=listVectorStoreFiles(vsId)
                runOnUiThread{
                    val area=vsListArea ?: return@runOnUiThread
                    area.removeAllViews()
                    if(files.isEmpty()){
                        area.addView(TextView(this).apply{this.text="Файлов пока нет";setTextColor(Color.GRAY);textSize=13f})
                    }
                    files.forEach{(fid,name)->
                        val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(0,dp(6),0,dp(6))}
                        row.addView(TextView(this).apply{this.text=name;textSize=14f;setTextColor(Color.WHITE)}, LinearLayout.LayoutParams(0,-2,1f))
                        row.addView(TextView(this).apply{
                            this.text="✕";setTextColor(Color.rgb(210,120,120));setPadding(dp(12),dp(6),dp(6),dp(6))
                            setOnClickListener{
                                executor.execute{
                                    try{ removeFileFromVectorStore(vsId,fid) }catch(_:Exception){}
                                    renderVectorStoreList(vsId)
                                }
                            }
                        })
                        area.addView(row)
                    }
                    vsStatusLine?.text="Vector Store: $vsId"
                }
            }catch(e:Exception){
                runOnUiThread{ vsStatusLine?.text="Ошибка загрузки: ${e.message}" }
            }
        }
    }

    private fun pickFileForVectorStore(){
        val i=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="*/*"}
        startActivityForResult(i,pickVectorStoreFile)
    }

    private fun listVectorStoreFiles(vsId:String):List<Pair<String,String>>{
        val key=secure.getApiKey()
        val req=Request.Builder().url("https://api.openai.com/v1/vector_stores/$vsId/files?limit=100")
            .addHeader("Authorization","Bearer $key").get().build()
        client.newCall(req).execute().use{resp->
            val raw=resp.body?.string().orEmpty()
            if(!resp.isSuccessful)throw IOException("HTTP ${resp.code}: $raw")
            val arr=JSONObject(raw).optJSONArray("data") ?: JSONArray()
            val out=mutableListOf<Pair<String,String>>()
            for(i in 0 until arr.length()){
                val fid=arr.optJSONObject(i)?.optString("id") ?: continue
                val name=try{ fetchFileName(fid) }catch(_:Exception){ fid }
                out.add(fid to name)
            }
            return out
        }
    }
    private fun fetchFileName(fileId:String):String{
        val key=secure.getApiKey()
        val req=Request.Builder().url("https://api.openai.com/v1/files/$fileId")
            .addHeader("Authorization","Bearer $key").get().build()
        client.newCall(req).execute().use{resp->
            val raw=resp.body?.string().orEmpty()
            if(!resp.isSuccessful)throw IOException("HTTP ${resp.code}")
            return JSONObject(raw).optString("filename",fileId)
        }
    }
    private fun createVectorStore(name:String):String{
        val key=secure.getApiKey()
        val reqBody=JSONObject().put("name",name).toString().toRequestBody("application/json".toMediaType())
        val req=Request.Builder().url("https://api.openai.com/v1/vector_stores")
            .addHeader("Authorization","Bearer $key").post(reqBody).build()
        client.newCall(req).execute().use{resp->
            val raw=resp.body?.string().orEmpty()
            if(!resp.isSuccessful)throw IOException("HTTP ${resp.code}: $raw")
            return JSONObject(raw).getString("id")
        }
    }
    private fun attachFileToVectorStore(vsId:String, fileId:String){
        val key=secure.getApiKey()
        val reqBody=JSONObject().put("file_id",fileId).toString().toRequestBody("application/json".toMediaType())
        val req=Request.Builder().url("https://api.openai.com/v1/vector_stores/$vsId/files")
            .addHeader("Authorization","Bearer $key").post(reqBody).build()
        client.newCall(req).execute().use{resp->
            if(!resp.isSuccessful)throw IOException("HTTP ${resp.code}: ${resp.body?.string()}")
        }
    }
    private fun removeFileFromVectorStore(vsId:String, fileId:String){
        val key=secure.getApiKey()
        val req=Request.Builder().url("https://api.openai.com/v1/vector_stores/$vsId/files/$fileId")
            .addHeader("Authorization","Bearer $key").delete().build()
        client.newCall(req).execute().use{resp->
            if(!resp.isSuccessful)throw IOException("HTTP ${resp.code}: ${resp.body?.string()}")
        }
    }
    private fun uploadFileForVectorStore(uri:Uri):Pair<String,String>{
        val key=secure.getApiKey()
        val temp=File(cacheDir,"upload_${System.nanoTime()}")
        val input=contentResolver.openInputStream(uri) ?: throw IOException("Не удалось открыть файл")
        input.use{src->temp.outputStream().use{out->src.copyTo(out,64*1024)}}
        val mime=contentResolver.getType(uri) ?: "application/octet-stream"
        val name=queryName(uri) ?: "attachment"
        val body=MultipartBody.Builder().setType(MultipartBody.FORM)
            .addFormDataPart("purpose","assistants")
            .addFormDataPart("file",name,temp.asRequestBody(mime.toMediaType()))
            .build()
        val req=Request.Builder().url("https://api.openai.com/v1/files").addHeader("Authorization","Bearer $key").post(body).build()
        try{
            client.newCall(req).execute().use{resp->
                val raw=resp.body?.string().orEmpty()
                if(!resp.isSuccessful)throw IOException("HTTP ${resp.code}: $raw")
                return JSONObject(raw).getString("id") to name
            }
        }finally{temp.delete()}
    }

    override fun onActivityResult(r:Int,c:Int,d:Intent?){
        super.onActivityResult(r,c,d)
        if(c!=RESULT_OK || d==null)return
        if(r==pickExportTxt){
            val uri=d.data ?: return
            val bytes=pendingExportBytes
            if(bytes==null){ status.text="Нечего сохранять"; return }
            try{
                val out=contentResolver.openOutputStream(uri) ?: throw IOException("Не удалось открыть файл для записи")
                out.use{it.write(bytes)}
                status.text="Сохранено в файл"
            }catch(e:Exception){ status.text="Ошибка экспорта: ${e.message}" }
            pendingExportBytes=null
            return
        }
        if(r==pickSaveGenerated){
            val uri=d.data ?: return
            val source=pendingSaveSourcePath
            if(source.isNullOrBlank()){ status.text="Файл больше недоступен"; return }
            try{
                val sourceFile=File(source)
                if(!sourceFile.isFile) throw IOException("Локальная копия файла не найдена")
                val out=contentResolver.openOutputStream(uri) ?: throw IOException("Не удалось открыть файл для записи")
                sourceFile.inputStream().use{input->out.use{output->input.copyTo(output,64*1024)}}
                status.text="Сохранено в файл"
            }catch(e:Exception){status.text="Ошибка сохранения: ${e.message}"}
            pendingSaveSourcePath=null
            pendingSaveFilename=null
            pendingSaveMime=null
            return
        }
        if(r==pickVoice){
            val results=d.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val heard=results?.firstOrNull()
            if(!heard.isNullOrBlank()){
                val current=input.text.toString()
                input.setText(if(current.isBlank()) heard else "$current $heard")
                input.setSelection(input.text.length)
            }
            return
        }
        if(r==pickVectorStoreFile){
            val uri=d.data ?: return
            val vsId=vectorStoreId()
            if(vsId==null){ vsStatusLine?.text="Сначала создайте Vector Store"; return }
            vsStatusLine?.text="Загружаю файл…"
            executor.execute{
                try{
                    val (fileId,_)=uploadFileForVectorStore(uri)
                    attachFileToVectorStore(vsId,fileId)
                    runOnUiThread{ renderVectorStoreList(vsId) }
                }catch(e:Exception){
                    runOnUiThread{ vsStatusLine?.text="Ошибка: ${e.message}" }
                }
            }
            return
        }
        if(r==pickImage){
            val uri=d.data ?: return
            beginUpload()
            executor.execute{
                try{
                    val path=copyImageToLocal(uri) ?: throw IOException("Не удалось сохранить изображение")
                    val name=queryName(uri) ?: "image.${File(path).extension}"
                    val fileId=uploadImageFile(path,name)
                    runOnUiThread{
                        pendingImagePath=path
                        pendingImageFileId=fileId
                        refreshAttachChips()
                        status.text="Изображение готово к отправке"
                    }
                }catch(e:Exception){runOnUiThread{status.text="Ошибка изображения: ${e.message}"}}
                finally{ endUpload() }
            }
            return
        }

        val uris=mutableListOf<Uri>()
        d.data?.let{uris.add(it)}
        d.clipData?.let{clip->for(i in 0 until clip.itemCount)uris.add(clip.getItemAt(i).uri)}
        uris.distinct().forEach{uri->
            val name=queryName(uri) ?: "attachment"
            val ext=name.substringAfterLast('.',"").lowercase()
            if(ext=="zip"){
                handleZipAttachment(uri,name)
                return@forEach
            }
            if(ext.isBlank() || ext !in supportedFileExtensions){
                runOnUiThread{status.text="Формат .$ext не поддерживается для чтения файла: $name"}
                return@forEach
            }
            beginUpload()
            executor.execute{
                try{
                    val (id,uploadedName,sizeBytes)=uploadFile(uri)
                    runOnUiThread{
                        attachedFileIds.add(id)
                        attachedFileNames.add(uploadedName)
                        attachedFileSizes.add(sizeBytes)
                        refreshAttachChips()
                    }
                }catch(e:Exception){runOnUiThread{status.text="Ошибка файла: ${e.message}"}}
                finally{ endUpload() }
            }
        }
    }

    private val supportedFileExtensions = setOf(
        "art","bat","brf","c","cls","css","csv","diff","doc","docx","dot","eml","epub","es",
        "h","hs","htm","html","hwp","hwpx","ics","ifb","java","js","json","keynote","ksh",
        "ltx","mail","markdown","md","mht","mhtml","mjs","msg","nws","odp","ods","odt","otp",
        "ots","pages","patch","pdf","pl","pm","pot","potm","potx","ppa","pps","ppsm","ppsx",
        "ppt","pptm","pptx","pwz","py","rst","rtf","scala","sh","shtml","srt","sty","svg",
        "svgz","tex","text","txt","tsv","vcf","vtt","wiz","xla","xlb","xlc","xlm","xls","xlsx",
        "xlt","xlw","xml","yaml","yml"
    )

    private fun handleZipAttachment(uri:Uri, zipName:String){
        runOnUiThread{status.text="Распаковываю $zipName…"}
        beginUpload()
        executor.execute{
            var uploaded=0
            var skipped=0
            var entries=0
            var totalInflated=0L
            val maxEntryBytes=25_000_000L
            val maxTotalBytes=200L*1024L*1024L
            val maxEntries=100
            try{
                contentResolver.openInputStream(uri)?.use{stream->
                    java.util.zip.ZipInputStream(java.io.BufferedInputStream(stream)).use{zin->
                        var entry=zin.nextEntry
                        while(entry!=null){
                            entries++
                            if(entries>maxEntries) throw IOException("ZIP содержит больше $maxEntries файлов")
                            val entryName=entry.name.substringAfterLast('/').trim()
                            val ext=entryName.substringAfterLast('.').lowercase()
                            if(!entry.isDirectory && entry.size >= 0L && entry.size > maxEntryBytes) {
                                throw ZipSafetyException("entry_too_large")
                            }
                            val supported=!entry.isDirectory && entryName.isNotBlank() && !entryName.startsWith(".") && ext in supportedFileExtensions
                            if(supported){
                                val temp=File(cacheDir,"zip_${System.nanoTime()}.tmp")
                                var entryBytes=0L
                                try{
                                    temp.outputStream().use{out->
                                        val buffer=ByteArray(64*1024)
                                        while(true){
                                            val n=zin.read(buffer)
                                            if(n<0) break
                                            entryBytes+=n
                                            totalInflated+=n
                                            if(entryBytes>maxEntryBytes) throw ZipSafetyException("entry_too_large")
                                            if(totalInflated>maxTotalBytes) throw ZipSafetyException("archive_too_large")
                                            out.write(buffer,0,n)
                                        }
                                    }
                                    if(entryBytes==0L){ skipped++ }
                                    else {
                                        val (id,uploadedName,sizeBytes)=uploadTempFile(temp,entryName,mimeForFilename(entryName))
                                        runOnUiThread{
                                            if(!isFinishing){
                                                attachedFileIds.add(id)
                                                attachedFileNames.add(uploadedName)
                                                attachedFileSizes.add(sizeBytes)
                                                refreshAttachChips()
                                                status.text="ZIP: загружено $uploaded"
                                            }
                                        }
                                        uploaded++
                                    }
                                }catch(e:ZipSafetyException){
                                    throw e
                                }catch(_:Exception){
                                    skipped++
                                }finally{temp.delete()}
                            }else if(!entry.isDirectory){
                                // Drain unsupported entries too so their uncompressed bytes count
                                // against the archive-wide budget. Do not use readBytes().
                                val buffer=ByteArray(64*1024)
                                var discarded=0L
                                while(true){
                                    val n=zin.read(buffer)
                                    if(n<0) break
                                    discarded+=n
                                    totalInflated+=n
                                    if(totalInflated>maxTotalBytes) throw ZipSafetyException("archive_too_large")
                                    if(discarded>maxEntryBytes) throw ZipSafetyException("entry_too_large")
                                }
                                skipped++
                            }
                            zin.closeEntry()
                            entry=zin.nextEntry
                        }
                    }
                } ?: throw IOException("Не удалось открыть ZIP")
                runOnUiThread{
                    status.text="Из $zipName загружено файлов: $uploaded" +
                            if(skipped>0) ", пропущено: $skipped" else ""
                }
            }catch(e:ZipSafetyException){
                runOnUiThread{status.text=when(e.reason){
                    "entry_too_large"->"ZIP остановлен: один файл превышает ${formatBytes(maxEntryBytes)}"
                    else->"ZIP остановлен: распакованный объём превышает ${formatBytes(maxTotalBytes)}"
                }}
            }catch(e:Exception){
                runOnUiThread{status.text="Ошибка распаковки $zipName: ${e.message}"}
            }finally{ endUpload() }
        }
    }

    private class ZipSafetyException(val reason:String):IOException(reason)

    private fun uploadTempFile(temp:File,name:String,mime:String):Triple<String,String,Long>{
        val key=secure.getApiKey()
        val body=MultipartBody.Builder().setType(MultipartBody.FORM)
            .addFormDataPart("purpose","user_data")
            .addFormDataPart("file",name,temp.asRequestBody(mime.toMediaType()))
            .build()
        val req=Request.Builder().url("https://api.openai.com/v1/files").addHeader("Authorization","Bearer $key").post(body).build()
        client.newCall(req).execute().use{resp->
            val raw=resp.body?.string().orEmpty()
            if(!resp.isSuccessful)throw IOException("HTTP ${resp.code}: $raw")
            return Triple(JSONObject(raw).getString("id"), name, temp.length())
        }
    }

    private fun uploadFileBytes(bytes:ByteArray, name:String):Triple<String,String,Long>{
        val temp=File(cacheDir,"upload_${System.nanoTime()}")
        temp.writeBytes(bytes)
        try{return uploadTempFile(temp,name,mimeForFilename(name))}finally{temp.delete()}
    }

    private fun uploadImageFile(path:String,name:String):String{
        val key=secure.getApiKey()
        val file=File(path)
        if(!file.isFile) throw IOException("Изображение больше недоступно")
        val mime=mimeForFilename(name).takeIf{it.startsWith("image/")} ?: "image/jpeg"
        val body=MultipartBody.Builder().setType(MultipartBody.FORM)
            .addFormDataPart("purpose","vision")
            .addFormDataPart("file",safeFileName(name),file.asRequestBody(mime.toMediaType()))
            .build()
        val req=Request.Builder().url("https://api.openai.com/v1/files")
            .addHeader("Authorization","Bearer $key").post(body).build()
        client.newCall(req).execute().use{resp->
            val raw=resp.body?.string().orEmpty()
            if(!resp.isSuccessful) throw IOException("HTTP ${resp.code}: $raw")
            return JSONObject(raw).getString("id")
        }
    }

    private fun uploadFile(uri:Uri):Triple<String,String,Long>{
        val key=secure.getApiKey()
        val maxInputFileBytes=50L*1024L*1024L
        val reportedSize=contentResolver.query(uri,arrayOf(OpenableColumns.SIZE),null,null,null)?.use{c->
            if(c.moveToFirst() && !c.isNull(0)) c.getLong(0) else -1L
        } ?: -1L
        if(reportedSize>maxInputFileBytes){
            throw IOException("Файл слишком большой для Responses API (максимум ${formatBytes(maxInputFileBytes)})")
        }
        val temp=File(cacheDir,"upload_${System.nanoTime()}")
        var copied=0L
        try{
            val input=contentResolver.openInputStream(uri) ?: throw IOException("Не удалось открыть файл")
            input.use{src->temp.outputStream().use{out->
                val buffer=ByteArray(64*1024)
                while(true){
                    val n=src.read(buffer)
                    if(n<0) break
                    copied+=n
                    if(copied>maxInputFileBytes) throw IOException("Файл слишком большой для Responses API (максимум ${formatBytes(maxInputFileBytes)})")
                    out.write(buffer,0,n)
                }
            }}
        } catch(e:Exception){
            temp.delete()
            throw e
        }
        val mime=contentResolver.getType(uri) ?: "application/octet-stream"
        val name=queryName(uri) ?: "attachment"
        val body=MultipartBody.Builder().setType(MultipartBody.FORM)
            .addFormDataPart("purpose","user_data")
            .addFormDataPart("file",name,temp.asRequestBody(mime.toMediaType()))
            .build()
        val req=Request.Builder().url("https://api.openai.com/v1/files").addHeader("Authorization","Bearer $key").post(body).build()
        try{
            client.newCall(req).execute().use{resp->
                val raw=resp.body?.string().orEmpty()
                if(!resp.isSuccessful)throw IOException("HTTP ${resp.code}: $raw")
                return Triple(JSONObject(raw).getString("id"), name, temp.length())
            }
        }finally{temp.delete()}
    }
    private fun queryName(uri:Uri):String?{
        var n:String?=null
        contentResolver.query(uri,arrayOf(OpenableColumns.DISPLAY_NAME),null,null,null)?.use{c->
            if(c.moveToFirst()) n=c.getString(c.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME))
        }
        return n
    }

    // ---------- storage ----------
    private fun ensureChatStore(){
        val existing=currentChatId()
        if(existing.isBlank()){
            val id = newChatId()
            prefs.edit().putString("current_chat",id).apply()
            chatDb.ensureChat(id,"Новый чат")
        } else {
            chatDb.ensureChat(existing,"Новый чат")
        }
    }

    private fun currentChatTitleSafe(): String {
        val id=currentChatId()
        return chatDb.getChatTitle(id) ?: "Новый чат"
    }
    private fun currentChatId()=prefs.getString("current_chat","") ?: ""
    private fun currentChatTitle():String = currentChatTitleSafe()
    private fun currentChatObj():JSONObject = chatDb.getChat(currentChatId())
        ?: JSONObject().put("id",currentChatId()).put("title","Новый чат").put("messages",JSONArray())

    private fun ensureChatEntry(id:String,titleText:String){
        chatDb.ensureChat(id,titleText)
    }
    private fun loadAllChats():List<JSONObject> = chatDb.listChatSummaries()
    private fun saveAllChats(list:List<JSONObject>){
        // Compatibility helper for callers that still hand us a full list.
        list.forEach { c ->
            chatDb.upsertCurrentChat(
                c.optString("id"),
                c.optString("title","Новый чат"),
                c.optString("response_id").takeIf{it.isNotBlank() && it!="null"},
                c.optString("baseline_effort").takeIf{it.isNotBlank() && it!="null"},
                jsonArrayToList(c.optJSONArray("messages"))
            )
        }
    }
    private fun jsonArrayToList(arr:JSONArray?):List<JSONObject>{
        if(arr==null)return emptyList()
        val out=mutableListOf<JSONObject>()
        for(i in 0 until arr.length()) arr.optJSONObject(i)?.let{out.add(it)}
        return out
    }
    private fun persistCurrentChat(){
        val id=currentChatId()
        if(id.isBlank())return
        var chatTitle=currentChatTitleSafe()
        if(chat.isNotEmpty() && chatTitle=="Новый чат"){
            val first=chat.firstOrNull{it.optString("role")=="user"}?.optString("text").orEmpty()
            chatTitle=first.take(36).ifBlank{"Новый чат"}
        }
        chatDb.upsertCurrentChat(id,chatTitle,currentResponseId,baselineEffort,chat)
        if(::title.isInitialized) title.text=chatTitle
    }
    private fun restoreCurrentChat(){
        messages.removeAllViews()
        chat.clear()
        attachedFileIds.clear()
        attachedFileNames.clear()
        attachedFileSizes.clear()
        pendingImagePath=null
        pendingImageFileId=null
        refreshAttachChips()
        val c=currentChatObj()
        title.text=c.optString("title","Новый чат")
        currentResponseId=c.optString("response_id").takeIf{it.isNotBlank() && it!="null"}
        baselineEffort=c.optString("baseline_effort").takeIf{it.isNotBlank() && it!="null"}
        val arr=c.optJSONArray("messages") ?: JSONArray()
        for(i in 0 until arr.length()){
            val m=arr.optJSONObject(i)?:continue
            val role=m.optString("role")
            val t=m.optString("text")
            chat.add(m)
            val imgPath=m.optString("image_path").takeIf{it.isNotBlank()}
            addBubble(if(role=="user")"Ты" else "Astra",t,role=="user",imgPath?.let{decodeThumbnailFromFile(it)},m.optJSONArray("annotations"),m)
            if(role=="user")lastUserText=t
        }
        val restoredTools = chat.lastOrNull { it.optString("role") == "assistant" }
            ?.optJSONArray("tools")
        toolLabel.text = restoredTools?.let { arr ->
            (0 until arr.length()).map { arr.optString(it) }.filter { it.isNotBlank() }.distinct().joinToString("  ")
        }.orEmpty()
        val restoredStatus = chat.lastOrNull { it.optString("role") == "assistant" }?.optString("status")
        status.text = if(restoredStatus == "incomplete") "Последний ответ был неполным" else "Готово"
    }

    private fun editMessage(idx:Int){
        if(idx<0 || idx>=chat.size) return
        if(chat[idx].optString("role")!="user") return
        requestGeneration++
        currentCall?.cancel()
        val message=chat[idx]
        val text=message.optString("text")

        // Restore attachments from the original user message into the composer.
        attachedFileIds.clear()
        attachedFileNames.clear()
        attachedFileSizes.clear()
        pendingImagePath=null
        pendingImageFileId=null
        message.optJSONArray("file_ids")?.let { arr ->
            for(i in 0 until arr.length()) attachedFileIds.add(arr.optString(i))
        }
        message.optJSONArray("file_names")?.let { arr ->
            for(i in 0 until arr.length()) attachedFileNames.add(arr.optString(i))
        }
        message.optJSONArray("file_sizes")?.let { arr ->
            for(i in 0 until arr.length()) attachedFileSizes.add(arr.optLong(i,0L))
        }
        while (attachedFileSizes.size < attachedFileIds.size) attachedFileSizes.add(0L)
        message.optString("image_path").takeIf { it.isNotBlank() }?.let { path ->
            if(File(path).isFile) pendingImagePath=path
        }
        message.optString("image_file_id").takeIf { it.isNotBlank() && it != "null" }?.let { pendingImageFileId=it }

        while(chat.size>idx) chat.removeAt(chat.size-1)
        while(messages.childCount>idx) messages.removeViewAt(messages.childCount-1)
        currentResponseId=chat.lastOrNull{it.optString("role")=="assistant"}
            ?.optString("response_id")?.takeIf{it.isNotBlank() && it!="null"}
        if(chat.isEmpty()) baselineEffort=null
        persistCurrentChat()
        input.setText(text)
        input.setSelection(input.text.length)
        refreshAttachChips()
        input.requestFocus()
        setBusy(false)
        status.text="Отредактируйте и отправьте снова"
    }

    private fun restoreLastUserAttachments(){
        val last=chat.lastOrNull{it.optString("role")=="user"} ?: return
        attachedFileIds.clear()
        attachedFileNames.clear()
        attachedFileSizes.clear()
        pendingImagePath=null
        pendingImageFileId=null
        last.optJSONArray("file_ids")?.let { arr ->
            for(i in 0 until arr.length()) attachedFileIds.add(arr.optString(i))
        }
        last.optJSONArray("file_names")?.let { arr ->
            for(i in 0 until arr.length()) attachedFileNames.add(arr.optString(i))
        }
        last.optJSONArray("file_sizes")?.let { arr ->
            for(i in 0 until arr.length()) attachedFileSizes.add(arr.optLong(i,0L))
        }
        while (attachedFileSizes.size < attachedFileIds.size) attachedFileSizes.add(0L)
        last.optString("image_path").takeIf { it.isNotBlank() }?.let { path ->
            if(File(path).isFile) pendingImagePath=path
        }
        last.optString("image_file_id").takeIf { it.isNotBlank() && it != "null" }?.let { pendingImageFileId=it }
    }

    private fun decodeThumbnailFromFile(path:String, maxDim:Int=640): Bitmap?{
        return try{
            val bounds=BitmapFactory.Options().apply{inJustDecodeBounds=true}
            BitmapFactory.decodeFile(path,bounds)
            if(bounds.outWidth<=0 || bounds.outHeight<=0) return null
            var sample=1
            while(bounds.outWidth/sample>maxDim || bounds.outHeight/sample>maxDim) sample*=2
            val opts=BitmapFactory.Options().apply{inSampleSize=sample; inPreferredConfig=Bitmap.Config.RGB_565}
            BitmapFactory.decodeFile(path,opts)
        }catch(_:Exception){null}
    }

    private fun copyImageToLocal(uri:Uri):String?{
        val mime=contentResolver.getType(uri)?.lowercase() ?: "image/jpeg"
        val ext=when{
            mime=="image/png"->"png"
            mime=="image/webp"->"webp"
            mime=="image/gif"->"gif"
            mime=="image/jpeg"->"jpg"
            else->throw IOException("Формат изображения не поддерживается: $mime. Используйте PNG, JPEG, WEBP или GIF.")
        }
        val maxBytes=50L*1024L*1024L
        val dir=File(filesDir,"attachments").apply{mkdirs()}
        val file=File(dir,"img_${System.currentTimeMillis()}_${System.nanoTime()}.$ext")
        var total=0L
        try{
            contentResolver.openInputStream(uri)?.use{input->
                file.outputStream().use{output->
                    val buffer=ByteArray(64*1024)
                    while(true){
                        val n=input.read(buffer)
                        if(n<0) break
                        total+=n
                        if(total>maxBytes){ throw IOException("Изображение слишком большое (максимум ${formatBytes(maxBytes)})") }
                        output.write(buffer,0,n)
                    }
                }
            } ?: throw IOException("Не удалось открыть изображение")
            return file.absolutePath
        }catch(e:Exception){
            file.delete()
            throw e
        }
    }

    // ---------- utils ----------
    private fun setBusy(v:Boolean){send.isEnabled=!v;stop.visibility=if(v)View.VISIBLE else View.GONE}
    private fun beginUpload(){ runOnUiThread{ pendingUploads++; send.isEnabled=false } }
    private fun endUpload(){ runOnUiThread{ pendingUploads=(pendingUploads-1).coerceAtLeast(0); if(pendingUploads==0) send.isEnabled=true } }
    private fun addBubble(
        label:String,
        text:String,
        user:Boolean,
        imageBitmap:Bitmap?=null,
        annotations:JSONArray?=null,
        message:JSONObject?=null
    ):TextView{
        val card=LinearLayout(this).apply{
            orientation=LinearLayout.VERTICAL
            setPadding(dp(13),dp(10),dp(13),dp(10))
            background=rounded(if(user)Color.rgb(31,40,54) else Color.rgb(28,29,34),14)
        }
        val who=TextView(this).apply{
            this.text=label;textSize=12f
            setTextColor(if(user)Color.rgb(160,195,245) else Color.rgb(190,195,205))
            setTypeface(null,Typeface.BOLD)
        }
        card.addView(who)
        imageBitmap?.let{ bmp->
            card.addView(ImageView(this).apply{
                setImageBitmap(bmp)
                setAdjustViewBounds(true)
                scaleType=ImageView.ScaleType.FIT_CENTER
                setPadding(0,dp(6),0,0)
            }, LinearLayout.LayoutParams(-1,dp(180)))
        }
        val body=TextView(this).apply{
            this.text=if(!user && message!=null) RichTextRenderer.render(AstraResponseModel.fromChatJson(message)) else markdown(text, annotations)
            textSize=16f
            setTextColor(Color.WHITE)
            setLinkTextColor(Color.rgb(138,180,248))
            movementMethod=LinkMovementMethod.getInstance()
            highlightColor=Color.TRANSPARENT
            setPadding(0,dp(5),0,dp(0))
        }
        card.addView(body)
        if(!user && annotations!=null){
            renderAnnotations(annotations,card,message ?: findMessageForAnnotations(annotations) ?: JSONObject(),currentChatId(),requestGeneration)
        }
        if(!user && message!=null){
            renderGeneratedImages(message,card)
        }
        if(!user && message!=null){
            addFeedbackRow(card,message,currentChatId())
        }
        val longPress=View.OnLongClickListener{
            val items=if(user)arrayOf("Копировать","Экспорт в TXT","Редактировать") else arrayOf("Копировать","Экспорт в TXT","Повторить последний запрос")
            AlertDialog.Builder(this).setItems(items){_,which->
                when(which){
                    0->{
                        val cm=getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                        cm.setPrimaryClip(ClipData.newPlainText("Astra",body.text?.toString().orEmpty()));status.text="Скопировано"
                    }
                    1->{
                        pendingExportBytes=body.text?.toString().orEmpty().toByteArray()
                        val i=Intent(Intent.ACTION_CREATE_DOCUMENT).apply{
                            addCategory(Intent.CATEGORY_OPENABLE)
                            type="text/plain"
                            putExtra(Intent.EXTRA_TITLE,"astra_message_${System.currentTimeMillis()}.txt")
                        }
                        try{ startActivityForResult(i,pickExportTxt) }
                        catch(e:Exception){ status.text="Экспорт недоступен: ${e.message}" }
                    }
                    2->if(user) editMessage(messages.indexOfChild(card)) else sendMessage(true)
                }
            }.show();true
        }
        card.setOnLongClickListener(longPress)
        body.setOnLongClickListener(longPress)
        who.setOnLongClickListener(longPress)
        messages.addView(card,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(8)})
        scroll.post{scroll.fullScroll(View.FOCUS_DOWN)}
        return body
    }

    private fun addFeedbackRow(card:LinearLayout, message:JSONObject, chatId:String){
        val requestId=message.optString("request_id").takeIf{it.isNotBlank() && it!="null"} ?: return
        val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(0,dp(6),0,0)}
        val current=message.optInt("feedback",0)
        fun feedbackButton(label:String,value:Int)=TextView(this).apply{
            text=if(current==value) "$label ✓" else label
            textSize=12f
            setTextColor(Color.rgb(150,155,165))
            setPadding(dp(6),dp(3),dp(10),dp(3))
            isEnabled=current==0
            setOnClickListener{
                if(message.optInt("feedback",0)!=0)return@setOnClickListener
                message.put("feedback",value)
                chatDb.recordFeedback(chatId,requestId,value)
                diagnostics.log("effort_feedback",mapOf("chat_id" to chatId,"request_id" to requestId,"value" to value))
                text="$label ✓"
                for(i in 0 until row.childCount) row.getChildAt(i).isEnabled=false
                status.text="Спасибо за оценку"
            }
        }
        row.addView(feedbackButton("👍",1))
        row.addView(feedbackButton("👎",-1))
        card.addView(row)
    }

    private fun findMessageForAnnotations(annotations:JSONArray):JSONObject?{
        return chat.lastOrNull{it.optString("role")=="assistant" && it.optJSONArray("annotations")?.toString()==annotations.toString()}
    }

    private fun markdown(s:String, annotations:JSONArray?=null):CharSequence = RichTextRenderer.render(s,annotations)

    private fun button(t:String,a:()->Unit)=Button(this).apply{
        text=t;textSize=16f;minWidth=0;minimumWidth=0
        setPadding(dp(10),dp(6),dp(10),dp(6))
        setTextColor(Color.rgb(210,214,222))
        background=rounded(Color.rgb(34,36,42))
        setOnClickListener{a()}
    }
    private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
    private fun rounded(fill:Int, radiusDp:Int=10): GradientDrawable = GradientDrawable().apply{
        cornerRadius = dp(radiusDp).toFloat()
        setColor(fill)
    }

    private class SecureStore(private val context:Context){
        private val prefs=context.getSharedPreferences("secure",Context.MODE_PRIVATE)
        private val alias="OpenAIApiChatKey"
        private fun key():SecretKey{
            val ks=KeyStore.getInstance("AndroidKeyStore").apply{load(null)}
            (ks.getKey(alias,null) as? SecretKey)?.let{return it}
            val gen=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore")
            gen.init(KeyGenParameterSpec.Builder(alias,KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).setRandomizedEncryptionRequired(true).build())
            return gen.generateKey()
        }
        fun setApiKey(v:String){
            if(v.isBlank()){prefs.edit().remove("key").apply();return}
            val c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,key())
            val p=c.iv+c.doFinal(v.toByteArray(Charsets.UTF_8))
            prefs.edit().putString("key",Base64.encodeToString(p,Base64.NO_WRAP)).apply()
        }
        fun getApiKey():String{
            return try{
                val p=Base64.decode(prefs.getString("key",null)?:return "",Base64.NO_WRAP)
                val iv=p.copyOfRange(0,12);val d=p.copyOfRange(12,p.size)
                val c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,key(),GCMParameterSpec(128,iv))
                String(c.doFinal(d),Charsets.UTF_8)
            }catch(_:Exception){""}
        }
    }
}
