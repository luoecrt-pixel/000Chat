package com.example.openaichat

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONArray
import org.json.JSONObject

/**
 * Persistent chat history and lightweight response/effort telemetry.
 * Settings remain in SharedPreferences; chat history no longer lives in one giant JSON blob.
 */
class ChatDatabase(context: Context) : SQLiteOpenHelper(context, DB_NAME, null, DB_VERSION) {
    companion object {
        private const val DB_NAME = "astra_chats.db"
        private const val DB_VERSION = 7
        private const val CHAT_TABLE = "chats"
        private const val MESSAGE_TABLE = "messages"
        private const val METRICS_TABLE = "effort_metrics"
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE $CHAT_TABLE (
                id TEXT PRIMARY KEY NOT NULL,
                title TEXT NOT NULL,
                response_id TEXT,
                baseline_effort TEXT,
                updated_at INTEGER NOT NULL
            )
        """.trimIndent())
        db.execSQL("""
            CREATE TABLE $MESSAGE_TABLE (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                chat_id TEXT NOT NULL,
                position INTEGER NOT NULL,
                role TEXT NOT NULL,
                text TEXT NOT NULL,
                response_id TEXT,
                request_id TEXT,
                file_ids TEXT,
                file_names TEXT,
                file_sizes TEXT,
                image_path TEXT,
                image_file_id TEXT,
                annotations TEXT,
                generated_images TEXT,
                tools TEXT,
                status TEXT,
                feedback INTEGER,
                FOREIGN KEY(chat_id) REFERENCES $CHAT_TABLE(id) ON DELETE CASCADE
            )
        """.trimIndent())
        db.execSQL("CREATE INDEX idx_messages_chat_position ON $MESSAGE_TABLE(chat_id, position)")
        db.execSQL("""
            CREATE TABLE $METRICS_TABLE (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                chat_id TEXT NOT NULL,
                created_at INTEGER NOT NULL,
                effort_pref TEXT NOT NULL,
                effective_effort TEXT NOT NULL,
                auto_selected INTEGER NOT NULL,
                prompt_chars INTEGER NOT NULL,
                attachments INTEGER NOT NULL,
                latency_ms INTEGER NOT NULL,
                input_tokens INTEGER NOT NULL DEFAULT 0,
                cached_tokens INTEGER NOT NULL DEFAULT 0,
                cache_write_tokens INTEGER NOT NULL DEFAULT 0,
                output_tokens INTEGER NOT NULL DEFAULT 0,
                reasoning_tokens INTEGER NOT NULL DEFAULT 0,
                success INTEGER NOT NULL,
                error_type TEXT,
                request_id TEXT,
                task_class TEXT NOT NULL DEFAULT 'general',
                feedback INTEGER
            )
        """.trimIndent())
        db.execSQL("CREATE INDEX idx_effort_metrics_created ON $METRICS_TABLE(created_at)")
        db.execSQL("CREATE INDEX idx_effort_metrics_task ON $METRICS_TABLE(task_class, effective_effort, feedback)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE $MESSAGE_TABLE ADD COLUMN image_file_id TEXT")
        }
        if (oldVersion < 3) {
            db.execSQL("ALTER TABLE $MESSAGE_TABLE ADD COLUMN tools TEXT")
            db.execSQL("ALTER TABLE $MESSAGE_TABLE ADD COLUMN status TEXT")
        }
        if (oldVersion < 4) {
            db.execSQL("ALTER TABLE $MESSAGE_TABLE ADD COLUMN feedback INTEGER")
            db.execSQL("ALTER TABLE $METRICS_TABLE ADD COLUMN request_id TEXT")
            db.execSQL("ALTER TABLE $METRICS_TABLE ADD COLUMN task_class TEXT NOT NULL DEFAULT 'general'")
            db.execSQL("ALTER TABLE $METRICS_TABLE ADD COLUMN feedback INTEGER")
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_effort_metrics_task ON $METRICS_TABLE(task_class, effective_effort, feedback)")
        }
        if (oldVersion < 5) {
            // request_id already exists in the original messages schema; older v4
            // migration attempted to add it again, which caused a duplicate-column crash.
        }
        if (oldVersion < 6) {
            db.execSQL("ALTER TABLE $MESSAGE_TABLE ADD COLUMN file_sizes TEXT")
        }
        if (oldVersion < 7) {
            db.execSQL("ALTER TABLE $MESSAGE_TABLE ADD COLUMN generated_images TEXT")
        }
    }

    /** One-time migration from v4.13's SharedPreferences chat_store JSON. */
    fun migrateLegacyPrefs(prefs: android.content.SharedPreferences) {
        if (prefs.getBoolean("chat_store_migrated_v7", false)) return
        val raw = prefs.getString("chat_store", null)
        writableDatabase.transaction { sql ->
            if (!raw.isNullOrBlank()) {
                val chats = try { JSONArray(raw) } catch (_: Exception) { JSONArray() }
                for (i in 0 until chats.length()) {
                    val c = chats.optJSONObject(i) ?: continue
                    upsertChatObject(sql, c)
                }
            }
        }
        prefs.edit().putBoolean("chat_store_migrated_v7", true).remove("chat_store").apply()
    }

    fun ensureChat(id: String, title: String = "Новый чат") {
        if (id.isBlank()) return
        val d = writableDatabase
        d.query(CHAT_TABLE, arrayOf("id"), "id=?", arrayOf(id), null, null, null, "1").use { c ->
            if (c.moveToFirst()) return
        }
        val v = ContentValues().apply {
            put("id", id)
            put("title", title.ifBlank { "Новый чат" })
            putNull("response_id")
            putNull("baseline_effort")
            put("updated_at", System.currentTimeMillis())
        }
        d.insertOrThrow(CHAT_TABLE, null, v)
    }

    fun getChat(id: String): JSONObject? {
        val d = readableDatabase
        d.query(CHAT_TABLE, null, "id=?", arrayOf(id), null, null, null, "1").use { c ->
            if (!c.moveToFirst()) return null
            val chat = JSONObject()
                .put("id", c.getString(c.getColumnIndexOrThrow("id")))
                .put("title", c.getString(c.getColumnIndexOrThrow("title")))
            val responseId = c.getString(c.getColumnIndexOrThrow("response_id"))
            val baseline = c.getString(c.getColumnIndexOrThrow("baseline_effort"))
            if (!responseId.isNullOrBlank()) chat.put("response_id", responseId) else chat.put("response_id", JSONObject.NULL)
            if (!baseline.isNullOrBlank()) chat.put("baseline_effort", baseline) else chat.put("baseline_effort", JSONObject.NULL)
            chat.put("messages", loadMessages(id))
            return chat
        }
    }

    fun getChatTitle(id: String): String? {
        if (id.isBlank()) return null
        readableDatabase.query(CHAT_TABLE, arrayOf("title"), "id=?", arrayOf(id), null, null, null, "1").use { c ->
            return if (c.moveToFirst()) c.getString(c.getColumnIndexOrThrow("title")) else null
        }
    }

    fun listChats(): List<JSONObject> {
        val out = mutableListOf<JSONObject>()
        readableDatabase.query(CHAT_TABLE, null, null, null, null, null, "updated_at DESC, id DESC").use { c ->
            while (c.moveToNext()) {
                val id = c.getString(c.getColumnIndexOrThrow("id"))
                val obj = JSONObject()
                    .put("id", id)
                    .put("title", c.getString(c.getColumnIndexOrThrow("title")))
                val responseId = c.getString(c.getColumnIndexOrThrow("response_id"))
                val baseline = c.getString(c.getColumnIndexOrThrow("baseline_effort"))
                if (!responseId.isNullOrBlank()) obj.put("response_id", responseId) else obj.put("response_id", JSONObject.NULL)
                if (!baseline.isNullOrBlank()) obj.put("baseline_effort", baseline) else obj.put("baseline_effort", JSONObject.NULL)
                obj.put("messages", loadMessages(id))
                out.add(obj)
            }
        }
        return out
    }

    /** Lightweight list for the chat picker; never loads full message histories. */
    fun listChatSummaries(): List<JSONObject> {
        val out = mutableListOf<JSONObject>()
        readableDatabase.query(
            CHAT_TABLE,
            arrayOf("id", "title", "response_id", "baseline_effort", "updated_at"),
            null, null, null, null, "updated_at DESC, id DESC"
        ).use { c ->
            while (c.moveToNext()) {
                val obj = JSONObject()
                    .put("id", c.getString(c.getColumnIndexOrThrow("id")))
                    .put("title", c.getString(c.getColumnIndexOrThrow("title")))
                val responseId = c.getString(c.getColumnIndexOrThrow("response_id"))
                val baseline = c.getString(c.getColumnIndexOrThrow("baseline_effort"))
                if (!responseId.isNullOrBlank()) obj.put("response_id", responseId)
                if (!baseline.isNullOrBlank()) obj.put("baseline_effort", baseline)
                out.add(obj)
            }
        }
        return out
    }


    fun renameChat(id: String, title: String) {
        writableDatabase.update(CHAT_TABLE, ContentValues().apply {
            put("title", title.ifBlank { "Чат" })
            put("updated_at", System.currentTimeMillis())
        }, "id=?", arrayOf(id))
    }

    fun deleteChat(id: String) {
        writableDatabase.transaction { db ->
            db.delete(MESSAGE_TABLE, "chat_id=?", arrayOf(id))
            db.delete(CHAT_TABLE, "id=?", arrayOf(id))
        }
    }

    fun upsertCurrentChat(id: String, title: String, responseId: String?, baselineEffort: String?, messages: List<JSONObject>) {
        if (id.isBlank()) return
        writableDatabase.transaction { db ->
            val exists = db.query(CHAT_TABLE, arrayOf("id"), "id=?", arrayOf(id), null, null, null, "1").use { it.moveToFirst() }
            val values = ContentValues().apply {
                put("id", id)
                put("title", title.ifBlank { "Новый чат" })
                if (responseId.isNullOrBlank()) putNull("response_id") else put("response_id", responseId)
                if (baselineEffort.isNullOrBlank()) putNull("baseline_effort") else put("baseline_effort", baselineEffort)
                put("updated_at", System.currentTimeMillis())
            }
            if (exists) db.update(CHAT_TABLE, values, "id=?", arrayOf(id)) else db.insertOrThrow(CHAT_TABLE, null, values)
            db.delete(MESSAGE_TABLE, "chat_id=?", arrayOf(id))
            messages.forEachIndexed { index, m ->
                val mv = ContentValues().apply {
                    put("chat_id", id)
                    put("position", index)
                    put("role", m.optString("role"))
                    put("text", m.optString("text"))
                    putStringOrNull("response_id", m.optString("response_id").takeIf { it.isNotBlank() && it != "null" })
                    putStringOrNull("request_id", m.optString("request_id").takeIf { it.isNotBlank() && it != "null" })
                    putStringOrNull("file_ids", m.optJSONArray("file_ids")?.toString())
                    putStringOrNull("file_names", m.optJSONArray("file_names")?.toString())
                    putStringOrNull("file_sizes", m.optJSONArray("file_sizes")?.toString())
                    putStringOrNull("image_path", m.optString("image_path").takeIf { it.isNotBlank() })
                    putStringOrNull("image_file_id", m.optString("image_file_id").takeIf { it.isNotBlank() && it != "null" })
                    putStringOrNull("annotations", m.optJSONArray("annotations")?.toString())
                    putStringOrNull("generated_images", m.optJSONArray("generated_images")?.toString())
                    putStringOrNull("tools", m.optJSONArray("tools")?.toString())
                    putStringOrNull("status", m.optString("status").takeIf { it.isNotBlank() && it != "null" })
                    if (m.has("feedback") && !m.isNull("feedback")) put("feedback", m.optInt("feedback")) else putNull("feedback")
                }
                db.insertOrThrow(MESSAGE_TABLE, null, mv)
            }
        }
    }

    fun recordEffortMetric(
        requestId: String?,
        chatId: String,
        taskClass: String,
        effortPref: String,
        effectiveEffort: String,
        autoSelected: Boolean,
        promptChars: Int,
        attachments: Int,
        latencyMs: Long,
        inputTokens: Int,
        cachedTokens: Int,
        cacheWriteTokens: Int,
        outputTokens: Int,
        reasoningTokens: Int,
        success: Boolean,
        errorType: String?
    ) {
        val v = ContentValues().apply {
            put("chat_id", chatId)
            put("created_at", System.currentTimeMillis())
            putStringOrNull("request_id", requestId)
            put("task_class", taskClass.ifBlank { "general" })
            put("effort_pref", effortPref)
            put("effective_effort", effectiveEffort)
            put("auto_selected", if (autoSelected) 1 else 0)
            put("prompt_chars", promptChars)
            put("attachments", attachments)
            put("latency_ms", latencyMs.coerceAtLeast(0))
            put("input_tokens", inputTokens.coerceAtLeast(0))
            put("cached_tokens", cachedTokens.coerceAtLeast(0))
            put("cache_write_tokens", cacheWriteTokens.coerceAtLeast(0))
            put("output_tokens", outputTokens.coerceAtLeast(0))
            put("reasoning_tokens", reasoningTokens.coerceAtLeast(0))
            put("success", if (success) 1 else 0)
            putStringOrNull("error_type", errorType)
        }
        writableDatabase.insert(METRICS_TABLE, null, v)
    }

    fun recordFeedback(chatId: String, requestId: String, value: Int) {
        val v = value.coerceIn(-1, 1)
        if (requestId.isBlank() || v == 0) return
        writableDatabase.transaction { db ->
            db.execSQL(
                "UPDATE $METRICS_TABLE SET feedback=? WHERE chat_id=? AND request_id=?",
                arrayOf(v, chatId, requestId)
            )
            db.query(MESSAGE_TABLE, arrayOf("id", "annotations", "feedback"), "chat_id=? AND request_id=?", arrayOf(chatId, requestId), null, null, "position DESC", "1").use { c ->
                if (!c.moveToFirst()) return@use
                val id = c.getLong(c.getColumnIndexOrThrow("id"))
                val cv = ContentValues().apply { put("feedback", v) }
                db.update(MESSAGE_TABLE, cv, "id=?", arrayOf(id.toString()))
            }
        }
    }

    fun updateGeneratedFileState(
        chatId: String,
        fileId: String,
        state: String,
        localPath: String? = null,
        mimeType: String? = null,
        sizeBytes: Long? = null,
        error: String? = null,
        annotationType: String? = null
    ) {
        if (chatId.isBlank() || fileId.isBlank()) return
        writableDatabase.transaction { db ->
            db.query(MESSAGE_TABLE, arrayOf("id", "annotations"), "chat_id=? AND annotations IS NOT NULL", arrayOf(chatId), null, null, "position ASC").use { c ->
                while (c.moveToNext()) {
                    val raw = c.getString(c.getColumnIndexOrThrow("annotations")) ?: continue
                    val anns = try { JSONArray(raw) } catch (_: Exception) { continue }
                    var changed = false
                    for (i in 0 until anns.length()) {
                        val a = anns.optJSONObject(i) ?: continue
                        val type = a.optString("type")
                        if (type != "container_file_citation" && type != "file_citation") continue
                        if (annotationType != null && type != annotationType) continue
                        if (a.optString("file_id") != fileId) continue
                        a.put("state", state)
                        if (localPath != null) a.put("local_path", localPath)
                        if (mimeType != null) a.put("mime_type", mimeType)
                        if (sizeBytes != null) a.put("size_bytes", sizeBytes)
                        if (error != null) a.put("error", error) else a.remove("error")
                        changed = true
                    }
                    if (changed) {
                        val cv = ContentValues().apply { put("annotations", anns.toString()) }
                        db.update(MESSAGE_TABLE, cv, "id=?", arrayOf(c.getLong(c.getColumnIndexOrThrow("id")).toString()))
                    }
                }
            }
        }
    }

    /**
     * Use explicit user feedback as a conservative correction to the lexical baseline.
     * With fewer than 3 ratings for a task/effort pair, the heuristic stays authoritative.
     */
    fun autoEffortHint(taskClass: String, baseline: String): String {
        val levels = listOf("low", "medium", "high", "xhigh", "max")
        val baseIndex = levels.indexOf(baseline).takeIf { it >= 0 } ?: 2
        val candidates = mutableListOf<Pair<String, Double>>()
        readableDatabase.query(
            METRICS_TABLE,
            arrayOf("effective_effort", "COUNT(*) AS n", "AVG(feedback) AS avg_feedback"),
            "task_class=? AND feedback IS NOT NULL",
            arrayOf(taskClass.ifBlank { "general" }),
            "effective_effort",
            null,
            null
        ).use { c ->
            while (c.moveToNext()) {
                val n = c.getInt(c.getColumnIndexOrThrow("n"))
                if (n >= 3) candidates.add(c.getString(0) to c.getDouble(2))
            }
        }
        if (candidates.isEmpty()) return baseline
        val best = candidates.maxByOrNull { it.second } ?: return baseline
        val bestIndex = levels.indexOf(best.first).takeIf { it >= 0 } ?: return baseline
        // Never let sparse feedback jump more than one reasoning tier from the baseline.
        if (kotlin.math.abs(bestIndex - baseIndex) > 1) return baseline
        if (best.second < 0.35) return baseline
        val baselineStats = candidates.firstOrNull { it.first == baseline }
        if (baselineStats != null && best.second - baselineStats.second < 0.35) return baseline
        return best.first
    }

    fun effortStats(days: Int = 30): String {
        val since = System.currentTimeMillis() - days.coerceIn(1, 3650) * 86_400_000L
        val sb = StringBuilder()
        val d = readableDatabase
        d.query(
            METRICS_TABLE,
            arrayOf("effective_effort", "COUNT(*) AS n", "AVG(latency_ms) AS latency", "SUM(output_tokens) AS output", "SUM(reasoning_tokens) AS reasoning", "SUM(success) AS success", "SUM(CASE WHEN feedback IS NOT NULL THEN 1 ELSE 0 END) AS ratings", "AVG(feedback) AS avg_feedback"),
            "created_at>=?",
            arrayOf(since.toString()),
            "effective_effort",
            null,
            "CASE effective_effort WHEN 'low' THEN 1 WHEN 'medium' THEN 2 WHEN 'high' THEN 3 WHEN 'xhigh' THEN 4 WHEN 'max' THEN 5 ELSE 6 END"
        ).use { c ->
            if (!c.moveToFirst()) return "Пока нет измерений."
            sb.append("Последние $days дней\n\n")
            do {
                val effort = c.getString(c.getColumnIndexOrThrow("effective_effort"))
                val n = c.getInt(c.getColumnIndexOrThrow("n"))
                val latency = c.getDouble(c.getColumnIndexOrThrow("latency"))
                val output = c.getLong(c.getColumnIndexOrThrow("output"))
                val reasoning = c.getLong(c.getColumnIndexOrThrow("reasoning"))
                val success = c.getInt(c.getColumnIndexOrThrow("success"))
                val ratings = c.getInt(c.getColumnIndexOrThrow("ratings"))
                val avgFeedback = c.getDouble(c.getColumnIndexOrThrow("avg_feedback"))
                val feedbackText = if (ratings > 0) ", оценок $ratings, avg ${"%.2f".format(avgFeedback)}" else ""
                sb.append("$effort: $n запросов, успех $success/$n, средняя задержка ${"%.1f".format(latency / 1000.0)} с, output ${formatTokens(output)}, reasoning ${formatTokens(reasoning)}$feedbackText\n")
            } while (c.moveToNext())
        }
        return sb.toString().trim()
    }

    private fun loadMessages(chatId: String): JSONArray {
        val arr = JSONArray()
        readableDatabase.query(MESSAGE_TABLE, null, "chat_id=?", arrayOf(chatId), null, null, "position ASC, id ASC").use { c ->
            while (c.moveToNext()) {
                val m = JSONObject()
                    .put("role", c.getString(c.getColumnIndexOrThrow("role")))
                    .put("text", c.getString(c.getColumnIndexOrThrow("text")))
                c.getString(c.getColumnIndexOrThrow("response_id"))?.let { if (it.isNotBlank()) m.put("response_id", it) }
                c.getString(c.getColumnIndexOrThrow("request_id"))?.let { if (it.isNotBlank()) m.put("request_id", it) }
                parseArrayColumn(c.getString(c.getColumnIndexOrThrow("file_ids")))?.let { m.put("file_ids", it) }
                parseArrayColumn(c.getString(c.getColumnIndexOrThrow("file_names")))?.let { m.put("file_names", it) }
                parseArrayColumn(c.getString(c.getColumnIndexOrThrow("file_sizes")))?.let { m.put("file_sizes", it) }
                c.getString(c.getColumnIndexOrThrow("image_path"))?.let { if (it.isNotBlank()) m.put("image_path", it) }
                c.getString(c.getColumnIndexOrThrow("image_file_id"))?.let { if (it.isNotBlank()) m.put("image_file_id", it) }
                parseArrayColumn(c.getString(c.getColumnIndexOrThrow("annotations")))?.let { m.put("annotations", it) }
                parseArrayColumn(c.getString(c.getColumnIndexOrThrow("generated_images")))?.let { m.put("generated_images", it) }
                parseArrayColumn(c.getString(c.getColumnIndexOrThrow("tools")))?.let { m.put("tools", it) }
                c.getString(c.getColumnIndexOrThrow("status"))?.let { if (it.isNotBlank()) m.put("status", it) }
                if (!c.isNull(c.getColumnIndexOrThrow("feedback"))) m.put("feedback", c.getInt(c.getColumnIndexOrThrow("feedback")))
                arr.put(m)
            }
        }
        return arr
    }

    private fun upsertChatObject(db: SQLiteDatabase, c: JSONObject) {
        val id = c.optString("id").trim()
        if (id.isBlank()) return
        val title = c.optString("title", "Новый чат").ifBlank { "Новый чат" }
        val v = ContentValues().apply {
            put("id", id)
            put("title", title)
            val response = c.optString("response_id").takeIf { it.isNotBlank() && it != "null" }
            putStringOrNull("response_id", response)
            val baseline = c.optString("baseline_effort").takeIf { it.isNotBlank() && it != "null" }
            putStringOrNull("baseline_effort", baseline)
            put("updated_at", System.currentTimeMillis())
        }
        db.insertWithOnConflict(CHAT_TABLE, null, v, SQLiteDatabase.CONFLICT_REPLACE)
        db.delete(MESSAGE_TABLE, "chat_id=?", arrayOf(id))
        val arr = c.optJSONArray("messages") ?: JSONArray()
        for (i in 0 until arr.length()) {
            val m = arr.optJSONObject(i) ?: continue
            val mv = ContentValues().apply {
                put("chat_id", id)
                put("position", i)
                put("role", m.optString("role"))
                put("text", m.optString("text"))
                putStringOrNull("response_id", m.optString("response_id").takeIf { it.isNotBlank() && it != "null" })
                putStringOrNull("request_id", m.optString("request_id").takeIf { it.isNotBlank() && it != "null" })
                putStringOrNull("file_ids", m.optJSONArray("file_ids")?.toString())
                putStringOrNull("file_names", m.optJSONArray("file_names")?.toString())
                putStringOrNull("image_path", m.optString("image_path").takeIf { it.isNotBlank() })
                putStringOrNull("image_file_id", m.optString("image_file_id").takeIf { it.isNotBlank() && it != "null" })
                putStringOrNull("annotations", m.optJSONArray("annotations")?.toString())
                putStringOrNull("tools", m.optJSONArray("tools")?.toString())
                putStringOrNull("status", m.optString("status").takeIf { it.isNotBlank() && it != "null" })
                if (m.has("feedback") && !m.isNull("feedback")) put("feedback", m.optInt("feedback")) else putNull("feedback")
            }
            db.insertOrThrow(MESSAGE_TABLE, null, mv)
        }
    }

    private fun ContentValues.putStringOrNull(key: String, value: String?) {
        if (value.isNullOrBlank()) putNull(key) else put(key, value)
    }

    private fun parseArrayColumn(raw: String?): JSONArray? {
        if (raw.isNullOrBlank()) return null
        return try { JSONArray(raw) } catch (_: Exception) { null }
    }

    private fun formatTokens(n: Long): String = when {
        n >= 1_000_000 -> "%.1fM".format(n / 1_000_000.0)
        n >= 1_000 -> "%.1fK".format(n / 1_000.0)
        else -> n.toString()
    }

    private inline fun SQLiteDatabase.transaction(block: (SQLiteDatabase) -> Unit) {
        beginTransaction()
        try {
            block(this)
            setTransactionSuccessful()
        } finally {
            endTransaction()
        }
    }
}
