# What to take from Astra v4.14.1

The supplied build log showed that the previous source package failed at Kotlin compilation, not in the Android SDK setup.

## Fixes included

1. Enable `buildConfig = true` in `app/build.gradle.kts`.
2. Fix the two `ChatDatabase` transaction receiver mistakes (`db.transaction` and bare `delete`).
3. Use DB schema version 7. The old v4 -> v5 migration attempted to add `messages.request_id` even though that column already existed; do not reintroduce that migration bug.
4. Keep the canonical workflow at `.github/workflows/build.yml`. The failed run explicitly loaded that file. Update that file in the repository. Remove/replace any duplicate old build workflow if it would cause a second build.
5. The workflow now uses checkout@v7, setup-java@v6, setup-android@v4, setup-gradle@v6, upload-artifact@v7, JDK 17, SDK 35 and Gradle 8.9.
6. `container_file_citation` and `file_citation` are treated as real files, not `sandbox:/` web URLs. Container files auto-download; File Search citations expose a deliberate Download action.
7. `image_generation_call.result` is saved locally as PNG and shown with Open/Save/Share.
8. Persist the user + assistant messages before starting asynchronous file/image rendering so DB state updates are reliable.
9. Track uploaded file sizes and enforce the 50 MB total input-file budget when sizes are known.
10. Keep `configuration_update` separate from automatic compaction: on a request that changes reasoning configuration, do not send automatic compaction in the same request.
11. Use chat summaries for the chat picker instead of loading all messages for every chat.
12. Use unique chat IDs with `System.currentTimeMillis() + System.nanoTime()`.

## Already working in the supplied v4.14 source — do NOT duplicate

- Auto-effort metrics and feedback calibration already exist.
- Diagnostics logging already exists.
- ZIP streaming/per-entry 25 MB protection already exists.
- Normal Markdown/bare HTTP(S) links are already clickable.
- Race protection and current-chat deletion fix already exist.
- web_search_preview -> web_search is already done.
- Normal multipart upload preserves the filename.

## Build instruction

The repository must contain the updated `.github/workflows/build.yml`. The previous build log proves that this is the workflow actually executed.

Do not commit multiple `*-source.zip` archives at repo root. The new workflow intentionally fails when more than one source archive is present, instead of guessing which source to unzip.

---

# v4.15.1 handoff note

v4.15.1 is a GPT-authored increment on top of v4.14.1. Do not revert the already-working v4.14/v4.14.1 features.

New in this increment:
- live tool activity statuses with request/chat guards;
- local Astra file library;
- background Responses with automatic resume/poll after Activity recreation or restart;
- automatic continuation after a local stream disconnect once a response ID is known;
- composer draft + attachment persistence per chat;
- upload callbacks scoped to the originating chat;
- send button remains disabled while uploads or an active response exist;
- usage/token/cost dashboard;
- long-chat preflight warning.

The canonical workflow is still `.github/workflows/build.yml`; no workflow change is required for v4.15.1.


# v4.15.1 handoff

This is a GPT-authored fix/feature increment on top of v4.14. Do not revert v4.14/v4.14.1/v4.15.0 functionality.

## Changes from v4.14 through v4.15.1

- v4.14 baseline: real `container_file_citation` downloads, clickable `url_citation`, current-chat deletion fix, export error handling, request/chat race protection, `web_search`, SQLite foundation, diagnostics, Auto-effort metrics/feedback, safe ZIP entry protections, generated image/file handling.
- v4.14.1 build fixes: enabled BuildConfig, fixed SQLite transaction receiver errors, fixed legacy DB migration path, added known 50 MB total input-file preflight, improved file citation handling, generated-image local persistence, lightweight chat summaries, unique chat IDs, separate `configuration_update` from compaction.
- v4.15.0 UX/reliability: live tool-activity strip; local Astra file library; Background Responses with automatic polling/reconciliation after app restart; per-chat composer draft persistence and attachment restoration; send-button guard while uploads/generation are active; usage/token/cost dashboard; non-blocking long-chat warning; durable active-response state.
- v4.15.1 build fixes after the next CI log: changed resumed-response message list to mutable before `add()`; added Long token formatter overload for statistics.
- v4.15.1 reasoning summaries: the existing `reasoning.summary` setting is now actually surfaced in the UI. Final reasoning items are parsed from Responses output, streaming `response.reasoning_summary_text.delta` events are shown live, and saved summaries are persisted/restored with assistant messages. UI text is `🧠 Показать ход рассуждений`; this is the API-provided reasoning summary, not raw private chain-of-thought.
- v4.15.1 static verifier updated to check the reasoning-summary path and version.

## Important CI note

The supplied failed run came from the repository's own `.github/workflows/build.yml`, which was still using `actions/checkout@v4`, `android-actions/setup-android@v3`, and `gradle/actions/setup-gradle@v4`. The newer workflow inside the source archive does not retroactively replace the repository workflow that invoked it. Copy the provided `.github/workflows/build.yml` into the repository and commit it.

## Latest observed compile errors fixed in v4.15.1

- `MainActivity.kt:1353` — `jsonArrayToList()` returned immutable `List`; resumed finalization now uses a mutable list.
- `MainActivity.kt:1856-1858` — usage totals are Long but formatter only accepted Int; `fmtTokens(Long)` overload added.

Do not claim the APK was built here; the authoritative build test is the GitHub Actions run.
