from pathlib import Path
import re
import sqlite3
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
MAIN = ROOT / "app/src/main/java/com/example/openaichat/MainActivity.kt"
DB = ROOT / "app/src/main/java/com/example/openaichat/ChatDatabase.kt"
MODEL = ROOT / "app/src/main/java/com/example/openaichat/AstraResponseModel.kt"
RENDERER = ROOT / "app/src/main/java/com/example/openaichat/RichTextRenderer.kt"
GRADLE = ROOT / "app/build.gradle.kts"
WF = ROOT / ".github/workflows/build.yml"

main = MAIN.read_text()
db = DB.read_text()
model = MODEL.read_text()
renderer = RENDERER.read_text()
gradle = GRADLE.read_text()
workflow = WF.read_text()

assert 'versionName = "4.15.0"' in gradle
assert 'buildConfig = true' in gradle
assert 'container_file_citation' in main
assert 'file_citation' in main
assert 'url_citation' in main
assert 'put("type","web_search")' in main
assert 'configuration_update' in main
assert 'context_management' in main
assert 'if (configUpdateEffort == null)' in main
assert 'response.failed' in main
assert 'response.incomplete' in main
assert 'body.byteStream()' in main
assert 'body.bytes()' not in main
assert 'web_search_preview' not in main
assert 'AstraResponseModel.fromResponse' in main
assert 'AstraResponseModel.fromChatJson' in main
assert 'generatedImageResults' in main
assert 'saveGeneratedImages' in main
assert 'renderGeneratedImages' in main
assert 'Triple<String,String,Long>' in main
assert 'newChatId()' in main
assert 'listChatSummaries()' in main
assert 'BuildConfig.APPLICATION_ID' in main
assert 'downloadContainerFile' not in main
assert 'file_sizes' in main
assert 'generated_images' in (ROOT/'app/src/main/res/xml/file_paths.xml').read_text()
assert 'generated_images' in main
assert 'background_responses' in main
assert 'background' in main
assert 'pollBackgroundResponse' in main
assert 'setBusy(true)' in main
assert 'showLocalFiles' in main
assert 'showUsageStats' in main
assert 'persistComposerStateNow' in main
assert 'resumePendingUploads' in main
assert 'historyChars' in main
assert 'request_chat_id' not in main
assert 'URLSpan' in renderer
assert 'DB_VERSION = 10' in db
assert 'autoEffortHint' in db
assert 'getChatTitle' in db
assert 'request_id already exists' in db
assert 'ALTER TABLE $MESSAGE_TABLE ADD COLUMN file_sizes TEXT' in db
assert 'ALTER TABLE $MESSAGE_TABLE ADD COLUMN generated_images TEXT' in db

# The completion path should persist messages before rendering annotations/images.
completion_start = main.index('runOnUiThread{', main.index('val assistantMessage'))
completion = main[completion_start:]
completion_order = [completion.index('persistCurrentChat()'), completion.index('renderAnnotations'), completion.index('renderGeneratedImages')]
assert completion_order == sorted(completion_order), "Persistence must happen before annotation/image rendering"

# There should be exactly one completion-path construction of userMessage.
assert main.count('val sentUserMessage = JSONObject().put("role","user").put("text",text)') == 1

# The chat list path should use summaries rather than full histories.
assert 'private fun loadAllChats():List<JSONObject> = chatDb.listChatSummaries()' in main

# Validate XML files.
for p in [ROOT/'app/src/main/AndroidManifest.xml', *ROOT.glob('app/src/main/res/**/*.xml')]:
    ET.parse(p)

# Verify the current representative schema in a real SQLite engine.
con = sqlite3.connect(':memory:')
con.execute('''CREATE TABLE chats (
    id TEXT PRIMARY KEY NOT NULL,
    title TEXT NOT NULL,
    response_id TEXT,
    baseline_effort TEXT,
    updated_at INTEGER NOT NULL,
    active_response_id TEXT,
    active_request_id TEXT,
    active_text TEXT,
    active_status TEXT,
    active_started_at INTEGER,
    active_effort_pref TEXT,
    active_effective_effort TEXT,
    active_auto_selected INTEGER NOT NULL DEFAULT 0,
    active_prompt_chars INTEGER NOT NULL DEFAULT 0,
    active_attachments INTEGER NOT NULL DEFAULT 0
)''')
con.execute('''CREATE TABLE messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    chat_id TEXT NOT NULL,
    position INTEGER NOT NULL,
    role TEXT NOT NULL,
    text TEXT NOT NULL,
    response_id TEXT,
    request_id TEXT,
    file_ids TEXT,
    file_names TEXT,
    file_sizes TEXT,
    image_path TEXT,
    image_file_id TEXT,
    annotations TEXT,
    generated_images TEXT,
    tools TEXT,
    status TEXT,
    feedback INTEGER,
    FOREIGN KEY(chat_id) REFERENCES chats(id) ON DELETE CASCADE
)''')
con.execute('''CREATE TABLE effort_metrics (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    chat_id TEXT NOT NULL,
    created_at INTEGER NOT NULL,
    effort_pref TEXT NOT NULL,
    effective_effort TEXT NOT NULL,
    auto_selected INTEGER NOT NULL,
    prompt_chars INTEGER NOT NULL,
    attachments INTEGER NOT NULL,
    latency_ms INTEGER NOT NULL,
    input_tokens INTEGER NOT NULL DEFAULT 0,
    cached_tokens INTEGER NOT NULL DEFAULT 0,
    cache_write_tokens INTEGER NOT NULL DEFAULT 0,
    output_tokens INTEGER NOT NULL DEFAULT 0,
    reasoning_tokens INTEGER NOT NULL DEFAULT 0,
    success INTEGER NOT NULL,
    error_type TEXT,
    request_id TEXT,
    task_class TEXT NOT NULL DEFAULT 'general',
    feedback INTEGER,
    estimated_cost_usd REAL NOT NULL DEFAULT 0
)''')
cols = {r[1] for r in con.execute('PRAGMA table_info(messages)')}
assert {'file_sizes', 'generated_images', 'request_id'} <= cols

# Basic Kotlin delimiter sanity check: ignore quoted strings and line/block comments.
def delimiter_balance(src: str):
    stack=[]
    i=0
    state='code'
    while i < len(src):
        c=src[i]; n=src[i+1] if i+1 < len(src) else ''
        if state=='line':
            if c=='\n': state='code'
            i+=1; continue
        if state=='block':
            if c=='*' and n=='/': state='code'; i+=2
            else: i+=1
            continue
        if state=='string':
            if c=='\\': i+=2; continue
            if c=='"': state='code'
            i+=1; continue
        if state=='char':
            if c=='\\': i+=2; continue
            if c=="'": state='code'
            i+=1; continue
        if c=='/' and n=='/': state='line'; i+=2; continue
        if c=='/' and n=='*': state='block'; i+=2; continue
        if c=='"': state='string'; i+=1; continue
        if c=="'": state='char'; i+=1; continue
        if c in '({[': stack.append(c)
        elif c in ')}]':
            if not stack:
                raise AssertionError('unexpected delimiter')
            expected={')':'(', '}':'{', ']':'['}[c]
            if stack[-1] != expected:
                raise AssertionError(f'delimiter mismatch: expected {expected}, got {c}')
            stack.pop()
        i+=1
    assert state=='code', f'unclosed lexer state: {state}'
    assert not stack, f'unclosed delimiters: {stack[-10:]}'

for src_path in [MAIN, DB, MODEL, RENDERER]:
    delimiter_balance(src_path.read_text())

# Workflow sanity.
for action in [
    'actions/checkout@v7',
    'actions/setup-java@v6',
    'android-actions/setup-android@v4',
    'gradle/actions/setup-gradle@v6',
    'actions/upload-artifact@v7',
]:
    assert action in workflow
assert 'gradle-version: \'8.9\'' in workflow
assert 'find . -maxdepth 1 -type f -name \'*-source.zip\'' in workflow

assert '.put("background",backgroundEnabled)' in main
assert 'canContinueInBackground' in main
assert 'historyChars' in main
print('Astra v4.15.0 static verification: PASS')
