
# Сборка APK с Android

1. Открой GitHub в Chrome и создай пустой репозиторий.
2. Нажми Add file → Upload files.
3. Загрузи ВСЕ файлы и папки из `OpenAIApiChat`.
4. Commit changes.
5. Открой вкладку Actions.
6. Нажми `Build Android APK`.
7. Нажми `Run workflow`.
8. После окончания job открой её страницу и раздел Artifacts.
9. Скачай `OpenAIApiChat-enhanced-debug`.
10. Распакуй ZIP и установи `app-debug.apk`.

API key не нужен для сборки и не должен храниться в репозитории.

