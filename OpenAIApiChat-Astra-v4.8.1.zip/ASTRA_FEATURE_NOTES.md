# Astra feature notes

Implemented directly:
- reasoning.effort
- max_output_tokens
- instructions
- prompt_cache_key
- parallel_tool_calls
- streaming
- previous_response_id
- web_search_preview
- file_search with vector_store_ids
- file upload + input_file
- code_interpreter auto container
- image_generation tool flag
- image + text inputs

Not fully implemented:
- Computer Use executor
- arbitrary custom function tools / MCP UX
- Realtime voice UI
- rich image-generation result gallery
- Structured Outputs schema editor

The app does not use `temperature` or `top_p` because GPT-6 Astra guidance says to remove them for this model.

