# FINAL AUDIT v4.1

Verified fixes from the user's crash log:
- `ensureChatStore()` no longer calls `newChat()` before `buildUi()` initializes `messages` and `title`.
- `setHintTextColor(...)` is used instead of the invalid Kotlin property assignment.
- `this.text = label` is used inside the `apply` block to avoid capturing the function parameter.
- `android.content.ClipboardManager` is imported explicitly.

Additional compile-safety fix:
- Removed `JSONArray(attachedFileIds)` and replaced it with explicit JSON array construction.

Checked archive:
- `unzip -t` passes.
- GitHub Actions workflow is present.
- Android project files are present.

API note:
- `web_search_preview` is still used in the current OpenAI Responses API reference examples for GPT-6 Astra, so it was not changed solely because it is called "preview".
- GPT-6 Astra currently supports web search, file search, image generation, code interpreter, hosted shell, apply patch, skills, computer use, MCP, and tool search; however several of these require a real executor/integration in the client and cannot be implemented as a UI toggle alone.


## v4.2 UI thread crash fix

Fixed Android crash: `Only the original thread that created a view hierarchy can touch its views`.
The assistant bubble is created on the main thread before the network worker starts. Streaming TextView updates already use `runOnUiThread`, and final chat mutation/persistence now also execute on main.
The earlier startup-order bug is preserved as fixed: `ensureChatStore()` does not call `newChat()` before `buildUi()`.
