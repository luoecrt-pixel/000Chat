# OpenAI API Chat — Astra Final v4

Нативный Android-клиент для использования собственного OpenAI API key, ориентированный на GPT-6 Astra.

## Реализовано

- Чат-интерфейс в стиле ChatGPT
- несколько локально сохранённых чатов
- список чатов + переименование + удаление
- streaming через Responses API
- `previous_response_id` для продолжения контекста
- regenerate последнего пользовательского запроса
- копирование ответа
- `reasoning.effort`: low / medium / high / xhigh / max
- max output tokens до 128K
- developer instructions
- prompt cache key
- parallel tool calls
- Web Search
- File Search + Vector Store ID
- загрузка документов в `/v1/files`
- input image / input file
- Code Interpreter
- Image Generation tool
- Structured Outputs через JSON Schema
- базовое отображение Markdown / inline code
- API key через Android Keystore
- отмена генерации
- отображение задействованных инструментов
- GitHub Actions для сборки APK

## Что не является «магически включённым»

Astra поддерживает Computer Use, MCP, Hosted Shell, Skills, Apply Patch, Programmatic Tool Calling, async tool calling, mid-turn steering и другие возможности. Некоторые из них требуют внешнего исполнителя/серверной интеграции. Android-клиент не может корректно выполнить, например, произвольные Computer Use действия только потому, что в JSON присутствует соответствующий tool.

Голос работает через отдельные realtime/audio API, а не через обычный текстовый `/v1/responses`.

## Важная проверка API

На момент текущей документации OpenAI GPT-6 Astra:
- model ID: `gpt-6-astra`
- context window: 1,050,000
- max output: 128,000
- reasoning: low / medium / high / xhigh / max

Конкретные инструменты и их доступность зависят от модели и вашего API-проекта.


## Финальная проверка

В архиве присутствует `.github/workflows/build-apk.yml`. Три Kotlin-исправления из проверки также присутствуют: `setHintTextColor(...)`, `this.text = label` и явный `android.content.ClipboardManager`.

OpenAI в текущей документации по Responses API продолжает документировать `web_search_preview` наряду с новым `web_search`, поэтому использование preview не является само по себе ошибкой сборки.
